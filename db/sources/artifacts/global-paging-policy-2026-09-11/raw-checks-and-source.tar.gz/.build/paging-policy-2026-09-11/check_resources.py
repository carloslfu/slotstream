import json, os, sys
from pathlib import Path
ROOT=Path.cwd(); sys.path.insert(0, str(ROOT/'Tools'))
from context_qualification import quiet_preflight
from context_resource_gates import validate_receipt
from memory_gate import check_memory, swap_deltas
from prefill_bench import run_child, vm_snapshot
from serve_bench import verified_build
base=ROOT/'.build/paging-policy-2026-09-11'
binary=base/'local-build/candidate/slotstream'
identity=verified_build(binary)['identity']
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k!='BIN'}
for name,args,need,timeout in [
    ('local-governor',['elastic-drill','--slots','1000','--max-memory-gb','13'],16,600),
    ('local-context',['context-check','--tokens','2048','--memory-gb','10','--sample-footprint','--json'],13,900)]:
    out=base/name;out.mkdir(exist_ok=False)
    report={'identity':identity,'command':[str(binary),*args],'before':quiet_preflight(need),'passed':False}
    (out/'protocol.json').write_text(json.dumps(report,indent=2)+'\n')
    try:
        report['exit_code']=run_child(report['command'],env,out,timeout)
        report['after']=vm_snapshot()
        stdout=(out/'stdout.txt').read_text();stderr=(out/'stderr.txt').read_text()
        if name=='local-governor':
            report['receipt']=validate_receipt('governor',stdout+stderr,report['exit_code'])
        else:
            assert report['exit_code']==0
            result=json.loads(stdout.strip().splitlines()[-1])
            assert result['fits'] is True and result['aborted'] is None and result['prefill_tokens']==2048
            report['receipt']=check_memory(result,10)
        report['global_swap_deltas']=swap_deltas(report['before'],report['after'])
        report['passed']=True
    finally:
        (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'case':name,**{k:report[k] for k in ['passed','exit_code','receipt','global_swap_deltas']}}),flush=True)
