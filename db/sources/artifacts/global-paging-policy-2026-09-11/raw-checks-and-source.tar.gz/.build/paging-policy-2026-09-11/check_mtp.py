import json, os, sys
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'Tools'))
from context_qualification import quiet_preflight
from context_resource_gates import validate_receipt
from memory_gate import swap_deltas
from prefill_bench import run_child, vm_snapshot, digest
from serve_bench import verified_build

base = ROOT / '.build/paging-policy-2026-09-11'
out = base / 'local-mtp'; out.mkdir(exist_ok=False)
binary = base / 'local-build/candidate/slotstream'
identity = verified_build(binary)['identity']
assert all(digest(ROOT / name) == value for name, value in identity['source'].items())
env = {k: v for k, v in os.environ.items() if not k.startswith(('SLOTSTREAM_', 'SS_DEBUG_')) and k != 'BIN'}
command = [str(binary), 'mtp-check', '--memory-gb', '12', '--mtp', 'on', '--vision', 'on',
           '--image', 'Tools/assets/vision_test/secret1.jpg']
report = {'identity': identity, 'command': command, 'before': quiet_preflight(15),
          'constraint': 'All user apps and unrelated workloads remain untouched.', 'passed': False}
(out / 'protocol.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    report['exit_code'] = run_child(command, env, out, 1200)
    report['after'] = vm_snapshot()
    output = (out / 'stdout.txt').read_text() + (out / 'stderr.txt').read_text()
    report['receipt'] = validate_receipt('mtp-vision', output, report['exit_code'])
    report['global_swap_deltas'] = swap_deltas(report['before'], report['after'])
    report['passed'] = True
finally:
    (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['passed', 'exit_code', 'receipt', 'global_swap_deltas']}), flush=True)
