#!/usr/bin/env python3
"""Stock automatic-memory serving comparison, with bounded resources and complete scheduled rows."""
import collections,datetime,http.client,json,math,os,signal,socket,statistics,subprocess,threading,time
from pathlib import Path
from prefill_bench import preflight,vm_snapshot,digest
from serve_bench import request_body,exchange,wait_ready,stop_server,resource_exclusions,competing_jobs
from optimization_readiness import pressure_snapshot,require_normal
from thermal_readiness import observe
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
P=json.loads((HERE/'protocol.json').read_text());ACTIVE=None;DEADLINE=0;INTERRUPTED=False

def save(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def progress(**d):print(json.dumps({'utc':utc(),**d}),flush=True)

def models(owned=None):
    p=subprocess.run(['ps','-axo','pid=,comm='],capture_output=True,text=True,check=True,timeout=5)
    found=[]
    for line in p.stdout.splitlines():
        f=line.strip().split(None,1)
        if len(f)==2 and f[0].isdigit() and Path(f[1]).name in ['slotstream','llama-server','mlx_lm.server'] and int(f[0])!=owned:
            found.append({'pid':int(f[0]),'executable':Path(f[1]).name})
    return found

def signal_stop(sig,frame):
    global INTERRUPTED
    INTERRUPTED=True;raise KeyboardInterrupt(f'signal {sig}')
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,signal_stop)

def clean_env(depth,details=False):
    e={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))}
    e['SLOTSTREAM_DRAFT_DEPTH']=str(max(depth,1))
    if details:e['SLOTSTREAM_BENCH_DETAILS']='1'
    return e

def settle(minimum,owned=None):
    start=time.monotonic();last=time.monotonic();stable=None;lastswap=None;observations=[]
    while time.monotonic()-start < P['readiness_wait_limit_seconds']:
        if time.monotonic()>DEADLINE:raise TimeoutError('study deadline')
        vm=vm_snapshot();state=observe();pressure=pressure_snapshot()
        current=(vm['swapins'],vm['swapouts'])
        ready=state['ready'] and pressure['level']==1 and vm['reclaimable_bytes']>=P['minimum_live_headroom_gb']*1e9
        if not ready or current!=lastswap:stable=time.monotonic()
        if stable is None:stable=time.monotonic()
        observations.append({'elapsed':time.monotonic()-start,'vm':{k:v for k,v in vm.items() if k!='raw'},'conditions':state['conditions'],'pressure':pressure['name']})
        lastswap=current
        if ready and time.monotonic()-start>=minimum and time.monotonic()-stable>=P['quiet_observation_seconds']:
            return observations
        time.sleep(2)
    # Do not turn an unstable timing window into a model launch or a timed run.
    raise TimeoutError('readiness did not settle within five minutes')

def doctor(depth):
    c=[P['binary'],'doctor','--model',P['model'],'--max-ram-percent',str(P['max_ram_percent']),'--mtp','on' if depth else 'off','--json']
    r=subprocess.run(c,env=clean_env(depth),text=True,capture_output=True,timeout=15,check=True)
    p=json.loads(r.stdout)
    if p['source']!='auto' or p['mtp']!=bool(depth):raise ValueError('planner configuration mismatch')
    return p

def run_cell(out,r,prompt,depth,tokens,warm_tokens,minimum_outputs):
    global ACTIVE,INTERRUPTED
    cell=out/f'r{r}-{prompt}-d{depth}';cell.mkdir()
    row={'round':r,'prompt':prompt,'depth':depth,'started_utc':utc(),'valid':False,'completed':False}
    child=None;done=threading.Event();monitor=[];fatal=[];watcher=None
    progress(round=r,prompt=prompt,depth=depth,phase='waiting for launch readiness')
    try:
        row['launch_settle']=settle(P['cooldown_seconds'])
        others=models()
        if others:raise RuntimeError('another model process: '+str(others))
        row['doctor']=doctor(depth)
        required=row['doctor']['expected_peak_gb']+P['minimum_startup_headroom_gb']
        row['before_startup']=preflight(required);require_normal(pressure_snapshot())
        row['other_jobs_before']=competing_jobs()
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        cmd=[P['binary'],'serve','--model',P['model'],'--port',str(port),'--max-ram-percent',str(P['max_ram_percent']),
             '--mtp','on' if depth else 'off','--max-context',str(P['max_context'])]
        env=clean_env(depth,True);row['command']=cmd;row['environment']={k:v for k,v in env.items() if k.startswith('SLOTSTREAM_')}
        with (cell/'server.stdout').open('wb') as stdout,(cell/'server.stderr').open('wb') as stderr:
            launched=time.monotonic();child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            ACTIVE=child;row['pid']=child.pid
            def watch():
                last=time.monotonic();baseline=row['before_startup']['swapouts']
                while not done.wait(P['monitor_interval_seconds']):
                    try:
                        now=time.monotonic();vm=vm_snapshot();pressure=pressure_snapshot();state=observe()
                        x={'elapsed':now-launched,'scheduler_lateness_seconds':max(0,now-last-P['monitor_interval_seconds']),
                           'vm':{k:v for k,v in vm.items() if k!='raw'},'conditions':state['conditions'],'pressure':pressure['name']}
                        start=time.monotonic();conn=http.client.HTTPConnection('127.0.0.1',port,timeout=.75)
                        try:
                            conn.request('GET','/api/version');res=conn.getresponse();res.read(4096);x['metadata_status']=res.status
                        except Exception as e:x['metadata_error']=type(e).__name__
                        finally:conn.close()
                        x['metadata_seconds']=time.monotonic()-start;last=time.monotonic();monitor.append(x)
                        reason=None
                        if vm['swapouts']>baseline:reason='new global swapouts'
                        elif pressure['level']!=1:reason='OS memory pressure'
                        elif vm['reclaimable_bytes']<P['minimum_live_headroom_gb']*1e9:reason='lost minimum3GB live headroom'
                        elif state['conditions']['thermalState'] in ['serious','critical'] or state['conditions']['lowPowerModeEnabled']:reason='severe thermal or low-power state'
                        elif now>DEADLINE:reason='study deadline'
                        if reason:
                            fatal.append(reason)
                            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
                            return
                    except Exception as e:
                        fatal.append('monitor failed: '+str(e))
                        if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
                        return
            watcher=threading.Thread(target=watch,daemon=True);watcher.start();wait_ready(child,port)
            row['startup_seconds']=time.monotonic()-launched
            for phase,n in [('warmup',warm_tokens),('measured',tokens)]:
                if phase=='measured':
                    progress(round=r,prompt=prompt,depth=depth,phase='warmup finished; waiting for measurement readiness')
                    row['measurement_settle']=settle(P['warmup_settle_seconds'],child.pid)
                if child.poll() is not None:raise RuntimeError('server exited before '+phase)
                before=vm_snapshot();hostbefore=observe();jobsbefore=competing_jobs();marker=len(monitor)
                body=request_body(P|{'max_tokens':n},P['prompts'][prompt],images=[])
                (cell/(phase+'-request.json')).write_bytes(body)
                result,wire=exchange(port,body,P['timeout_per_request'],allow_complete_prompt=True)
                after=vm_snapshot();hostafter=observe();jobsafter=competing_jobs()
                (cell/(phase+'.ndjson')).write_bytes(wire);save(cell/(phase+'.json'),result)
                m=result['metrics'];s=m['stats']
                reasons=resource_exclusions(s,{'maximum_sampled_footprint_bytes':P['maximum_footprint_bytes'],'require_nominal_power_state':True})
                gb,ga=s.get('generatorVMBefore'),s.get('generatorVMAfter')
                if not isinstance(gb,dict) or not isinstance(ga,dict):raise ValueError('native resource observations missing')
                if any(before[k]!=after[k] or gb[k]!=ga[k] for k in ['swapins','swapouts']):reasons.append('swap activity during request')
                if not hostbefore['ready'] or not hostafter['ready'] or any(x['conditions']['thermalState']!='nominal' or x['conditions']['lowPowerModeEnabled'] for x in monitor[marker:]):reasons.append('non-nominal thermal/power observation')
                if jobsbefore or jobsafter:reasons.append('known background storage/build job')
                if s['decodeTokens']<(n if phase=='warmup' else minimum_outputs):reasons.append('output shorter than declared workload')
                if s.get('memoryPressureCancelled',False) or s.get('finishReason') not in ['length','stop']:reasons.append('generation did not complete normally')
                if m['effective_mtp']!=bool(depth):raise ValueError('effective MTP mismatch')
                if depth and s.get('verifyPasses',0)==0:raise ValueError('MTP did not run')
                if depth and s['draftedTokens']!=depth*s['verifyPasses']:raise ValueError('effective depth differs from fixed requested depth')
                if not depth and s.get('draftedTokens',0)!=0:raise ValueError('plain arm drafted tokens')
                row[phase]={'before':before,'after':after,'host_before':hostbefore,'host_after':hostafter,'jobs_before':jobsbefore,'jobs_after':jobsafter,
                            'valid':not reasons,'exclusions':reasons,**result}
                if any('footprint' in reason for reason in reasons):fatal.append('physical footprint ceiling exceeded')
                if fatal:raise RuntimeError('; '.join(fatal))
            row['valid']=row['measured']['valid'];row['completed']=True
            row['same_output_warm_and_measured']=row['warmup']['metrics']['output_ids']==row['measured']['metrics']['output_ids']
    except KeyboardInterrupt as e:INTERRUPTED=True;row['error']=str(e)
    except Exception as e:row['error']=type(e).__name__+': '+str(e)
    finally:
        done.set()
        if child is not None:stop_server(child);row['process_stopped']=child.poll() is not None;row['process_exit_code']=child.poll()
        ACTIVE=None
        if watcher:watcher.join(timeout=5)
        row['monitor']=monitor;row['fatal']=fatal;row['finished_utc']=utc();save(cell/'result.json',row)
        with (out/'results.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    report={k:row[k] for k in ['round','prompt','depth','valid','completed']}
    if 'error' in row:report['error']=row['error']
    if 'measured' in row:
        s=row['measured']['metrics']['stats'];report.update(tps=s['decodeTokens']/s['decodeSeconds'],exclusions=row['measured']['exclusions'],
                pool=row['measured']['metrics']['effective_pool_slots'],peak_gb=s['sampledFootprint']['peakBytes']/1e9,
                accepted=s['acceptedDrafts'],drafted=s['draftedTokens'])
    progress(phase='cell complete',**report);return row

def select_finalists(rows):
    norm={d:collections.defaultdict(list) for d in P['depths']}
    blocks=collections.defaultdict(list)
    for row in rows:
        if row['valid']:blocks[(row['round'],row['prompt'])].append(row)
    for block in blocks.values():
        if len(block)<2:continue
        rates=[r['measured']['metrics']['stats']['decodeTokens']/r['measured']['metrics']['stats']['decodeSeconds'] for r in block]
        denominator=math.prod(rates)**(1/len(rates))
        for row,rate in zip(block,rates):norm[row['depth']][row['prompt']].append(rate/denominator)
    scores={str(d):{'coverage':len(ps),'workloads':{p:statistics.median(v) for p,v in ps.items()},
                   'score':math.prod(statistics.median(v) for v in ps.values())**(1/len(ps)) if ps else None} for d,ps in norm.items()}
    complete=[d for d in P['depths'] if scores[str(d)]['coverage']==len(P['prompts'])]
    ranked=sorted(complete,key=lambda d:(-scores[str(d)]['score'],d))
    selected=ranked[:2] if len(ranked)>=2 else [1,2]
    return {'scores':scores,'ranked_complete_coverage':ranked,'selected':selected,'fallback':len(ranked)<2}

def main():
    global DEADLINE
    DEADLINE=time.monotonic()+P['deadline_seconds']
    out=HERE/'study';out.mkdir()
    if digest(Path(P['binary']))!=P['binary_sha256']:raise ValueError('binary changed')
    save(HERE/'freeze.json',{'protocol':P,'files':{p.name:digest(p) for p in HERE.glob('*.py')},'protocol_sha256':digest(HERE/'protocol.json')})
    rows=[]
    try:
        prompts=list(P['prompts'])
        for r,order in enumerate(P['orders'],1):
            orderp=prompts[(r-1)%3:]+prompts[:(r-1)%3]
            for prompt in orderp:
                for depth in order:
                    if INTERRUPTED or time.monotonic()>DEADLINE:return 1
                    rows.append(run_cell(out,r,prompt,depth,P['max_tokens'],P['warm_tokens'],P['max_tokens']))
        choice=select_finalists(rows);save(HERE/'finalist-selection.json',choice);progress(phase='finalists selected',**choice)
        out=HERE/'confirmation';out.mkdir()
        for r,prompt in enumerate(P['confirmation']['prompts'],1):
            order=choice['selected'] if r%2 else list(reversed(choice['selected']))
            for depth in order:
                if INTERRUPTED or time.monotonic()>DEADLINE:return 1
                run_cell(out,r,prompt,depth,P['confirmation']['max_tokens'],P['confirmation']['warm_tokens'],P['confirmation']['minimum_outputs'])
        return 0
    finally:
        if ACTIVE:stop_server(ACTIVE)
        save(HERE/'after.json',{'utc':utc(),'vm':vm_snapshot(),'conditions':observe(),'remaining_models':models(),'interrupted':INTERRUPTED})

if __name__=='__main__':raise SystemExit(main())
