#!/usr/bin/env python3
"""Post-run integrity and resource audit; no inference and no reruns."""
import collections, hashlib, json, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def rows(name):
    p = ROOT / name / 'results.jsonl'
    return [json.loads(line) for line in p.read_text().splitlines()] if p.exists() else []

p = json.loads((ROOT / 'protocol.json').read_text())
freeze = json.loads((ROOT / 'freeze.json').read_text())
short, long = rows('study'), rows('confirmation')
all_rows = short + long
measured = [r for r in all_rows if 'measured' in r]
samples = [s for r in all_rows for s in r['monitor']]
groups = collections.defaultdict(list)
for r in short:
    if 'measured' in r:
        groups[f"{r['prompt']}-d{r['depth']}"].append(r)
out = {
    'primary_expected': 48, 'primary_rows': len(short),
    'confirmation_expected': 6, 'confirmation_rows': len(long),
    'primary_unique_cells': len({(r['round'], r['prompt'], r['depth']) for r in short}),
    'all_rows_completed': all(r['completed'] for r in all_rows),
    'all_owned_children_stopped': all(r.get('process_stopped') for r in all_rows if 'pid' in r),
    'all_frozen_drivers_exact': all(digest(ROOT / name) == sha for name, sha in freeze['files'].items()),
    'protocol_exact': digest(ROOT / 'protocol.json') == freeze['protocol_sha256'],
    'executed_binary_exact': digest(Path(p['binary'])) == p['binary_sha256'],
    'installed_binary_exact': digest(Path.home() / '.slotstream/bin/slotstream') == p['binary_sha256'],
    'installed_metal_exact': digest(Path.home() / '.slotstream/bin/mlx.metallib') == p['metal_sha256'],
    'watchdog_safety_stops': [{'round':r['round'], 'prompt':r['prompt'], 'depth':r['depth'], 'fatal':r['fatal']} for r in all_rows if r['fatal']],
    'sampled_pressure_states': sorted({s['pressure'] for s in samples}),
    'sampled_thermal_states': sorted({s['conditions']['thermalState'] for s in samples}),
    'sampled_low_power_values': sorted({s['conditions']['lowPowerModeEnabled'] for s in samples}),
    'minimum_sampled_reclaimable_gb': min((s['vm']['reclaimable_bytes']/1e9 for s in samples), default=None),
    'memory_pressure_cancellations': sum(r['measured']['metrics']['stats'].get('memoryPressureCancelled',False) for r in measured),
    'output_tokens_by_phase': {phase:sorted({r['measured']['metrics']['stats']['decodeTokens'] for r in rs if 'measured' in r}) for phase,rs in [('primary',short),('confirmation',long)]},
    'short_warmup_equals_measured': all(r.get('same_output_warm_and_measured') for r in short if 'measured' in r),
    'short_token_paths_by_setting': {name:len({tuple(r['measured']['metrics']['output_ids']) for r in rs}) for name,rs in groups.items()},
    'primary_acceptance_by_setting': {name:{
        'observations': len(rs),
        'accepted_drafted_pairs': sorted({(r['measured']['metrics']['stats']['acceptedDrafts'],r['measured']['metrics']['stats']['draftedTokens']) for r in rs}),
        'verify_passes': sorted({r['measured']['metrics']['stats']['verifyPasses'] for r in rs}),
    } for name,rs in groups.items()},
}
after = ROOT / 'after.json'
if after.exists():
    final = json.loads(after.read_text())
    out['final_remaining_models'] = final['remaining_models']
    out['study_swapin_pages_delta'] = final['vm']['swapins'] - p['before']['swapins']
    out['study_swapout_pages_delta'] = final['vm']['swapouts'] - p['before']['swapouts']
    out['interrupted'] = final['interrupted']
(ROOT / 'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
