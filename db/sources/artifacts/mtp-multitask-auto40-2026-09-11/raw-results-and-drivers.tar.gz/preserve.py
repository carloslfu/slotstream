#!/usr/bin/env python3
"""Capture completed study evidence before writing its derived brain record."""
import datetime, fcntl, hashlib, io, json, os, shutil, subprocess, tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
DEST = REPO / 'db/sources/artifacts/mtp-multitask-auto40-2026-09-11'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

assert (HERE / 'after.json').exists(), 'Driver has not finished'
audit = json.loads((HERE / 'audit.json').read_text())
assert audit['primary_rows'] == 48 and audit['confirmation_rows'] == 6
assert audit['all_owned_children_stopped'] and audit['protocol_exact']
assert audit['all_frozen_drivers_exact'] and audit['executed_binary_exact']
assert audit['installed_binary_exact'] and audit['installed_metal_exact']
rows = [json.loads(s) for phase in ('study', 'confirmation')
        for s in (HERE / phase / 'results.jsonl').read_text().splitlines()]
owned = {r['pid'] for r in rows if 'pid' in r}
live = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,comm='], text=True)
owned_live = []
models = []
for line in live.splitlines():
    fields = line.strip().split(None, 2)
    if len(fields) != 3:
        continue
    pid, ppid, comm = fields
    if int(pid) in owned:
        owned_live.append({'pid':int(pid), 'parent_pid':int(ppid), 'executable':comm})
    if Path(comm).name in ('slotstream', 'llama-server', 'mlx_lm.server'):
        models.append({'pid':int(pid), 'executable':Path(comm).name})
assert not owned_live, owned_live
with open(f'/tmp/slotstream-model-{os.getuid()}.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    lock_free = True
identity_path = HERE.parent / 'mtp-depth-study-20260911/binary/build-identity.json'
identity = json.loads(identity_path.read_text())
source_mismatches = [name for name, expected in identity['source'].items()
                     if not (REPO / name).exists() or sha((REPO / name).read_bytes()) != expected]
save(HERE / 'cleanup-proof.json', {
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'owned_model_pid_count':len(owned), 'owned_model_pids_still_live':owned_live,
    'remaining_models':models, 'native_model_lock_free':lock_free,
    'compiled_identity_file_count':len(identity['source']),
    'compiled_identity_mismatches':source_mismatches,
    'installed_binary_and_metal_exact':audit['installed_binary_exact'] and audit['installed_metal_exact'],
    'git_head_after_study':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'instrumentation_scope':'Existing BENCH_DETAILS diagnostics only in terminated test-child environments; no production setting or source changed.',
})
DEST.mkdir(parents=True, exist_ok=False)
files = sorted(p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
members = {str(p.relative_to(HERE)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
archive = DEST / 'raw-results-and-drivers.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for path in files:
        tar.add(path, arcname=str(path.relative_to(HERE)), recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    checked = {}
    for member in tar.getmembers():
        data = tar.extractfile(member).read()
        checked[member.name] = {'bytes':len(data), 'sha256':sha(data)}
assert checked == members, 'Archive round trip changed evidence'
for name in ('analysis.json', 'audit.json', 'protocol.json', 'freeze.json',
             'finalist-selection.json', 'after.json', 'cleanup-proof.json'):
    shutil.copyfile(HERE / name, DEST / name)
shutil.copyfile(identity_path, DEST / 'build-identity.json')
save(DEST / 'manifest.json', {
    'study':'mtp-multitask-auto40-v1',
    'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},
    'members':members, 'all_members_decompressed_and_sha256_verified':True,
    'individual_artifacts':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
                            for p in sorted(DEST.iterdir()) if p.name != archive.name},
})
print(json.dumps({'destination':str(DEST),'members':len(members),'archive_bytes':archive.stat().st_size,
                  'source_mismatches':source_mismatches,'remaining_models':models},indent=2))
