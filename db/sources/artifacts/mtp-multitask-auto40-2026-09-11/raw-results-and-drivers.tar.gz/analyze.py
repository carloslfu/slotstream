#!/usr/bin/env python3
"""Offline analysis of all scheduled multitasking measurements; no model calls."""
import collections,json,math,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
med=statistics.median

def rows_at(name):
    p=ROOT/name/'results.jsonl'
    return [json.loads(s) for s in p.read_text().splitlines()] if p.exists() else []
def stats(r,phase='measured'):return r[phase]['metrics']['stats']
def rate(r):s=stats(r);return s['decodeTokens']/s['decodeSeconds']
def gm(xs):return math.prod(xs)**(1/len(xs)) if xs else None
def median(xs):return med(xs) if xs else None
def percentile(xs,q):
    if not xs:return None
    a=sorted(xs);pos=(len(a)-1)*q;lo=int(pos);hi=min(lo+1,len(a)-1)
    return a[lo]+(a[hi]-a[lo])*(pos-lo)

def summary(rs):
    eligible=[r for r in rs if r['valid']]
    measured=[r for r in rs if 'measured' in r]
    samples=[m for r in rs for m in r['monitor']]
    return {'scheduled_attempts':len(rs),'completed_measured':len(measured),'speed_eligible':len(eligible),
     'median_tps':median([rate(r) for r in eligible]),'individual_clean_tps':[rate(r) for r in eligible],
     'median_client_seconds':median([r['measured']['client_seconds'] for r in eligible]),
     'median_first_visible_seconds':median([r['measured']['first_visible_text_seconds'] for r in eligible]),
     'median_expert_MB_per_output':median([stats(r)['decodeReadBytes']/stats(r)['decodeTokens']/1e6 for r in eligible]),
     'median_acceptance':median([stats(r)['acceptedDrafts']/stats(r)['draftedTokens'] for r in eligible if stats(r)['draftedTokens']]),
     'median_outputs_after_initial_sample_per_verify':median([(stats(r)['decodeTokens']-1)/stats(r)['verifyPasses'] for r in eligible if stats(r)['verifyPasses']]),
     'median_draft_fraction':median([stats(r)['draftSeconds']/stats(r)['decodeSeconds'] for r in eligible]),
     'median_verify_fraction':median([stats(r)['verifySeconds']/stats(r)['decodeSeconds'] for r in eligible]),
     'median_reconciliation_fraction':median([stats(r)['reconciliationSeconds']/stats(r)['decodeSeconds'] for r in eligible]),
     'pool_slots_all_measured':sorted({r['measured']['metrics']['effective_pool_slots'] for r in measured}),
     'prefill_chunks_all_measured':sorted({r['measured']['metrics']['effective_prefill_chunk'] for r in measured}),
     'peak_physical_footprint_gb_all_phases':max([r[phase]['metrics']['stats']['sampledFootprint']['peakBytes']/1e9 for r in rs for phase in ['warmup','measured'] if phase in r],default=None),
     'metadata_probe_p95_seconds':percentile([m['metadata_seconds'] for m in samples],.95),
     'metadata_probe_errors':sum('metadata_error' in m or m.get('metadata_status')!=200 for m in samples),
     'scheduler_lateness_p95_seconds':percentile([m['scheduler_lateness_seconds'] for m in samples],.95),
     'unique_measured_output_sequences':len({tuple(r['measured']['metrics']['output_ids']) for r in measured}),
     'generation_failures':[{'round':r['round'],'prompt':r['prompt'],'depth':r['depth'],'error':r.get('error'),'fatal':r.get('fatal')} for r in rs if not r['completed']],
     'exclusions':[{'round':r['round'],'prompt':r['prompt'],'depth':r['depth'],'reasons':r.get('measured',{}).get('exclusions'),'error':r.get('error')} for r in rs if not r['valid']]}

def pair_table(rows,b,c):
    lookup={(r['round'],r['prompt'],r['depth']):r for r in rows}
    workloads={}
    for prompt in P['prompts']:
        pairs=[]
        for rnd in range(1,5):
            x,y=lookup.get((rnd,prompt,b)),lookup.get((rnd,prompt,c))
            if not x or not y or not x['valid'] or not y['valid']:continue
            smx,smy=stats(x),stats(y)
            pairs.append({'round':rnd,'ratio':rate(y)/rate(x),'baseline_tps':rate(x),'candidate_tps':rate(y),
                'client_speed_ratio':x['measured']['client_seconds']/y['measured']['client_seconds'],
                'baseline_pool':x['measured']['metrics']['effective_pool_slots'],'candidate_pool':y['measured']['metrics']['effective_pool_slots'],
                'output_ids_equal':x['measured']['metrics']['output_ids']==y['measured']['metrics']['output_ids'],
                'read_bytes_ratio':smy['decodeReadBytes']/smx['decodeReadBytes'] if smx['decodeReadBytes'] else None})
        workloads[prompt]={'count':len(pairs),'median_ratio':median([p['ratio'] for p in pairs]),'pairs':pairs}
    ratios=[v['median_ratio'] for v in workloads.values() if v['median_ratio'] is not None]
    enough=all(v['count']>=2 for v in workloads.values())
    overall=gm(ratios) if len(ratios)==3 else None
    return {'baseline_depth':b,'candidate_depth':c,'workloads':workloads,'enough_pairs':enough,'equal_workload_geomean_ratio':overall,
            'passes_primary_change_rule':bool(enough and overall>=1.05 and min(ratios)>=.95)}

rs=rows_at('study');long=rows_at('confirmation')
result={'primary_planned':48,'confirmation_planned':6,'primary':summary(rs),'confirmation':summary(long),
 'per_workload':{p:{str(d):summary([r for r in rs if r['prompt']==p and r['depth']==d]) for d in P['depths']} for p in P['prompts']},
 'comparisons':{f'{b}-to-{c}':pair_table(rs,b,c) for b in P['depths'] for c in P['depths'] if b!=c},
 'all_started_processes_stopped':all(r.get('process_stopped',False) for r in rs+long if 'pid' in r)}
choice=ROOT/'finalist-selection.json'
if choice.exists():
    result['finalist_selection']=json.loads(choice.read_text());a,b=result['finalist_selection']['selected']
    result['long_comparison']=pair_table(long,a,b)
    longpairs=[p for w in result['long_comparison']['workloads'].values() for p in w['pairs']]
    result['long_median_ratio']=median([p['ratio'] for p in longpairs]);result['long_clean_pairs']=len(longpairs)
    result['qualified_default_candidates']=[]
    if 1 in [a,b]:
        candidate=b if a==1 else a
        pair=pair_table(long,1,candidate)
        lp=[p['ratio'] for w in pair['workloads'].values() for p in w['pairs']]
        if result['comparisons'][f'1-to-{candidate}']['passes_primary_change_rule'] and len(lp)>=2 and med(lp)>=1.03:
            result['qualified_default_candidates']=[candidate]
(ROOT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'primary':{k:result['primary'][k] for k in ['scheduled_attempts','completed_measured','speed_eligible']},
 'confirmation':{k:result['confirmation'][k] for k in ['scheduled_attempts','completed_measured','speed_eligible']},
 'per_workload':{p:{d:{'n':v['speed_eligible'],'tps':v['median_tps']} for d,v in ds.items()} for p,ds in result['per_workload'].items()},
 'vs_depth1':{str(c):{k:result['comparisons'][f'1-to-{c}'][k] for k in ['enough_pairs','equal_workload_geomean_ratio','passes_primary_change_rule']} for c in [0,2,3]},
 'finalists':result.get('finalist_selection'),'qualified_default_candidates':result.get('qualified_default_candidates')},indent=2))
