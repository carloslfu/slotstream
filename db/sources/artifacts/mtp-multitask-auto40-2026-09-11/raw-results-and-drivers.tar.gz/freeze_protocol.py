import json,sys,subprocess
from pathlib import Path
from prefill_bench import vm_snapshot
from thermal_readiness import observe
root=Path(__file__).resolve().parent
old=json.loads((root.parent/'mtp-depth-study-20gb-20260911/protocol.json').read_text())
p={k:old[k] for k in ['binary','binary_sha256','metal_sha256','model','model_identity','prompts','seed','raw','think','sampling']}
p.update(id='mtp-multitask-auto40-v1',max_ram_percent=40,depths=[0,1,2,3],rounds=4,
 orders=[[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]],max_tokens=128,warm_tokens=128,max_context=32768,
 prefix_cache=True,elastic=True,prefill_chunk='automatic',cooldown_seconds=20,warmup_settle_seconds=10,
 quiet_observation_seconds=5,readiness_wait_limit_seconds=300,timeout_per_request=180,deadline_seconds=7200,
 minimum_startup_headroom_gb=3,minimum_live_headroom_gb=3,
 maximum_footprint_bytes=int(.40*int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True))),
 monitor_interval_seconds=2,
 primary_selection='Speed-eligible means complete native metrics, zero global swap changes over client/native generation interval, nominal sampled thermal state, low-power off, physical footprint within40% physical RAM and no known storage/build job in the measured window. Other normal apps remain open. Safety stop kills only owned model on new swapouts, OS warning/critical, <3GB reclaimable, severe thermal/low power or deadline; preserve row, wait for recovery and continue next scheduled cell. No data-futility early stop.',
 rank='Within each round/workload block with at least2 speed-eligible depths, divide throughput by their geometric mean; rank by geometric mean of workload median normalized ratios. Require observations in all3 workloads to rank ahead of incomplete coverage. This ranks exploratory finalists, not proven model quality.',
 default_change='At least2 speed-eligible same-round pairs per workload versus depth1; >=5% equal-workload geometric mean of per-workload median paired throughput ratios; no workload median slowdown >5%. Final confirmation must have at least2 clean pairs and median candidate/baseline throughput ratio >=1.03. Otherwise report fastest observed candidate with uncertainty and retain default.',
 confirmation={'runs':6,'max_tokens':512,'warm_tokens':128,'prompts':['prose','code','reasoning'],
  'selection':'Top2 exploratory ranked depths. If ranking lacks3-workload coverage, use predeclared1 and2 fallback. Exactlyone longer response per finalist per workload, each in a fresh server after128-token warmup; alternate finalist order by workload. If depth1 is absent from finalists, no global default change is qualified by this study.',
  'minimum_outputs':384},
 scope='Same automatic40% RAM policy, with ordinary user apps left open. Effective pool, prefill and prefix retention may differ as availability changes; record these. Generated outputs may differ acrossdepths. Request/scheduler responsiveness proxies do not certify other apps UI responsiveness. No quality or long-context benchmark.',
 before=vm_snapshot(),conditions_before=observe(),git_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
(root/'protocol.json').write_text(json.dumps(p,indent=2)+'\n')
print('Frozen',p['id'],'physical footprint ceiling',p['maximum_footprint_bytes'])
