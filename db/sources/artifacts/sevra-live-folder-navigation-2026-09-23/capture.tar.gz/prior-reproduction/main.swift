import Foundation
import SevraRuntime
import Slotstream

func call(_ session: SourceSession, _ name: String, _ arguments: [String: JSONValue] = [:]) throws -> [String: Any] {
    let result = try session.execute(ProposedTool(name: name, arguments: arguments), cancellation: Cancellation())
    return try JSONSerialization.jsonObject(with: Data(result.utf8)) as! [String: Any]
}
func check(_ value: Bool, _ label: String) throws {
    if !value { throw NSError(domain: "SourceAudit", code: 1, userInfo: [NSLocalizedDescriptionKey: label]) }
    print("CONFIRMED: " + label)
}
let root = FileManager.default.temporaryDirectory.appendingPathComponent("sevra-live-probe-" + UUID().uuidString)
do {
    let fm = FileManager.default
    try fm.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? fm.removeItem(at: root) }
    let folder = root.appendingPathComponent("live")
    try fm.createDirectory(at: folder, withIntermediateDirectories: true)
    let existing = folder.appendingPathComponent("existing.txt")
    try Data("original content\n".utf8).write(to: existing)
    let session = SourceSession()
    _ = try session.attach(url: folder, access: .read)
    let before = try call(session, "source.list")
    let id = (before["files"] as! [[String: Any]])[0]["id"] as! String
    _ = try call(session, "source.read", ["id": .string(id)])
    try Data("updated content\n".utf8).write(to: existing, options: .atomic)
    let updated = try call(session, "source.read", ["id": .string(id)])
    try check((updated["content"] as? String) == "updated content\n", "reading a registered path observes an atomic editor replacement")
    try Data("NEW_FILE_CANARY\n".utf8).write(to: folder.appendingPathComponent("new.txt"))
    session.beginJob()
    let after = try call(session, "source.list")
    let found = try call(session, "source.search", ["query": .string("NEW_FILE_CANARY")])
    try check((after["total"] as? Int) == 1 && (found["matches"] as! [[String: Any]]).isEmpty, "new files stay absent from list and search, even in a new job")
    try fm.moveItem(at: existing, to: folder.appendingPathComponent("renamed.txt"))
    let renamed = try call(session, "source.list")
    try check((renamed["files"] as! [[String: Any]])[0]["path"] as? String == "existing.txt", "listing retains the old filename after a rename")
    var missing = false
    do { _ = try call(session, "source.read", ["id": .string(id)]) }
    catch { missing = error.localizedDescription.contains("missing") }
    try check(missing, "reading the renamed file's old ID fails instead of discovering its new path")

    let many = root.appendingPathComponent("many")
    try fm.createDirectory(at: many, withIntermediateDirectories: true)
    for n in 0..<SourceLimits.files { try Data().write(to: many.appendingPathComponent("\(n).bin")) }
    let accepted = SourceSession()
    let info = try accepted.attach(url: many, access: .read)
    try check(info.files == SourceLimits.files, "2,000 regular files attach, including unsupported binary extensions")
    try Data().write(to: many.appendingPathComponent("extra.bin"))
    let rejected = SourceSession()
    var refused = false
    do { _ = try rejected.attach(url: many, access: .read) }
    catch { refused = error.localizedDescription.contains("more than 2000 files") }
    try check(refused && rejected.infos.isEmpty && rejected.groups.isEmpty, "2,001 files reject the entire attachment and leave no source tool groups")

    let lines = root.appendingPathComponent("lines.txt")
    try Data((0..<25).map { "needle match \($0)\n" }.joined().utf8).write(to: lines)
    let searchSession = SourceSession()
    _ = try searchSession.attach(url: lines, access: .read)
    let first = try call(searchSession, "source.search", ["query": .string("needle")])
    let next = first["next"] as! Int
    let second = try call(searchSession, "source.search", ["query": .string("needle"), "offset": .int(next)])
    try check((first["matches"] as! [[String: Any]]).count == 20 && (second["matches"] as! [[String: Any]]).isEmpty, "search continuation skips the remaining 5 matches in a 25-match file")
    print("Audit finished. These checks characterize current behavior; they do not implement a fix.")
} catch {
    fputs("AUDIT FAILED: \(error)\n", stderr)
    exit(1)
}
