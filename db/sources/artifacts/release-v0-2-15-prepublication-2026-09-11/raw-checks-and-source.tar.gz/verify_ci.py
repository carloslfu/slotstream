import json,os,sys,subprocess,time,signal,hashlib
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'.build/release-v0.2.15'; OUT=BASE/'ci-model-acceptance';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'Tools'))
from context_qualification import quiet_preflight
from prefill_bench import digest,terminate_child_tree,vm_snapshot
from serve_bench import verified_build
BINARY=BASE/'ci-candidate/slotstream'
identity=verified_build(BINARY)["identity"]
assert subprocess.check_output([str(BINARY),'--version'],text=True).strip()=='0.2.15'
assert all(digest(ROOT/f)==h for f,h in identity['source'].items())
DRIVERS=['Tools/verify.sh','Tools/prefill_bench.py','Tools/context_qualification.py','Tools/memory_gate.py','Tools/long_context_gate.py','Tools/api_robustness.sh','Tools/vision_serving.py','Tools/quality_probe.sh']
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k not in ('BIN',)}
env.update(SLOTSTREAM_TEST_BINARY=str(BINARY),SLOTSTREAM_VERIFY_OUT=str(OUT/'checks'))
result={'binary':str(BINARY),'identity':identity,'driver_sha256':{f:digest(ROOT/f) for f in DRIVERS},'command':['bash','Tools/verify.sh'],'before':quiet_preflight(20.5),'started_at':time.time()}
(OUT/'protocol.json').write_text(json.dumps(result,indent=2)+'\n')
print('Starting complete original model acceptance against the exact CI candidate',flush=True)
with (OUT/'verify.log').open('wb') as log:
 child=subprocess.Popen(result['command'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 result['pid']=child.pid
 try:result['exit_code']=child.wait(timeout=3600)
 finally:
  # End any descendants even if the top-level script failed after spawning.
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  if child.poll() is None:terminate_child_tree(child)
result['after']=vm_snapshot();result['elapsed_seconds']=time.time()-result['started_at']
for f in ['/tmp/ssv_long.txt','/tmp/ssv_longmem.json','/tmp/ssv_longmem.txt','/tmp/ssv_longmem.err','/tmp/ssv_mem.json','/tmp/ssv_mem.txt','/tmp/ssv_mem.err','/tmp/ssv_ctx.json','/tmp/ssv_q.log','/tmp/ssv-vision-serve.log']:
 p=Path(f)
 if p.exists():(OUT/p.name).write_bytes(p.read_bytes())
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['identity','before','after','driver_sha256']}),flush=True)
sys.exit(result['exit_code'])
