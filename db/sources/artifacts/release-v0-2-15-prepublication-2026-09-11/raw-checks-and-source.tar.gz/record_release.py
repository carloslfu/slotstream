import hashlib, json, re, subprocess, tarfile
from pathlib import Path
ROOT=Path.cwd(); BASE=ROOT/'.build/release-v0.2.15'; DB=ROOT/'db'
ART=DB/'sources/artifacts/release-v0-2-15-2026-09-11'; ART.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
publication=load(BASE/'publication-verification.json'); installed=load(BASE/'installed-acceptance/result.json'); cleanup=load(BASE/'cleanup.json')
initial=load(BASE/'ci-model-acceptance/result.json'); retry=load(BASE/'targeted-reruns/results.json')
assert installed['e2e_exit_code']==0 and installed['server_stopped'] and cleanup['model_lock_free'] and not cleanup['model_processes']
assert cleanup['apps_restored']==['com.google.Chrome','com.electron.wispr-flow']
assert 'passed 23, failed 2' in (BASE/'ci-model-acceptance/verify.log').read_text()
assert re.search(r'passed 31, failed 0|31 passed, 0 failed',(BASE/'installed-acceptance/e2e.log').read_text())
assert all(any(r['gate']==g and r['passed'] for r in retry) for g in ['elastic','mtp'])
assert publication['matches_ci_archive'] and publication['identity_matches_ci'] and publication['attestation_verified']
stats=installed['default_probe']['metrics']['stats']
assert stats['draftedTokens']==2*stats['verifyPasses'] and stats['verifyPasses']>0
summary={'release':'v0.2.15','source_commit':'ee4d1af5b3d63c2b5670c814b40b25432415eb46','ci_run':34592671081,'publication':publication,'initial_model_gates':{'passed':23,'failed':2},'targeted_results':[{'gate':r['gate'],'attempt':r['attempt'],'passed':r['passed']} for r in retry],'unique_original_model_gates_qualified':25,'installed_e2e_passed':31,'default_probe':{'drafted_tokens':stats['draftedTokens'],'verify_passes':stats['verifyPasses']},'cleanup':cleanup,'performance_claim':'No new throughput comparison; correctness and bounded-memory acceptance only.'}
(BASE/'acceptance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
excluded_names={'slotstream','mlx.metallib','slotstream-arm64.tar.gz'}
files=[p for p in BASE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in excluded_names and p.suffix!='.pyc']
archive=ART/'raw-checks-and-source.tar.gz'; inventory=[]
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):
  name=str(p.relative_to(BASE));tar.add(p,arcname=name,recursive=False);inventory.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())=={r['path'] for r in inventory}
 for row in inventory:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
manifest={'archive':archive.name,'archive_sha256':sha(archive),'files':inventory,'roundtrip_verified':True,'excluded':'Compiled executable, metallib, duplicate downloadable release archives and Python bytecode; exact hashes, build identity and reconstructible source are preserved.'}
(ART/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(ART/'acceptance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
def db(args):
 r=subprocess.run(['dbmd']+args+['--json'],cwd=DB,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
 return json.loads(r.stdout)
def write(path,typ,title,body,fields):
 temp=BASE/(Path(path).stem+'-body.md');temp.write_text(body)
 args=['write',path,'--type',typ,'--summary',title,'--body-file',str(temp)]
 for k,v in {'title':title,**fields}.items():args+=['--fm',f'{k}={v}']
 out=db(args); actual=out['written']
 if actual!=path:db(['rename',actual,path])
 return path.removesuffix('.md')
# Runs use sources/runs/YYYY/MM, four levels below the store root.
artifact_link='[raw archive](../../../artifacts/release-v0-2-15-2026-09-11/raw-checks-and-source.tar.gz)'
common={'tool':'Slotstream release qualification','command':'Original Tools/verify.sh; unchanged targeted native gates; exact CI publication; public installer; Tools/e2e_release.sh','binary':publication['binary_sha256'],'machines':'[[records/machines/macbook-pro-m5-pro-48gb]], [[records/machines/github-actions-macos-26]]','captured_at':'2026-09-11'}
failed_body=f'''The complete original model battery returned 23 passed and two failed against the exact CI candidate. Governor and combined MTP/vision stopped on native global-swap guards. The governor observed three swap-ins; the MTP interval observed four swap-ins and 32 swap-outs. Both observed process peaks remained below their explicit targets. These intervals remain failed and are excluded from resource and performance qualification. System-wide counters do not identify the responsible process. All original logs and memory records are preserved in the {artifact_link}, under `ci-model-acceptance/`. Any additional targeted failures remain in `targeted-reruns/`. The preversion long-prompt attempt with eight swap-ins is also preserved; its later clean pass is a distinct identity from this CI binary. A wrapper setup error before that model launch is retained as a harness error, not a product failure.\n'''
failed=write('sources/runs/2026/09/2026-09-11-release-0-2-15-excluded-intervals.md','run','v0.2.15 original resource exclusions retained',failed_body,{**common,'discarded':'true'})
good_body=f'''Published and installed {publication['url']} from commit `{summary['source_commit']}` after complete successful main CI 34592671081. Public archive SHA-256 `{publication['archive_sha256']}` matches the tested CI archive exactly; GitHub attestation and reconstructed source passed. The 23 valid original gates plus both unchanged targeted passes qualify all 25 unique original model gates. Installed-release API acceptance passed all 31 checks. A no-depth-override request recorded {stats['draftedTokens']} drafts over {stats['verifyPasses']} verification passes. This proves the configured depth and is not a performance comparison.\n\nBoth authorized apps were already closed when inspected, remained closed during tests and were reopened afterward. All owned model processes exited and the native lock was free. Test details were confined to child environments.\n\nThe {artifact_link} preserves the closed test logs, failed intervals, commands, readiness observations, identities, CI and publication receipts, installed response wires, restoration and cleanup. Its manifest has {len(inventory)} byte-verified members and archive SHA-256 `{manifest['archive_sha256']}`. Compiled binaries and Metal libraries remain downloadable release artifacts, bound by exact hashes; reconstructible build source is included. The initial failed intervals remain in [[{failed}]].\n'''
good=write('sources/runs/2026/09/2026-09-11-release-0-2-15-publication-and-acceptance.md','run','v0.2.15 published artifact and complete local acceptance',good_body,{**common,'discarded':'false'})
body=f'''**v0.2.15 is published and installed. Complete main CI passed; all 25 original model gates qualify across the initial run and unchanged targeted reruns; all 31 installed-release checks passed. Slotstream is stopped, and Chrome and Wispr Flow are reopened.**

Release: [v0.2.15]({publication['url']}), source commit `{summary['source_commit']}`. [Main CI](https://github.com/carloslfu/slotstream/actions/runs/34592671081) built and tested the archive. Publication reused it without recompilation. The independently downloaded public archive matched CI, passed GitHub provenance verification and reconstructed all 150 compiled inputs. The normal installer installed those verified public bytes.

Archive SHA-256: `{publication['archive_sha256']}`. Binary SHA-256: `{publication['binary_sha256']}`.

## Changes and commit boundaries

The release includes the adopted two-draft default, compatibility-preserving lifetime physical-footprint peak reports, native memory-lifecycle and explicit-budget regressions, corrected memory documentation and the reviewed Expert Lookahead execution plan. Expert prediction and prefetching remain planned work. Valid depth overrides, activation floor, automatic RAM share and memory guards retain their prior behavior. The timing studies do not establish a universal fastest depth or a new throughput gain.

The existing default and alignment commits are `0b600d8` and `7ea0941`. Final plan review is `b7487fa` (`docs(plan)`); memory implementation, tests and evidence are `546f292` (`fix(memory)`); version and release notes are `ee4d1af` (`chore(release)`). The publication receipt is committed separately after the release, without changing compiled inputs or moving its tag.

## Acceptance and preserved exclusions

The original full battery finished 23 passed and two failed. It passed long-context exact recall and zero-swap memory, context diagnostics, 15 quality probes, 74 API robustness checks, vision parity and 25 vision-serving checks. The original 7,972-token prompt completed with four output tokens and answer `SEVENTEEN`; its maximum observed memory was 8,102,153,528 bytes under the 10 GB ceiling.

Governor and combined MTP/vision initially failed native paging guards. Both unchanged targeted diagnostics subsequently passed, including full shrink/cooldown/regrowth and deterministic vision speculation with valid zero-swap memory. Readiness required real headroom, normal pressure, nominal thermal state and 120 seconds of stable swap counters. No workload, cooldown, ceiling or acceptance assertion changed. Earlier failed intervals remain failed. Global paging counters do not establish which process caused a particular event.

The installed binary and full build identity match the CI candidate. Its separate suite passed all 31 checks. With MTP explicitly on but no draft-depth override, one bounded request recorded {stats['draftedTokens']} drafts over {stats['verifyPasses']} verification passes, exactly two per pass, and retained the new lifetime footprint field. These functional checks are not performance measurements.

The earlier preversion long-prompt gap also closed with exact recall and zero swap. The release qualification above uses its own exact CI-binary pass, not an inferred transfer from that candidate. Original audit/source records remain historical evidence.

Carlos authorized pausing Chrome and Wispr Flow. Both were already closed at the first inspection in this release phase; they remained closed through model tests and were reopened afterward. Every owned model process stopped, the native model lock is free, and profiling/detail overrides were confined to child processes. No normal inference server was restarted.

Raw capture and publication: [[{good}]]. Preserved exclusions: [[{failed}]]. Related implementation: [[records/measurements/lifetime-footprint-reporting-and-fixed-budgets-2026-09-11]] and [[records/measurements/draft-depth-two-default-2026-09-11]].
'''
measurement=write('records/measurements/release-qualification-0-2-15.md','measurement','v0.2.15 release qualification',body,{'date':'2026-09-11','doc':'measurements','level':'3','order':'1190','status':'measured','machines':common['machines'],'runs':f'[[{good}]], [[{failed}]]'})
def body_update(path,text):
 temp=BASE/(Path(path).stem+'-updated-body.md');temp.write_text(text);db(['body','set',path,'--body-file',str(temp)])
def existing_body(path):return (DB/path).read_text().split('---',2)[2].lstrip('\n')
for p in ['records/measurements/lifetime-footprint-reporting-and-fixed-budgets-2026-09-11.md','records/measurements/draft-depth-two-default-2026-09-11.md']:
 original=existing_body(p)
 note=f'**Release follow-up, September 11:** this implementation is now published and installed in v0.2.15. All 25 original model gates and all 31 installed-release checks qualify by exact artifact identity. See [[{measurement}]]. The preserved audit below describes its earlier, prerelease state and retains the original failed intervals.\n\n'
 body_update(p,note+original)
 db(['fm','set',p,'note=Published in v0.2.15; full release qualification closes the earlier local acceptance gaps without relabeling failed intervals.'])
 db(['fm','set',p,'summary=Implementation published in v0.2.15; full release acceptance complete, with original audit and excluded intervals preserved'])
p='records/decisions/draft-depth-defaults-to-two.md'
text=existing_body(p).replace('The full MTP gate remains resource-incomplete; the installed public release was not replaced.','That implementation-only stage left the full MTP gate resource-incomplete and did not replace the installed public release. The later [[records/measurements/release-qualification-0-2-15]] closes all release gates and installs the two-draft default in public v0.2.15.')
body_update(p,text)
p='records/plan/expert-lookahead-local-experiment-2026-09-10.md';text=existing_body(p)
text=text.replace("Do not rely on an executable's default: the installed public 0.2.14 artifact still defaults to one.","Do not rely on an executable's default: public v0.2.15 now defaults to two, while older v0.2.14 artifacts default to one. Explicitly pinning the experimental setting preserves reproducibility across both.")
text=text.replace('Public artifact qualification still records two resource-sensitive local acceptance gaps. | Preserve them. The new experiment cannot retrospectively mark those gates passed.','All original public-artifact gates subsequently qualified through unchanged clean reruns; the original resource exclusions remain preserved. | Keep the release acceptance separate from predictor qualification. Current v0.2.15 acceptance is in [[records/measurements/release-qualification-0-2-15]]; freeze that exact baseline identity or qualify a new one.')
body_update(p,text)
db(['index','rebuild'])
print(json.dumps({'measurement':measurement,'raw_files':len(inventory),'archive_sha256':manifest['archive_sha256']}))
