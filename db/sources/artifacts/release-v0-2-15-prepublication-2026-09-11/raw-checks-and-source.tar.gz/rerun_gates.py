import json, os, re, sys, time
from pathlib import Path
ROOT=Path.cwd(); BASE=ROOT/'.build/release-v0.2.15'; OUT=BASE/'targeted-reruns'; OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'Tools'))
from context_qualification import quiet_preflight
from thermal_readiness import observe
from prefill_bench import vm_snapshot,run_child,digest
from serve_bench import verified_build
BINARY=BASE/'ci-candidate/slotstream'; identity=verified_build(BINARY)['identity']
assert all(digest(ROOT/p)==h for p,h in identity['source'].items())
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k!='BIN'}
gates=[('elastic',16,['elastic-drill','--slots','1000','--max-memory-gb','13']),('mtp',15,['mtp-check','--memory-gb','12','--mtp','on','--vision','on','--image','Tools/assets/vision_test/secret1.jpg'])]
(OUT/'protocol.json').write_text(json.dumps({'identity':identity,'gates':gates,'maximum_attempts_per_gate':2,'readiness_seconds':120,'readiness_timeout_seconds':600,'verify_driver_sha256':digest(ROOT/'Tools/verify.sh'),'environment_overrides':{}},indent=2)+'\n')
results=[]
for name,headroom,args in gates:
 for attempt in range(1,3):
  cell=OUT/f'{name}-{attempt}';cell.mkdir(); observations=[]; stable=None; last=None; begin=time.monotonic()
  while time.monotonic()-begin<600:
   vm=quiet_preflight(headroom); th=observe(); now=time.monotonic(); counters=(vm['swapins'],vm['swapouts'])
   if not th['ready'] or counters!=last:stable=now if th['ready'] else None
   observations.append({'elapsed':now-begin,'vm':vm,'thermal':th});last=counters
   (cell/'readiness.json').write_text(json.dumps(observations,indent=2)+'\n')
   if stable is not None and now-stable>=120:break
   time.sleep(5)
  else:raise RuntimeError('No stable readiness interval for '+name)
  row={'gate':name,'attempt':attempt,'command':[str(BINARY)]+args,'before':quiet_preflight(headroom)}
  (cell/'before.json').write_text(json.dumps(row,indent=2)+'\n');print('Launching',name,'attempt',attempt,flush=True)
  row['exit_code']=run_child(row['command'],env,cell,1200); row['after']=vm_snapshot()
  output=(cell/'stdout.txt').read_text()+'\n'+(cell/'stderr.txt').read_text()
  prefix='ELASTIC DRILL MEMORY ' if name=='elastic' else 'MTP CHECK MEMORY '
  memories=[json.loads(line[len(prefix):]) for line in output.splitlines() if line.startswith(prefix)]
  row['memory']=memories
  if name=='elastic':
   statuses=re.findall(r'^ELASTIC DRILL (?:PASS|FAIL|SKIP)(?::|$).*',output,re.M)
   valid=len(statuses)==1 and statuses[0].startswith('ELASTIC DRILL PASS:')
   valid=valid and len(memories)==1 and memories[0]['complete'] is True
  else:
   valid=all(s in output for s in ['PASS  vision speculation deterministic','PASS  vision speculation ran','MTP CHECK PASS']) and 'SKIP' not in output
   valid=valid and len(memories)==1 and memories[0]['memory_validated'] is True
  if memories:
   m=memories[0]; valid=valid and m['swapins_after']==m['swapins_before'] and m['swapouts_after']==m['swapouts_before']
  row['passed']=row['exit_code']==0 and valid;row['discarded']=not row['passed'];results.append(row)
  (cell/'result.json').write_text(json.dumps(row,indent=2)+'\n');(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps({k:v for k,v in row.items() if k not in ['before','after','command']}),flush=True)
  if row['passed']:break
 if not row['passed']:sys.exit(1)
print('Both unchanged targeted gates passed',flush=True)
