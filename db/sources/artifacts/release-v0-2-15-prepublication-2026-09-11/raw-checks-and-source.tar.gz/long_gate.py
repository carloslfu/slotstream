import os,sys,json,time,subprocess,hashlib
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'.build/release-v0.2.15/preversion-long-v2';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import vm_snapshot,run_child,digest
from context_qualification import quiet_preflight
from thermal_readiness import observe
from memory_gate import check_memory
BINARY=ROOT/'.build/memory-reporting-audit-20260911/candidate-final/slotstream'
identity=json.loads((BINARY.parent/'build-identity.json').read_text())
assert digest(BINARY)==identity['binary_sha256']
assert all(digest(ROOT/f)==h for f,h in identity['source'].items())
prompt=ROOT/'.build/memory-reporting-audit-20260911/verification/ssv_long.txt'
(OUT/'prompt.txt').write_bytes(prompt.read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_'))}
rows=[]
for attempt in range(1,3):
 cell=OUT/f'attempt-{attempt}';cell.mkdir()
 observations=[]; stable_start=None;last=None;begin=time.monotonic()
 while time.monotonic()-begin<600:
  vm=quiet_preflight(13); th=observe(); now=time.monotonic()
  counters=(vm['swapins'],vm['swapouts'])
  ok=th['ready']
  if not ok or counters!=last: stable_start=now if ok else None
  observations.append({'elapsed':now-begin,'vm':vm,'thermal':th})
  last=counters
  (cell/'readiness.json').write_text(json.dumps(observations,indent=2)+'\n')
  if stable_start is not None and now-stable_start>=120:break
  time.sleep(5)
 else:raise RuntimeError('No 120-second clean readiness interval within 600 seconds')
 quiet_preflight(13)
 cmd=[str(BINARY),'run','--prompt-file',str(OUT/'prompt.txt'),'--max-tokens','16','--greedy','--memory-gb','10','--sample-footprint','--stats-json',str(cell/'stats.json')]
 row={'attempt':attempt,'command':cmd,'binary_sha256':digest(BINARY),'prompt_sha256':digest(prompt),'before':vm_snapshot()}
 (cell/'before.json').write_text(json.dumps(row,indent=2)+'\n')
 print('Launching original long-prompt gate, attempt',attempt,flush=True)
 row['exit_code']=run_child(cmd,env,cell,1200)
 data=json.loads((cell/'stats.json').read_text())
 recall=subprocess.run([sys.executable,'Tools/long_context_gate.py',str(cell/'stats.json'),str(cell/'stdout.txt'),'--expected','SEVENTEEN','--minimum-prompt-tokens','7000','--maximum-output-tokens','16'],capture_output=True,text=True)
 row['recall']={'exit_code':recall.returncode,'stdout':recall.stdout,'stderr':recall.stderr}
 try:row['memory']=check_memory(data,10);row['passed']=row['exit_code']==0 and recall.returncode==0
 except ValueError as e:row['passed']=False;row['memory_error']=str(e)
 row['after']=vm_snapshot();rows.append(row)
 (cell/'result.json').write_text(json.dumps(row,indent=2)+'\n');(OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps({k:v for k,v in row.items() if k not in ['before','after','command']}),flush=True)
 if row['passed']:break
sys.exit(0 if rows and rows[-1]['passed'] else 1)
