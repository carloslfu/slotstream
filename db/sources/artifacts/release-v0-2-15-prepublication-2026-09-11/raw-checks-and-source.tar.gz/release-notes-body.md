Slotstream v0.2.15 makes two draft tokens the default when speculative decoding is enabled and fixes peak-memory reports that could miss GPU allocations after they were freed.

- Preserve explicit draft-depth overrides and the existing memory and MTP activation policies. The selected depth follows the mixed-workload study; no universal throughput improvement is claimed.
- Report lifetime physical-footprint peaks separately from current memory and sampled request peaks, including early failures and cancellations. Older saved statistics remain readable.
- Add native memory-lifecycle and explicit-budget regression checks, and clarify the difference between planned budgets, current usage and historical memory estimates.
- Publish the draft-depth evidence and reviewed Expert Lookahead plan. Learned expert prediction and expert prefetching remain planned work.

See [the changelog](https://github.com/carloslfu/slotstream/blob/v0.2.15/CHANGELOG.md) for details.
