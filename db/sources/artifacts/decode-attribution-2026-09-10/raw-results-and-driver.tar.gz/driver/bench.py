#!/usr/bin/env python3
"""Bounded decode attribution, fresh servers, identical warmup, AB/BA and exact output checks."""
import argparse,json,os,sys,time,socket,subprocess,hashlib,signal
from pathlib import Path
ROOT=Path('/Users/carlos/Projects/slotstream'); BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight,vm_snapshot,digest
from serve_bench import exchange,request_body,wait_ready,stop_server,competing_jobs
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--memory',type=float,default=10);p.add_argument('--mtp',choices=['on','off'],default='off');p.add_argument('--tokens',type=int,default=128);p.add_argument('--rounds',type=int,default=3);p.add_argument('--modes',default='0,2');p.add_argument('--fixture',default='prose.txt');p.add_argument('--cooldown',type=int,default=20);p.add_argument('--warm-tokens',type=int);p.add_argument('--sampled',action='store_true');a=p.parse_args()
assert 8.1<=a.memory<=24 and 1<=a.tokens<=512 and 1<=a.rounds<=8
binary=BASE/'worktree/.build/release/slotstream';out=BASE/a.name;out.mkdir(exist_ok=False)
protocol={'max_tokens':a.tokens,'seed':42,'raw':False,'think':False}
if a.sampled:protocol['sampling']={'temperature':.7,'top_p':.8,'top_k':20}
fixture=ROOT/'Tools/fixtures/optimization'/a.fixture
body=request_body(protocol,fixture.read_text());(out/'request.json').write_bytes(body)
warm_protocol={**protocol,'max_tokens':a.warm_tokens or a.tokens}
warm_body=request_body(warm_protocol,fixture.read_text())
manifest={'arguments':vars(a),'binary':str(binary),'binary_sha256':digest(binary),'fixture_sha256':digest(fixture),'base_git':'449f3841d65cbca8346ab6ae8092eb0948d92dbd','instrumentation':'host spans; Metal existing-buffer timestamps in mode1; Metal per-phase encoder timestamps in mode2; mode0 disabled','modes':list(map(int,a.modes.split(','))),'counting':'raw timelines retained; analysis partitions overlaps separately','resource_gate':'unchanged global swap counters across decode; prefill is outside the measured decode interval and reported separately','invalid_policy':'discard whole pair on any invalid cell; fresh-process retries continue after swap-ins with renewed preflight and cooldown; stop immediately on new swapouts, memory cancellation, or protocol failure'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=[]
def interrupted(signum, frame): raise KeyboardInterrupt(f'signal {signum}')
signal.signal(signal.SIGTERM,interrupted)
signal.signal(signal.SIGINT,interrupted)
try:
 for rnd in range(1,a.rounds+1):
  modes=manifest['modes'] if rnd%2 else list(reversed(manifest['modes']))
  for mode in modes:
   cell=out/f'round-{rnd}-mode-{mode}';cell.mkdir()
   row={'round':rnd,'mode':mode,'valid':False,'cell':str(cell)};child=None
   try:
    # No model or build may be competing. Cooldown is outside measurement.
    jobs=competing_jobs()
    if jobs:raise RuntimeError(f'competing work: {jobs}')
    row['before_cooldown']=vm_snapshot()
    if a.cooldown:time.sleep(a.cooldown)
    before=preflight(a.memory+5 if a.memory>12 else a.memory+3)
    row['before_launch']=before
    if competing_jobs():raise RuntimeError('competing job appeared during cooldown')
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    env={k:v for k,v in os.environ.items() if not k.startswith('SLOTSTREAM_')}
    env.update(SLOTSTREAM_DECODE_TRACE=str(mode),SLOTSTREAM_DECODE_TRACE_DIR=str(cell),SLOTSTREAM_BENCH_DETAILS='1',SLOTSTREAM_PREFILL_CHUNK='256',SLOTSTREAM_DRAFT_DEPTH='1')
    command=[str(binary),'serve','--model',str(Path('/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit')),'--port',str(port),'--memory-gb',str(a.memory),'--mtp',a.mtp,'--no-elastic','--no-prefix-cache']
    row['command']=command;row['env']={k:v for k,v in env.items() if k.startswith('SLOTSTREAM_')}
    with (cell/'server.log').open('wb') as log:
     child=subprocess.Popen(command,stdout=log,stderr=log,env=env,start_new_session=True)
     wait_ready(child,port)
     warm,wire=exchange(port,warm_body,300);(cell/'warmup.ndjson').write_bytes(wire)
     row['warmup']=warm
     row['competing_after_warmup']=competing_jobs()
     if row['competing_after_warmup']:raise RuntimeError('competing work during warmup')
     before=vm_snapshot();row['before']=before
     result,wire=exchange(port,body,300);(cell/'measured.ndjson').write_bytes(wire)
     after=vm_snapshot();row['after']=after;row.update(result)
     stats=result['metrics']['stats'];reasons=[]
     row['competing_after_measurement']=competing_jobs()
     if row['competing_after_measurement']:reasons.append('competing storage/build work')
     resource=json.loads((cell/'resource-1.json').read_text());row['decode_resource']=resource
     rb,ra=resource['before'],resource['after']
     if rb is None or ra is None:reasons.append('missing decode VM observation')
     elif any(rb[k]!=ra[k] for k in ['swapins','swapouts']):reasons.append('global swap activity during decode')
     row['whole_request_swap_delta']={k:after[k]-before[k] for k in ['swapins','swapouts']}
     for name in ['generatorSystemBefore','generatorSystemAfter']:
      obs=stats.get(name,{})
      if obs.get('thermalState')!='nominal' or obs.get('lowPowerModeEnabled') is not False:reasons.append(f'non-nominal or missing power: {name}')
     if stats.get('memoryPressureCancelled'):reasons.append('memory cancellation')
     if stats['decodeTokens']!=a.tokens:reasons.append('incomplete output budget')
     if stats.get('runtimeError'):reasons.append('runtime failure')
     if mode and not (cell/'trace-1.json').is_file():reasons.append('missing trace')
     row['exclusions']=reasons;row['valid']=not reasons
   except Exception as e:
    row['error']=f'{type(e).__name__}: {e}'
   finally:
    if child is not None:stop_server(child)
    rows.append(row)
    with (out/'results.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   stats=row.get('metrics',{}).get('stats',{})
   print(json.dumps({'round':rnd,'mode':mode,'valid':row['valid'],'decode_s':stats.get('decodeSeconds'),'hit':stats.get('expertHitRate'),'error':row.get('error'),'exclusions':row.get('exclusions')}),flush=True)
   if 'error' in row or stats.get('memoryPressureCancelled'):raise RuntimeError('run stopped on resource/protocol failure; evidence retained')
   resource=row.get('decode_resource',{});rb,ra=resource.get('before'),resource.get('after')
   if rb and ra and rb['swapouts']!=ra['swapouts']:raise RuntimeError('new swapouts; stopped and evidence retained')
  this=[r for r in rows if r['round']==rnd]
  if all(r['valid'] for r in this):
   first=this[0]['metrics'];checks={str(r['mode']):{'exact_output_ids':r['metrics']['output_ids']==first['output_ids'],'same_read_bytes':r['metrics']['stats']['decodeReadBytes']==first['stats']['decodeReadBytes'],'same_pool_slots':r['metrics']['effective_pool_slots']==first['effective_pool_slots']} for r in this}
   print(json.dumps({'round':rnd,'parity':checks}),flush=True)
   if not all(all(c.values()) for c in checks.values()):raise RuntimeError('profiling changed output or routed read workload')
finally:
 (out/'finished.json').write_text(json.dumps({'finished_at':time.time(),'cells':len(rows),'valid_cells':sum(r['valid'] for r in rows)},indent=2)+'\n')
