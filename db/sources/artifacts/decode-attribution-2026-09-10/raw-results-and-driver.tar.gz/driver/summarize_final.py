#!/usr/bin/env python3
"""Recompute exclusive wall-time attribution from every clean matched pair."""
import collections, json, statistics, sys
from pathlib import Path
from analyze import analyze

BASE = Path(__file__).resolve().parent

def group(key):
    if key == 'Host: expert file read': return 'SSD file-read workers and waits'
    if key == 'Host: staging allocation and wrapping': return 'Allocate and wrap RAM staging buffers'
    if key.startswith('CPU:'): return 'CPU Metal command preparation and driver calls'
    if key == 'Host: graph evaluation and synchronization': return 'CPU graph evaluation, scheduling and synchronization'
    if key.startswith('Host:'): return 'CPU model graphs, cache bookkeeping, MTP state and output'
    if key == 'GPU: cache writes': return 'GPU writes from staging RAM into the expert cache'
    if key == 'GPU: cache writes and expert calculations together': return 'GPU cache writes and expert calculations together'
    if key == 'GPU: expert calculations and output mixing': return 'GPU expert calculations and output mixing'
    if key == 'GPU: GDN layer preparation (normalization, recurrence, routing)': return 'GPU recurrent layers, with associated normalization and routing'
    if key == 'GPU: attention layer preparation (normalization, attention)': return 'GPU attention layers, with associated normalization'
    if key == 'GPU: normalization, routing and residual operations': return 'GPU remaining normalization, routing and residual operations'
    if key.startswith('GPU:'): return 'GPU vocabulary, ngram embedding, MTP head, sampling and other passes'
    raise ValueError(key)

studies = {}
for name in ['natural-smoke-32','final-small-128','final-large-mtp-128-v2','final-large-mtp-512-v2']:
    path = BASE/name
    rows = [json.loads(line) for line in (path/'results.jsonl').read_text().splitlines()]
    pairs = collections.defaultdict(dict)
    for row in rows: pairs[row['round']][row['mode']] = row
    clean = []
    rejected = {}
    for rnd, pair in pairs.items():
        if set(pair) != {0,4} or not all(r['valid'] for r in pair.values()):
            rejected[rnd] = {str(mode): row.get('exclusions',row.get('error')) for mode,row in pair.items()}
            continue
        off,on = pair[0],pair[4]
        a,b = off['metrics'],on['metrics']
        assert a['output_ids'] == b['output_ids']
        assert a['stats']['decodeReadBytes'] == b['stats']['decodeReadBytes']
        assert a['effective_pool_slots'] == b['effective_pool_slots']
        trace = path/f'round-{rnd}-mode-4/trace-1.json'
        analysis = analyze(trace)
        assert abs(analysis['sum_percent']-100) < 1e-8
        assert not analysis['invalid_gpu_samples'] and analysis['host_overlap_ns'] == 0
        assert 'uncovered' not in analysis['parts_percent']
        assert abs(analysis['decode_seconds']-b['stats']['decodeSeconds']) < 1e-8
        grouped = collections.Counter()
        for key,val in analysis['parts_percent'].items(): grouped[group(key)] += val
        analysis['grouped_percent'] = dict(grouped)
        (trace.parent/'analysis-final.json').write_text(json.dumps(analysis,indent=2)+'\n')
        clean.append({'round':rnd,'unprofiled_seconds':a['stats']['decodeSeconds'],
                      'profiled_seconds':analysis['decode_seconds'],
                      'paired_overhead_percent':100*(analysis['decode_seconds']/a['stats']['decodeSeconds']-1),
                      'profile':analysis,'stats':b['stats'],'pool_slots':b['effective_pool_slots']})
    if clean:
        total = sum(r['profiled_seconds'] for r in clean)
        grouped = collections.Counter(); full = collections.Counter()
        for r in clean:
            for key,val in r['profile']['grouped_percent'].items(): grouped[key] += val*r['profiled_seconds']/total
            for key,val in r['profile']['parts_percent'].items(): full[key] += val*r['profiled_seconds']/total
        ranked = sorted(clean,key=lambda r:r['profiled_seconds'])
        studies[name] = {'clean_pair_count':len(clean),'rejected_pairs':rejected,
                        'weighted_grouped_percent':dict(grouped),'weighted_full_percent':dict(full),
                        'median_paired_overhead_percent':statistics.median(r['paired_overhead_percent'] for r in clean),
                        'median_unprofiled_seconds':statistics.median(r['unprofiled_seconds'] for r in clean),
                        'median_profiled_seconds':statistics.median(r['profiled_seconds'] for r in clean),
                        'representative_round':ranked[len(ranked)//2]['round'],
                        'profiled_seconds_total':total,'pairs':clean}
    else: studies[name] = {'clean_pair_count':0,'rejected_pairs':rejected}
    print(name,studies[name]['clean_pair_count'],'clean pairs',flush=True)
(BASE/'final-summary.json').write_text(json.dumps(studies,indent=2)+'\n')
for name,study in studies.items():
    if study['clean_pair_count']:
        print(name,study['weighted_grouped_percent'],study['median_paired_overhead_percent'])
