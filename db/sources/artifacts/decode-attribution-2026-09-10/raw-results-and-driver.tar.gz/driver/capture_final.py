#!/usr/bin/env python3
"""Preserve raw counters losslessly, results including exclusions, and reproducible sources."""
import hashlib,json,lzma,shutil,subprocess,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
DEST=ROOT/'db/sources/artifacts/decode-attribution-2026-09-10'
DEST.mkdir(parents=True,exist_ok=False)
def digest(path,opener=open):
    h=hashlib.sha256()
    with opener(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
inventory=[]
studies=sorted(p for p in BASE.iterdir() if p.is_dir() and (p/'manifest.json').exists() and p.name!='source-freeze-final')
with tarfile.open(DEST/'raw-results-and-driver.tar.gz','w:gz') as tar:
    for p in studies:
        if (BASE/(p.name+'.log')).exists():tar.add(BASE/(p.name+'.log'),arcname=p.name+'/driver.log')
        for f in sorted(p.rglob('*')):
            if f.is_file() and (f.name in {'manifest.json','results.jsonl','finished.json','request.json','resource-0.json','resource-1.json','warmup.ndjson','measured.ndjson','server.log','analysis-final.json'}):
                tar.add(f,arcname=str(f.relative_to(BASE)),recursive=False)
    for name in ['bench.py','analyze.py','summarize_final.py','capture_final.py','long-prose.txt']:
        tar.add(BASE/name,arcname='driver/'+name)
    for name in ['prefill_bench.py','serve_bench.py']:
        tar.add(ROOT/'Tools'/name,arcname='driver/Tools/'+name)
    for name in ['build.txt','build-counter-fix.txt','build-cpu-encoding.txt','build-natural-counters.txt']:
        if (BASE/name).exists():tar.add(BASE/name,arcname='build-logs/'+name)
shutil.copy2(BASE/'source-freeze-final.tar.gz',DEST/'profiled-source.tar.gz')
shutil.copy2(BASE/'final-summary.json',DEST/'analysis.json')
summary=json.loads((BASE/'final-summary.json').read_text())
for study,info in summary.items():
    for pair in info.get('pairs',[]):
        trace=BASE/study/f"round-{pair['round']}-mode-4/trace-1.json"
        target=DEST/f"{study}-round-{pair['round']}-trace.json.xz"
        h=digest(trace)
        with trace.open('rb') as src,lzma.open(target,'wb',preset=3) as dst:shutil.copyfileobj(src,dst,1024*1024)
        assert digest(target,lzma.open)==h
        inventory.append({'source':str(trace.relative_to(ROOT)),'raw_bytes':trace.stat().st_size,'raw_sha256':h,
                          'artifact':target.name,'bytes':target.stat().st_size,'sha256':digest(target),'lossless_roundtrip':True})
        print('preserved',target.name,target.stat().st_size,flush=True)
for f in sorted(DEST.iterdir()):
    if not f.name.endswith('.xz'):
        inventory.append({'artifact':f.name,'bytes':f.stat().st_size,'sha256':digest(f)})
manifest={'inventory':inventory,'slotstream_base':'449f3841d65cbca8346ab6ae8092eb0948d92dbd',
          'binary_sha256':digest(BASE/'worktree/.build/release/slotstream'),
          'final_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
          'raw_trace_policy':'All measured traces from clean matched pairs are losslessly archived. Raw request results, resource counters and errors from all studies are retained, including discarded attempts. Unqualified and warmup traces remain in the local ignored build directory.',
          'source_policy':'profiled-source.tar.gz freezes actual native code. The raw-results archive contains the later driver contention checks and final offline analysis. Native binary did not change after the source freeze.',
          'mode_label_correction':'The original per-study manifest prose omits mode4. The actual modes array, arguments, source and trace headers are authoritative. Mode4 uses original natural Metal encoder boundaries, without added within-decode evals, waits or splits.'}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('CAPTURE_COMPLETE',DEST,flush=True)
