#!/usr/bin/env python3
"""Partition measured decode wall time; keep concurrency explicit in diagnostics."""
import json,sys,collections,heapq,statistics
from pathlib import Path
NAMES={0:'residual/other',1:'embedding',2:'ngram PLE',3:'hyperconnections and normalization',4:'GDN projections and convolution',5:'GDN recurrence',6:'GDN output',7:'attention indexer',8:'attention',10:'router',11:'routed experts',12:'shared expert',13:'cache slot write',14:'output projection',15:'sampling',16:'draft head',17:'state reconciliation',18:'expert file read',19:'staging allocation and wrapping',20:'cache lookup and eviction',21:'graph evaluation and synchronization',22:'output callback',23:'ngram row prefetch'}
NAMES.update({100:'GDN layer preparation (normalization, recurrence, routing)',101:'attention layer preparation (normalization, attention)',102:'expert calculations and output mixing',103:'cache writes and expert calculations together',104:'cache writes',105:'final mixing and vocabulary projection',106:'normalization and routing',107:'ngram embedding and preparation',108:'sampling'})
def gpu_category(bits):
 phases={i for i in range(24) if bits & (1<<i)}
 if 13 in phases and (11 in phases or 12 in phases):return 103
 if 13 in phases:return 104
 if 11 in phases or 12 in phases:return 102
 if phases & {4,5,6}:return 100
 if phases & {7,8}:return 101
 if 14 in phases:return 105
 if phases & {1,2}:return 107
 if 15 in phases:return 108
 return 106
def analyze(path):
 t=json.loads(Path(path).read_text());a,b=t['decode_start_ns'],t['decode_end_ns'];total=b-a
 events=[];host_sums=collections.Counter();graw=collections.Counter();invalid=[]
 for x,y,c in t['host']:
  x=max(x,a);y=min(y,b)
  if y>x: events.extend([(x,1,c,1),(y,1,c,-1)]);host_sums[c]+=y-x
 (c0,g0),(c1,g1)=t['cpu_gpu_clock_pairs'];num,den=t['timebase'];scale=(c1-c0)/(g1-g0)
 def clock(x):return c0+(x-g0)*scale
 for x,y,c in t['gpu_passes']:
  if t['mode']==4:c=gpu_category(c)
  if x==0 and y==0:continue
  if y<x or x==0 or y==0:invalid.append([x,y,c]);continue
  x,y=clock(x),clock(y);x=max(x,a);y=min(y,b)
  if y>x:events.extend([(x,0,c,1),(y,0,c,-1)]);graw[c]+=y-x
 for x,y,c in t.get('cpu_encodings',[]):
  x=max(x,a);y=min(y,b)
  if y>x:events.extend([(x,3,c,1),(y,3,c,-1)])
 events.extend([(a,2,0,0),(b,2,0,0)]);events.sort()
 host=collections.Counter();gpu=collections.Counter();encoder=collections.Counter();parts=collections.Counter();overlap_host=collections.Counter();overlap_gpu=collections.Counter();host_overlap_ns=0;gpu_sum=0;last=a
 for timestamp,kind,category,delta in events:
  dt=timestamp-last
  if dt>0:
   gs=[k for k,v in gpu.items() if v>0];hs=[k for k,v in host.items() if v>0]
   if len(hs)>1:host_overlap_ns+=dt
   if gs:
    gpu_sum+=dt
    if len(gs)==1:parts['GPU: '+NAMES.get(gs[0],str(gs[0]))]+=dt
    elif set(gs)<={102,103,104}:parts['GPU: cache writes and expert calculations together']+=dt;overlap_gpu[str(sorted(gs))]+=dt
    else:parts['GPU: overlapping categories']+=dt;overlap_gpu[str(sorted(gs))]+=dt
    if hs:overlap_host[NAMES.get(hs[0],str(hs[0]))]+=dt
   elif hs and hs[0] in [18,19,23]:parts['Host: '+NAMES.get(hs[0],str(hs[0]))]+=dt
   elif any(v>0 for v in encoder.values()):parts['CPU: Metal command preparation and driver calls']+=dt
   elif hs:parts['Host: '+NAMES.get(hs[0],str(hs[0]))]+=dt
   else:parts['uncovered']+=dt
  if kind==0:gpu[category]+=delta
  elif kind==1:host[category]+=delta
  elif kind==3:encoder[category]+=delta
  last=timestamp
 # Existing command buffers span gaps as well as work; don't label them pure GPU execution.
 intervals=sorted((max(a,x*1e9),min(b,y*1e9)) for x,y in t['command_buffers'] if y>x and y*1e9>a and x*1e9<b)
 cb=0;end=a
 for x,y in intervals:
  cb+=max(0,y-max(x,end));end=max(end,y)
 return {'decode_seconds':total/1e9,'parts_percent':{k:v/total*100 for k,v in sorted(parts.items(),key=lambda x:-x[1])},'host_raw_percent':{NAMES.get(k,str(k)):v/total*100 for k,v in host_sums.items()},'gpu_raw_percent':{NAMES.get(k,str(k)):v/total*100 for k,v in graw.items()},'gpu_union_percent':gpu_sum/total*100,'gpu_overlaps_percent':{k:v/total*100 for k,v in overlap_gpu.items()},'gpu_overlap_with_host_percent':{k:v/total*100 for k,v in overlap_host.items()},'host_overlap_ns':host_overlap_ns,'sum_percent':sum(parts.values())/total*100,'gpu_clock_scale':scale,'invalid_gpu_samples':invalid,'pass_count':len(t['gpu_passes']),'command_buffer_union_percent':cb/total*100}
if __name__=='__main__':
 for arg in sys.argv[1:]:
  result=analyze(arg)
  dest=Path(arg).with_name(Path(arg).stem+'-analysis.json');dest.write_text(json.dumps(result,indent=2)+'\n')
  print(arg,json.dumps(result,indent=2))
