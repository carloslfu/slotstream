// Diagnostic-only file in an isolated worktree. Not a production feature.
import Foundation
import MLX
@_silgen_name("ssprof_set_phase") private func setPhase(_ phase: Int32) -> Int32
@_silgen_name("ssprof_begin") private func beginProfile(_ mode: Int32)
@_silgen_name("ssprof_end") private func endProfile(_ path: UnsafePointer<CChar>, _ start: UInt64, _ end: UInt64)
enum DecodeTrace {
    static let mode = Int32(ProcessInfo.processInfo.environment["SLOTSTREAM_DECODE_TRACE"] ?? "0") ?? 0
    static var sequence = 0
    struct Resource: Codable {
        var start: UInt64
        var end: UInt64
        var before: ProcessMemory.VMActivity?
        var after: ProcessMemory.VMActivity?
    }
    static var before: ProcessMemory.VMActivity?
    static func begin() {
        if mode > 0 { Stream.gpu.synchronize(); beginProfile(mode) }
        before = ProcessMemory.vmActivity()
    }
    static func end(start: UInt64, end: UInt64) {
        let after = ProcessMemory.vmActivity()
        let directory = ProcessInfo.processInfo.environment["SLOTSTREAM_DECODE_TRACE_DIR"]!
        let resource=Resource(start:start,end:end,before:before,after:after)
        let resourceURL=URL(fileURLWithPath: "\(directory)/resource-\(sequence).json")
        try! JSONEncoder().encode(resource).write(to:resourceURL)
        if mode > 0 {
            Stream.gpu.synchronize()
            let path = "\(directory)/trace-\(sequence).json"
            path.withCString { endProfile($0, start, end) }
        }
        sequence += 1
    }
    @inline(__always) static func enter(_ phase: Int32) -> Int32 { mode > 0 ? setPhase(phase) : 0 }
    @inline(__always) static func leave(_ previous: Int32) { if mode > 0 { _ = setPhase(previous) } }
    @inline(__always) static func scope<T>(_ phase: Int32, _ body: () throws -> T) rethrows -> T {
        let previous=enter(phase); defer {leave(previous)}; return try body()
    }
}
