// Isolated measurement build only. Never linked into production.
#include "mlx/ssprofile.h"
#include "mlx/backend/metal/device.h"
#include <mach/mach_time.h>
#include <thread>
#include <mutex>
#include <vector>
#include <fstream>
#include <iomanip>
#include <atomic>
#include <stdexcept>
#include <objc/message.h>
#include <objc/runtime.h>
thread_local int ssprof_phase=0;
thread_local int ssprof_eval_phase=0;
int ssprof_mode=0;
namespace {
struct Host{uint64_t begin,end;int phase;};
struct GPU{uint64_t begin,end;int phase;};
struct Buffer{double begin,end;};
struct Block{MTL::CounterSampleBuffer* buffer=nullptr;std::vector<int> phases;};
std::vector<Host> hosts;std::vector<GPU> encodings;std::vector<GPU> passes;std::vector<Buffer> buffers;
std::mutex records_mutex;std::atomic<int> pending{0};Block current;
std::thread::id owner;MTL::Timestamp cpu0,gpu0;uint64_t host_start;
mach_timebase_info_data_t timebase;constexpr unsigned capacity=4096;
uint64_t now_ns(){return (long double)mach_absolute_time()*timebase.numer/timebase.denom;}
MTL::Device* device(){return mlx::core::metal::device(mlx::core::Device::gpu).mtl_device();}
Block new_block(){
 auto* desc=MTL::CounterSampleBufferDescriptor::alloc()->init();auto* sets=device()->counterSets();MTL::CounterSet* timestamps=nullptr;
 for(NS::UInteger i=0;i<sets->count();++i){auto* set=sets->object<MTL::CounterSet>(i);if(std::string(set->name()->utf8String())=="timestamp")timestamps=set;}
 if(!timestamps)throw std::runtime_error("timestamp counter set unavailable");
 desc->setCounterSet(timestamps);desc->setStorageMode(MTL::StorageModeShared);desc->setSampleCount(capacity);
 NS::Error* error=nullptr;auto* b=device()->newCounterSampleBuffer(desc,&error);desc->release();
 if(!b)throw std::runtime_error(std::string("GPU timestamp buffer: ")+(error?error->localizedDescription()->utf8String():"unknown"));
 Block result;result.buffer=b;result.phases.reserve(capacity/2);return result;
}
void collect(Block block){
 auto* pool=NS::AutoreleasePool::alloc()->init();
 if(!block.phases.empty()){
  auto* data=block.buffer->resolveCounterRange(NS::Range(0,block.phases.size()*2));
  if(!data||data->length()<block.phases.size()*2*sizeof(MTL::CounterResultTimestamp))throw std::runtime_error("incomplete GPU counters");
  auto* ts=static_cast<const MTL::CounterResultTimestamp*>(((const void*(*)(void*,SEL))objc_msgSend)(data,sel_registerName("bytes")));
  std::lock_guard<std::mutex> guard(records_mutex);
  for(size_t i=0;i<block.phases.size();++i)passes.push_back({ts[i*2].timestamp,ts[i*2+1].timestamp,block.phases[i]});
 }
 block.buffer->release();pool->release();
}
}
uint64_t ssprof_encoding_begin(){return ssprof_mode==1 || ssprof_mode>=3 ? now_ns() : 0;}
void ssprof_encoding_end(uint64_t start,int phase){if(start)encodings.push_back({start,now_ns(),phase});}
extern "C" int ssprof_get_phase(){return ssprof_mode?ssprof_phase:0;}
extern "C" int ssprof_set_phase(int phase){
 if(!ssprof_mode)return 0;int old=ssprof_phase;
 if(std::this_thread::get_id()==owner){uint64_t end=now_ns();hosts.push_back({host_start,end,old});host_start=end;}
 ssprof_phase=phase;return old;
}
extern "C" void ssprof_begin(int mode){
 if(!mode)return;mach_timebase_info(&timebase);hosts.clear();passes.clear();buffers.clear();
 hosts.reserve(500000);passes.reserve(250000);buffers.reserve(100000);owner=std::this_thread::get_id();
 encodings.clear();if(mode==1 || mode>=3)encodings.reserve(2000000);
 if(mode>=2)current=new_block();device()->sampleTimestamps(&cpu0,&gpu0);
 host_start=now_ns();ssprof_phase=0;ssprof_mode=mode;
}
MTL::ComputeCommandEncoder* ssprof_encoder(MTL::CommandBuffer* buffer){
 if(ssprof_mode<2)return buffer->computeCommandEncoder(MTL::DispatchTypeConcurrent);
 if(current.phases.size()*2==capacity){
  Block full=std::move(current);pending.fetch_add(1);
  buffer->addCompletedHandler([full=std::move(full)](MTL::CommandBuffer*){collect(full);pending.fetch_sub(1);});current=new_block();
 }
 unsigned i=current.phases.size()*2;current.phases.push_back(ssprof_mode==4 ? 0 : ssprof_eval_phase);
 auto* desc=MTL::ComputePassDescriptor::computePassDescriptor();desc->setDispatchType(MTL::DispatchTypeConcurrent);
 auto* a=desc->sampleBufferAttachments()->object(0);a->setSampleBuffer(current.buffer);a->setStartOfEncoderSampleIndex(i);a->setEndOfEncoderSampleIndex(i+1);
 return buffer->computeCommandEncoder(desc);
}
void ssprof_mark_dispatch(){if(ssprof_mode==4 && !current.phases.empty())current.phases.back() |= (1 << ssprof_eval_phase);}
void ssprof_command_buffer(MTL::CommandBuffer* buffer){
 if(!ssprof_mode)return;buffer->addCompletedHandler([](MTL::CommandBuffer* b){std::lock_guard<std::mutex> guard(records_mutex);buffers.push_back({b->GPUStartTime(),b->GPUEndTime()});});
}
extern "C" void ssprof_end(const char* path,uint64_t start_ns,uint64_t end_ns){
 if(!ssprof_mode)return;ssprof_set_phase(0);MTL::Timestamp cpu1,gpu1;device()->sampleTimestamps(&cpu1,&gpu1);
 int mode=ssprof_mode;ssprof_mode=0;
 if(current.buffer){collect(std::move(current));current=Block{};}
 auto deadline=now_ns()+5000000000ULL;
 while(pending.load()){if(now_ns()>deadline)throw std::runtime_error("counter callback drain timeout");std::this_thread::yield();}
 std::ofstream out(path);out<<std::setprecision(17);
 out<<"{\"mode\":"<<mode<<",\"decode_start_ns\":"<<start_ns<<",\"decode_end_ns\":"<<end_ns<<",\"cpu_gpu_clock_pairs\":[["<<cpu0<<","<<gpu0<<"],["<<cpu1<<","<<gpu1<<"]],\"timebase\":["<<timebase.numer<<","<<timebase.denom<<"],\"host\":[";
 for(size_t i=0;i<hosts.size();++i){if(i)out<<",";auto& h=hosts[i];out<<"["<<h.begin<<","<<h.end<<","<<h.phase<<"]";}
 out<<"],\"gpu_passes\":[";std::lock_guard<std::mutex> guard(records_mutex);
 for(size_t i=0;i<passes.size();++i){if(i)out<<",";auto& p=passes[i];out<<"["<<p.begin<<","<<p.end<<","<<p.phase<<"]";}
 out<<"],\"cpu_encodings\":[";
 for(size_t i=0;i<encodings.size();++i){if(i)out<<",";auto& e=encodings[i];out<<"["<<e.begin<<","<<e.end<<","<<e.phase<<"]";}
 out<<"],\"command_buffers\":[";
 for(size_t i=0;i<buffers.size();++i){if(i)out<<",";out<<"["<<buffers[i].begin<<","<<buffers[i].end<<"]";}out<<"]}\n";
}
