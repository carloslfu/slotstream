#pragma once
#include <cstdint>
#include <Metal/Metal.hpp>
extern thread_local int ssprof_phase;
extern thread_local int ssprof_eval_phase;
extern int ssprof_mode;
extern "C" int ssprof_get_phase();
extern "C" int ssprof_set_phase(int phase);
extern "C" void ssprof_begin(int mode);
extern "C" void ssprof_end(const char* path, uint64_t start_ns, uint64_t end_ns);
MTL::ComputeCommandEncoder* ssprof_encoder(MTL::CommandBuffer* buffer);
void ssprof_command_buffer(MTL::CommandBuffer* buffer);
