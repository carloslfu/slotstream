import json, os, sys, time, subprocess, datetime
from pathlib import Path
ROOT=Path.cwd(); BASE=ROOT/'.build/release-v0.2.15'; OUT=BASE/'open-apps-native-preflight'; OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'Tools'))
from context_qualification import quiet_preflight
from thermal_readiness import observe
from prefill_bench import vm_snapshot,run_child,digest
from serve_bench import verified_build
BINARY=BASE/'ci-candidate/slotstream'; identity=verified_build(BINARY)['identity']
assert all(digest(ROOT/p)==h for p,h in identity['source'].items())
assert subprocess.check_output([str(BINARY),'--version'],text=True).strip()=='0.2.15'
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k!='BIN'}
command=[str(BINARY),'mtp-check','--memory-gb','12','--mtp','on','--vision','on','--image','Tools/assets/vision_test/secret1.jpg']
protocol={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identity':identity,'command':command,'driver_sha256':{p:digest(ROOT/p) for p in ['Tools/verify.sh','Tools/prefill_bench.py','Tools/context_qualification.py','Tools/thermal_readiness.py']},'constraint':'Leave all user apps and unrelated workloads running. No quit, pause, stop, suspend or configuration change to them. Drain only model processes owned by this test.','maximum_attempts':3,'prior_model_attempts':1,'readiness_seconds':0,'readiness_timeout_seconds':120,'readiness_policy':'Original native gate preflight: one model, normal pressure and at least 15 GB real reclaimable; no extra stable-swap waiting requirement.','environment_overrides':{}}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
rows=[]
for attempt in range(2,5):
 cell=OUT/f'attempt-{attempt}';cell.mkdir(); observations=[]; stable=None; last=None; begin=time.monotonic()
 print('Checking original native preflight, attempt',attempt,flush=True)
 for check in range(25):
  try:
   ready=quiet_preflight(15)
   observations.append({'vm':ready,'thermal':observe(),'passed':True})
   break
  except Exception as exc:
   observations.append({'passed':False,'error':str(exc)})
   if check==24:raise
   time.sleep(5)
 (cell/'readiness.json').write_text(json.dumps(observations,indent=2)+'\n')
 row={'attempt':attempt,'command':command,'before':quiet_preflight(15)}
 (cell/'before.json').write_text(json.dumps(row,indent=2)+'\n')
 print('Launching original full MTP/vision gate, attempt',attempt,flush=True)
 row['exit_code']=run_child(command,env,cell,1200);row['after']=vm_snapshot()
 output=(cell/'stdout.txt').read_text()+'\n'+(cell/'stderr.txt').read_text()
 prefix='MTP CHECK MEMORY ';memory=[json.loads(line[len(prefix):]) for line in output.splitlines() if line.startswith(prefix)]
 row['memory']=memory;row['functional_vision_completed']=all(s in output for s in ['PASS  vision speculation deterministic','PASS  vision speculation ran'])
 valid=row['exit_code']==0 and row['functional_vision_completed'] and 'SKIP' not in output and 'MTP CHECK PASS' in output
 valid=valid and len(memory)==1 and memory[0]['memory_validated'] is True
 if memory:
  m=memory[0];valid=valid and m['swapins_before']==m['swapins_after'] and m['swapouts_before']==m['swapouts_after']
 row['passed']=valid;row['discarded']=not valid;rows.append(row)
 (cell/'result.json').write_text(json.dumps(row,indent=2)+'\n');(OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps({k:v for k,v in row.items() if k not in ['before','after','command']}),flush=True)
 if valid:break
print('Final MTP/vision gate passed:',rows[-1]['passed'],flush=True)
sys.exit(0 if rows[-1]['passed'] else 1)
