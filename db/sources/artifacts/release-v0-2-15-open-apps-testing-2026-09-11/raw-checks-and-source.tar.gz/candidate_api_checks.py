import json,os,sys,subprocess,socket,time,http.client
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'.build/release-v0.2.15';OUT=BASE/'candidate-api-acceptance';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'Tools'))
from context_qualification import quiet_preflight
from serve_bench import verified_build,wait_ready,stop_server,exchange
from prefill_bench import digest
BINARY=BASE/'ci-candidate/slotstream';identity=verified_build(BINARY)['identity']
expected=json.loads((BASE/'ci-candidate/build-identity.json').read_text());assert identity==expected
assert subprocess.check_output([str(BINARY),'--version'],text=True).strip()=='0.2.15'
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k!='BIN'}
env['SLOTSTREAM_BENCH_DETAILS']='1'
cmd=[str(BINARY),'serve','--memory-gb','10','--mtp','on','--vision','off','--port',str(port)]
report={'artifact_role':'uninstalled exact CI candidate, not an installed-release test','binary':str(BINARY),'identity':identity,'command':cmd,'environment':{'SLOTSTREAM_BENCH_DETAILS':'1'},'before':quiet_preflight(13)}
(OUT/'protocol.json').write_text(json.dumps(report,indent=2)+'\n')
with (OUT/'server.log').open('wb') as log:
 server=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['pid']=server.pid
 try:
  wait_ready(server,port)
  body=json.dumps({'model':'qwen3.8-flash-next:4bit','prompt':'Explain how a modern city supplies clean drinking water to homes.','stream':True,'think':False,'options':{'num_predict':32,'temperature':0,'seed':42}}).encode()
  (OUT/'request.json').write_bytes(body)
  probe,wire=exchange(port,body,180);(OUT/'response.ndjson').write_bytes(wire);report['default_probe']=probe
  stats=probe['metrics']['stats'];assert stats['draftedTokens']==2*stats['verifyPasses'] and stats['verifyPasses']>0
  assert stats.get('lifetimePhysicalFootprintPeakBytes',0)>=stats['physicalFootprintEndBytes']>0
  e2e_env=env.copy();e2e_env['BIN']=str(BINARY)
  with (OUT/'e2e.log').open('wb') as output:
   result=subprocess.run(['bash','Tools/e2e_release.sh',str(port)],env=e2e_env,stdout=output,stderr=subprocess.STDOUT,timeout=1800)
  report['e2e_exit_code']=result.returncode
  assert result.returncode==0
 finally:stop_server(server);report['server_stopped']=server.poll() is not None;(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'drafted_tokens':stats['draftedTokens'],'verify_passes':stats['verifyPasses'],'e2e_exit_code':report['e2e_exit_code'],'server_stopped':report['server_stopped']}),flush=True)
