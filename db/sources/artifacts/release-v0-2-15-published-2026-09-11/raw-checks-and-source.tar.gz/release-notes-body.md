- Stop treating system-wide macOS paging as a failed correctness or memory-budget
  check. Preserve paging diagnostics and the real process-memory, headroom,
  cancellation and completed-output safeguards. Clean performance measurements
  remain a separate qualification.
- Use two draft tokens by default when speculative decoding is enabled. Valid
  `SLOTSTREAM_DRAFT_DEPTH` overrides remain supported. The choice follows the
  mixed-workload comparison; it is not a universal throughput improvement.
- Fix peak-memory reporting after GPU buffers are freed by reading macOS's
  lifetime physical-footprint high-water. Keep current usage and sampled
  request peaks distinct, and report memory on early failures and cancellations.
- Add native memory-counter and explicit-budget regression checks, preserve
  older saved-statistics decoding, and clarify memory budgets and historical
  estimates in the documentation.
- Include the draft-depth studies, decode bottleneck evidence, and the reviewed
  Expert Lookahead plan. Learned expert prediction and expert prefetching remain
  planned work; this release does not implement them.
