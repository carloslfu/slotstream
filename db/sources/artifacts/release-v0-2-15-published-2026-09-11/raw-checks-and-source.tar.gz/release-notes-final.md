- Stop treating system-wide macOS paging as a failed correctness or memory-budget
  check. Preserve paging diagnostics and the real process-memory, headroom,
  cancellation and completed-output safeguards. Clean performance measurements
  remain a separate qualification.
- Use two draft tokens by default when speculative decoding is enabled. Valid
  `SLOTSTREAM_DRAFT_DEPTH` overrides remain supported. The choice follows the
  mixed-workload comparison; it is not a universal throughput improvement.
- Fix peak-memory reporting after GPU buffers are freed by reading macOS's
  lifetime physical-footprint high-water. Keep current usage and sampled
  request peaks distinct, and report memory on early failures and cancellations.
- Add native memory-counter and explicit-budget regression checks, preserve
  older saved-statistics decoding, and clarify memory budgets and historical
  estimates in the documentation.
- Include the draft-depth studies, decode bottleneck evidence, and the reviewed
  Expert Lookahead plan. Learned expert prediction and expert prefetching remain
  planned work; this release does not implement them.

Built and tested by CI from commit 48d11f288237e9b697264621297890eead7ffb0a (build and complete CI log: https://github.com/carloslfu/slotstream/actions/runs/34626184507).

This release publishes that exact archive after source verification and signing (release log: https://github.com/carloslfu/slotstream/actions/runs/34629147966).

sha256: d9ea8246d7868620a0c9e0766f7ba637522739d66da8e5fa5d44b2190fc6d4fa

Verify provenance: gh attestation verify slotstream-arm64.tar.gz --repo carloslfu/slotstream

Install or upgrade: curl -fsSL https://raw.githubusercontent.com/carloslfu/slotstream/main/install.sh | sh
