import json, subprocess, sys, hashlib
from pathlib import Path
ROOT=Path.cwd(); BASE=ROOT/'.build/paging-policy-2026-09-11'; PUBLIC=BASE/'public-download';PUBLIC.mkdir(exist_ok=False)
def run(args,name):
 r=subprocess.run(args,capture_output=True,text=True)
 (BASE/name).write_text(r.stdout)
 if r.stderr:(BASE/(name+'.stderr.txt')).write_text(r.stderr)
 if r.returncode:raise RuntimeError(str(args)+': '+str(r.returncode))
 return r.stdout
release=json.loads(run(['gh','release','view','v0.2.15','--json','url,tagName,targetCommitish,body,assets,publishedAt,isDraft,isPrerelease'],'published-release.json'))
assert not release['isDraft'] and not release['isPrerelease']
run(['gh','release','download','v0.2.15','--dir',str(PUBLIC)],'public-download.log')
asset=PUBLIC/'slotstream-arm64.tar.gz'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
want=(PUBLIC/'slotstream-arm64.tar.gz.sha256').read_text().split()[0]
assert digest(asset)==want==digest(BASE/'ci-download/slotstream-arm64.tar.gz')
run(['gh','attestation','verify',str(asset),'--repo','carloslfu/slotstream','--format','json'],'attestation-verification.json')
run([sys.executable,'Tools/release_candidate.py','--archive',str(asset),'--output',str(BASE/'public-candidate')],'public-archive-verification.json')
assert (BASE/'public-candidate/build-identity.json').read_bytes()==(BASE/'ci-candidate/build-identity.json').read_bytes()
notes=(BASE/'release-notes-body.md').read_text()+'\n'+release['body']+'\n'
(BASE/'release-notes-final.md').write_text(notes)
run(['gh','release','edit','v0.2.15','--notes-file',str(BASE/'release-notes-final.md')],'release-notes-edit.log')
report={'url':release['url'],'archive_sha256':want,'binary_sha256':digest(BASE/'public-candidate/slotstream'),'matches_ci_archive':True,'identity_matches_ci':True,'attestation_verified':True}
(BASE/'publication-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
