import json, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'.build/paging-policy-2026-09-11';OUT=BASE/'ci-model-acceptance'
sys.path.insert(0,str(ROOT/'Tools'))
from context_qualification import quiet_preflight, verification_lock
from prefill_bench import digest,terminate_child_tree,vm_snapshot
from serve_bench import verified_build
binary=BASE/'ci-candidate/slotstream';identity=verified_build(binary)['identity']
assert subprocess.check_output([str(binary),'--version'],text=True).strip()=='0.2.15'
assert all(digest(ROOT/f)==h for f,h in identity['source'].items())
before=quiet_preflight(20.5);OUT.mkdir(exist_ok=False)
drivers=['Tools/verify.sh','Tools/prefill_bench.py','Tools/context_qualification.py','Tools/memory_gate.py',
         'Tools/long_context_gate.py','Tools/api_robustness.sh','Tools/vision_serving.py','Tools/quality_probe.sh']
for f in drivers:
    target=OUT/'drivers'/f;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/f,target)
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k!='BIN'}
env.update(SLOTSTREAM_TEST_BINARY=str(binary),SLOTSTREAM_VERIFY_OUT=str(OUT/'checks'))
result={'binary':str(binary),'identity':identity,'driver_sha256':{f:digest(ROOT/f) for f in drivers},
        'command':['bash','Tools/verify.sh'],'before':before,'started_at':time.time(),'passed':False,
        'constraint':'Leave all user applications and unrelated workloads open and untouched.',
        'memory_policy':'Global paging is diagnostic; original numerical/work, actual process ceilings and headroom guards remain.'}
(OUT/'protocol.json').write_text(json.dumps(result,indent=2)+'\n')
print('Starting the full 25-gate model battery on the exact CI artifact',flush=True)
try:
    with (OUT/'verify.log').open('wb') as log:
        child=subprocess.Popen(result['command'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        result['pid']=child.pid
        try:
            result['exit_code']=child.wait(timeout=3600)
        finally:
            if child.poll() is None:terminate_child_tree(child)
            try:os.killpg(child.pid,signal.SIGTERM)
            except ProcessLookupError:pass
    result['after']=vm_snapshot()
    result['sources_unchanged']=all(digest(ROOT/f)==h for f,h in identity['source'].items())
    result['drivers_unchanged']=all(digest(ROOT/f)==h for f,h in result['driver_sha256'].items())
    output=(OUT/'verify.log').read_text()
    result['summary']=re.findall(r'passed .*failed.*',output)[-1:]
    result['passed']=result['exit_code']==0 and result['sources_unchanged'] and result['drivers_unchanged']
    with verification_lock(): result['model_lock_free']=True
finally:
    result['elapsed_seconds']=time.time()-result['started_at']
    for f in ['/tmp/ssv_long.txt','/tmp/ssv_longmem.json','/tmp/ssv_longmem.txt','/tmp/ssv_longmem.err',
              '/tmp/ssv_mem.json','/tmp/ssv_mem.txt','/tmp/ssv_mem.err','/tmp/ssv_ctx.json','/tmp/ssv_q.log','/tmp/ssv-vision-serve.log']:
        p=Path(f)
        if p.is_file() and p.stat().st_mtime>=result['started_at']:shutil.copy2(p,OUT/p.name)
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('identity','before','after','driver_sha256')}),flush=True)
sys.exit(0 if result['passed'] else 1)
