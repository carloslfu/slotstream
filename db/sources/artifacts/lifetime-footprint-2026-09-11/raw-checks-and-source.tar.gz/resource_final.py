import json, os, subprocess, sys
from pathlib import Path
ROOT=Path.cwd(); AUDIT=ROOT/'.build/memory-reporting-audit-20260911'; OUT=AUDIT/'resource-final'; OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight
from memory_gate import check_memory
BIN=AUDIT/'candidate-final/slotstream'
ENV={k:v for k,v in os.environ.items() if not k.startswith('SLOTSTREAM_')}
cases=[('long',['run','--prompt-file',str(AUDIT/'verification/ssv_long.txt'),'--max-tokens','16','--greedy']),('context',['context-check','--tokens','2048','--json'])]
rows=[]
for name,args in cases:
    preflight(13)
    stats=OUT/(name+'.json')
    command=[str(BIN),*args,'--memory-gb','10','--sample-footprint']
    if name!='context': command+=['--stats-json',str(stats)]
    with (stats if name=='context' else OUT/(name+'.txt')).open('w') as stdout, (OUT/(name+'.stderr.txt')).open('w') as stderr:
        run=subprocess.run(command,env=ENV,stdout=stdout,stderr=stderr,timeout=1200)
    data=json.loads(stats.read_text())
    row={'case':name,'command':command,'exit':run.returncode}
    try:
        row['memory']=check_memory(data,10)
        assert run.returncode==0
        if name=='short': assert (OUT/'short.txt').read_bytes()==Path('/tmp/ssv_big.txt').read_bytes()
        if name=='long':
            gate=subprocess.run([sys.executable,'Tools/long_context_gate.py',str(stats),str(OUT/'long.txt'),'--expected','SEVENTEEN','--minimum-prompt-tokens','7000','--maximum-output-tokens','16'],capture_output=True,text=True)
            row['answer_gate']=gate.stdout
            assert gate.returncode==0,gate.stdout+gate.stderr
        if name=='context': assert data['fits'] and data['aborted'] is None and data['prefill_tokens']==2048
        row['passed']=True
    except (ValueError,AssertionError) as error:
        row['passed']=False;row['error']=repr(error)
    rows.append(row)
    (OUT/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
sys.exit(0 if all(row['passed'] for row in rows) else 1)
