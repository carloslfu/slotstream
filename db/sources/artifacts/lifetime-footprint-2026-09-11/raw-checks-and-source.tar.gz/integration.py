import fcntl, hashlib, http.client, json, os, socket, subprocess, sys, time
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'.build/memory-reporting-audit-20260911/integration'; OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight
BIN=ROOT/'.build/memory-reporting-audit-20260911/candidate/slotstream'
ENV={k:v for k,v in os.environ.items() if not k.startswith('SLOTSTREAM_')}
rows=[]
def request(port,method,path,body=None):
    conn=http.client.HTTPConnection('127.0.0.1',port,timeout=120)
    try:
        conn.request(method,path,body=None if body is None else json.dumps(body),headers={'Content-Type':'application/json'})
        response=conn.getresponse(); data=response.read()
        if response.status != 200: raise AssertionError((response.status,data.decode()[:500]))
        return json.loads(data)
    finally: conn.close()
def stats_check(stats):
    assert stats['physicalFootprintEndBytes']>0
    assert stats['lifetimeRSSPeakBytes']>0
    peak=stats['lifetimePhysicalFootprintPeakBytes']
    assert peak>=stats['physicalFootprintEndBytes']
    assert stats['peakMemoryGB']==max(peak,stats['lifetimeRSSPeakBytes'],stats['physicalFootprintEndBytes'])/1e9
    if stats.get('sampledFootprint'): assert peak>=stats['sampledFootprint']['peakBytes']
    return peak
try:
    if '--cli-only' in sys.argv:
        rows=[json.loads((OUT/f'server-{budget}.json').read_text()) for budget in (8.1,10)]
    for budget in (() if '--cli-only' in sys.argv else (8.1,10)):
        preflight(13)
        flags=['--memory-gb',str(budget),'--mtp','off','--vision','off','--max-context','8192']
        expected=json.loads(subprocess.check_output([str(BIN),'doctor','--json',*flags],env=ENV))
        expected=expected.get('plan',expected)
        with socket.socket() as listener:
            listener.bind(('127.0.0.1',0)); port=listener.getsockname()[1]
        with (OUT/f'server-{budget}.log').open('w') as log:
            child=subprocess.Popen([str(BIN),'serve','--port',str(port),*flags],env={**ENV,'SLOTSTREAM_BENCH_DETAILS':'1'},stdout=log,stderr=subprocess.STDOUT)
            try:
                deadline=time.monotonic()+90
                while True:
                    assert child.poll() is None,'server exited during startup'
                    try: first=request(port,'GET','/api/ps');break
                    except (OSError,TimeoutError):
                        if time.monotonic()>=deadline: raise
                        time.sleep(.25)
                initial=first['models'][0]
                record={'budget_gb':budget,'initial':initial,'requests':[]}
                plan=initial['details']['memory_plan']
                assert plan['source']=='--memory-gb' and plan['target_gb']==budget
                assert plan['pool_slots']==expected['pool_slots']
                assert initial['size']==initial['size_vram']>0
                prior=0
                prompts=['Say OK.','The archive records that the vault combination is SEVENTEEN. '+('Routine maintenance was completed in the west wing. '*100)+' What is the vault combination?','Name one primary color.']
                for index,prompt in enumerate(prompts):
                    result=request(port,'POST','/api/generate',{'prompt':prompt,'stream':False,'options':{'num_predict':8,'temperature':0,'seed':42}})
                    stats=result['slotstream_benchmark']['stats'];peak=stats_check(stats)
                    assert peak>=prior;prior=peak
                    assert result['done'] and result['eval_count']>0
                    after=request(port,'GET','/api/ps')['models'][0]
                    assert after['details']['memory_plan']['pool_slots']==plan['pool_slots']
                    assert after['details']['memory_plan']['source']=='--memory-gb'
                    assert after['size']==after['size_vram']>0
                    record['requests'].append({'case':index,'result':result,'after':after})
                rows.append(record)
            finally:
                child.terminate()
                try:child.wait(timeout=15)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=15)
        (OUT/f'server-{budget}.json').write_text(json.dumps(record,indent=2)+'\n')
    pool_delta=rows[1]['initial']['details']['memory_plan']['memory_ledger']['pool_bytes']-rows[0]['initial']['details']['memory_plan']['memory_ledger']['pool_bytes']
    current_delta=rows[1]['initial']['size']-rows[0]['initial']['size']
    assert pool_delta>0 and current_delta>pool_delta*.5,(pool_delta,current_delta)
    cli=[]
    for name,prompt,cap,tokens in [('normal','The sky is',8192,4),('empty','',8192,1),('context-full','Hi',1,4),('context-refusal','Hello world, explain the sky.',1,4)]:
        preflight(13)
        path=OUT/(name+'.json')
        command=[str(BIN),'run','--raw','--prompt',prompt,'--memory-gb','8.1','--mtp','off','--vision','off','--max-context',str(cap),'--max-tokens',str(tokens),'--stats-json',str(path)]
        result=subprocess.run(command,env=ENV,capture_output=True,text=True,timeout=120)
        (OUT/(name+'.stderr.txt')).write_text(result.stderr)
        if name=='context-refusal':
            assert result.returncode==1 and 'context_length_exceeded' in result.stderr
            assert not path.exists(), 'CLI preparation refusal must not invent generation statistics'
            cli.append({'case':name,'exit':result.returncode,'pre_generation_refusal':True})
            continue
        data=json.loads(path.read_text());stats_check(data['stats'])
        assert result.returncode==(1 if name=='context-refusal' else 0),(name,result.returncode,result.stderr)
        if name in ('empty','context-full','context-refusal'):assert not data['output_ids']
        if name=='context-refusal':assert data['stats']['requestFailure']['code']=='context_length_exceeded'
        if name=='normal':assert 'lifetime footprint peak' in result.stderr
        cli.append({'case':name,'exit':result.returncode,'stats':data['stats']})
    summary={'passed':True,'servers':2,'successful_requests':6,'cli_cases':cli,'startup_pool_delta_bytes':pool_delta,'startup_current_footprint_delta_bytes':current_delta,'binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest()}
except Exception as error:
    summary={'passed':False,'error':repr(error)}
    raise
finally:
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='cli_cases'},indent=2))
