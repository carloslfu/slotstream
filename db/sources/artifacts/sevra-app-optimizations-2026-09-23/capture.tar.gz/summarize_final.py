import pathlib,json,statistics
r=pathlib.Path('/tmp/sevra-app-opt-20260923');out={}
for arm in ['plain','chat']:
 runs=[json.loads((r/f'final-{i}-{arm}.json').read_text()) for i in [1,2,3]]
 assert all(x['exit_code']==0 for x in runs)
 item={'binarySHA':runs[0]['binary_sha256'],'cases':{},'swapins':sum(x['after']['swapins']-x['before']['swapins'] for x in runs),'swapouts':sum(x['after']['swapouts']-x['before']['swapouts'] for x in runs),'thermalStates':sorted(set(s['process']['thermalState'] for x in runs for s in x['samples']))}
 sums=[];peaks=[]
 for case in ['conversation-0','conversation-1','conversation-2']:
  rows=[next(a['stats'] for a in x['rows'] if a.get('case')==case) for x in runs]
  item['cases'][case]={'readSeconds':statistics.median(a['prefillSeconds'] for a in rows),'decodeTPS':statistics.median(a['decodeTokens']/a['decodeSeconds'] for a in rows),'readTokens':[a['prefillTokens'] for a in rows],'cachedTokens':[a['reusedPrefixTokens'] for a in rows]}
 for x in runs:
  selected=[a['stats'] for a in x['rows'] if a.get('case') in item['cases']]
  sums.append(sum(a['prefillSeconds']+a['decodeSeconds'] for a in selected))
  peaks += [a['peakMemoryGB'] for a in selected]
 item['threeTurnSeconds']=statistics.median(sums);item['maxPeakGB']=max(peaks);out[arm]=item
(r/'final-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
