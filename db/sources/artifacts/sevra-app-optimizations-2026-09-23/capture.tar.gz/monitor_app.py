import subprocess,json,time,re,pathlib,sys
r=pathlib.Path('/tmp/sevra-app-opt-20260923');pid=int(sys.argv[1]);label=sys.argv[2]
def vm():
 raw=subprocess.check_output(['vm_stat'],text=True);v={k:int(x) for k,x in re.findall(r'^([^:\n]+):\s+(\d+)\.',raw,re.M)};s=int(re.search(r'page size of (\d+)',raw).group(1));return {'reclaimableGB':sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*s/1e9,'swapins':v['Swapins'],'swapouts':v['Swapouts']}
with (r/(label+'-samples.jsonl')).open('w') as f:
 for _ in range(1200):
  if (r/(label+'-stop')).exists():break
  p=subprocess.run(['/tmp/slotstream-release-calibration-20260922/probe',str(pid)],capture_output=True,text=True)
  if p.returncode:break
  f.write(json.dumps({'time':time.time(),'process':json.loads(p.stdout),'vm':vm()})+'\n');f.flush();time.sleep(.5)
