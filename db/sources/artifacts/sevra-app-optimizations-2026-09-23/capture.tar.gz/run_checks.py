import pathlib,subprocess,json,time,re,sys,hashlib
root=pathlib.Path('/tmp/sevra-app-opt-20260923');repo=pathlib.Path('/Users/carlos/Projects/slotstream');exe=repo/'apps/macos/.build/release/sevra-mac-checks'
def vm():
 raw=subprocess.check_output(['vm_stat'],text=True);v={k:int(x) for k,x in re.findall(r'^([^:\n]+):\s+(\d+)\.',raw,re.M)};s=int(re.search(r'page size of (\d+)',raw).group(1));return {'reclaimableGB':sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*s/1e9,'swapins':v['Swapins'],'swapouts':v['Swapouts']}
tests={'metrics-mtp':(26,['--real-metrics','--budget','32','--mtp-profile-gb','26']), 'cache-mtp':(26,['--real-cache','--mtp-profile-gb','26']), 'thinking-mtp':(26,['--real-thinking','--budget','24','--answer-after','2','--mtp-profile-gb','26']), 'tools-mtp':(26,['--real','--source',str(repo/'apps/macos/Fixtures/private-workspace-brief'),'--mtp-profile-gb','26']), 'performance':(10,['--performance-real']), 'cache-small':(10,['--real-cache'])}
assert subprocess.run(['pgrep','-x','Sevra'],capture_output=True).returncode!=0,'Quit app first'
for label in sys.argv[1:]:
 budget,flags=tests[label.split('-retry')[0]];home=root/'homes'/label;before=vm();assert before['reclaimableGB']>=budget+3,before;assert not home.exists()
 cmd=[str(exe),*flags,'--home',str(home)];samples=[];start=time.time()
 with (root/(label+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  try:
   while p.poll() is None:
    if time.time()-start>750:raise TimeoutError(label)
    probe=subprocess.run(['/tmp/slotstream-release-calibration-20260922/probe',str(p.pid)],capture_output=True,text=True)
    if probe.returncode==0:samples.append({'time':time.time(),'process':json.loads(probe.stdout),'vm':vm()})
    time.sleep(1)
  finally:
   if p.poll() is None:p.terminate()
   rc=p.wait(timeout=30)
 receipt={'label':label,'budgetGB':budget,'command':cmd,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'exit_code':rc,'before':before,'after':vm(),'elapsed':time.time()-start,'samples':samples}
 (root/(label+'.json')).write_text(json.dumps(receipt,indent=2))
 print(json.dumps({k:receipt[k] for k in ['label','exit_code','before','after','elapsed']}),flush=True)
 assert rc==0,label
