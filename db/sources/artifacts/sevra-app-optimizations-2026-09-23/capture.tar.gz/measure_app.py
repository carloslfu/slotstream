import pathlib,subprocess,json,time,sys
r=pathlib.Path('/tmp/sevra-app-opt-20260923');home=pathlib.Path('/Users/carlos/Sevra/Home');thread=json.loads((r/'app-thread.json').read_text());cli='/Users/carlos/Projects/slotstream/apps/macos/.build/release/sevra-local'
def state():
 x=json.loads(subprocess.check_output(['dbmd','show',thread['path'],'--json'],text=True));return json.loads(x['body'])
def wait_done():
 start=time.monotonic()
 while time.monotonic()-start<240:
  s=state();run=s.get('run') or {}
  if run.get('state') in ['completed','failed','stopped','interrupted','done','needsYou']:return run
  time.sleep(.5)
 raise RuntimeError('Timed out, no request resubmitted')
def filtered(run):return {k:run.get(k) for k in ['id','state','status','metrics']}
results=[]
if '--reload' in sys.argv:
 cases=[('reloaded-short','Reply with one friendly sentence saying hello.')]
else:
 run=wait_done();row={'label':'cold-bicycle','run':filtered(run),'captured_at':time.time()};results.append(row);(r/'app-cold-bicycle.json').write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
 assert run.get('state')=='completed' and run.get('metrics')
 cases=[('warm-rain','Performance test 2: In about 180 words, explain how rain forms and why some clouds do not produce rain. Use three short paragraphs. Answer directly without tools.'),('warm-caching','Performance test 3: In about 180 words, explain the difference between RAM and SSD storage, and why caching helps a computer. Use three short paragraphs. Answer directly without tools.'),('warm-short','Reply with one friendly sentence saying hello.')]
for label,prompt in cases:
 start=time.time()
 with (r/('app-'+label+'.log')).open('w') as log:p=subprocess.run([cli,'chat','--home',str(home),'--thread',thread['id'],'--prompt',prompt,'--nonce','sevra-optimized-20260923-'+label],stdout=log,stderr=subprocess.STDOUT,timeout=240)
 run=wait_done();row={'label':label,'prompt':prompt,'client_seconds':time.time()-start,'exit_code':p.returncode,'run':filtered(run),'captured_at':time.time()};results.append(row);(r/('app-'+label+'.json')).write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
 assert p.returncode==0 and run.get('state')=='completed' and run.get('metrics')
(r/('app-reload-results.json' if '--reload' in sys.argv else 'app-results.json')).write_text(json.dumps(results,indent=2))
