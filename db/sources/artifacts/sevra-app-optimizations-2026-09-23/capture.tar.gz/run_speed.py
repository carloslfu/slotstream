import pathlib,subprocess,json,time,re,sys,hashlib
root=pathlib.Path('/tmp/sevra-app-opt-20260923');exe=pathlib.Path('/Users/carlos/Projects/slotstream/apps/macos/.build/release/sevra-mac-checks')
def vm():
 raw=subprocess.check_output(['vm_stat'],text=True);v={k:int(x) for k,x in re.findall(r'^([^:\n]+):\s+(\d+)\.',raw,re.M)};s=int(re.search(r'page size of (\d+)',raw).group(1));return {'reclaimableGB':sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*s/1e9,'swapins':v['Swapins'],'swapouts':v['Swapouts']}
budget=float(sys.argv[1]);arms=sys.argv[2:]
assert subprocess.run(['pgrep','-x','Sevra'],capture_output=True).returncode!=0,'Quit app first'
for spec in arms:
 # Let XNU's shared one-second VM-statistics window expire after prior process exit.
 time.sleep(1.1)
 arm,label=spec.split(':');before=vm();assert before['reclaimableGB']>=budget+3,before
 cmd=[str(exe),'--real-speed','--memory-gb',str(budget),'--arm',arm] + (['--extended'] if label.startswith('pair-') else ['--short-only'] if label.startswith('final-') else [])
 samples=[];start=time.time()
 with (root/(label+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT)
  try:
   while p.poll() is None:
    if time.time()-start>480:raise TimeoutError(label)
    probe=subprocess.run(['/tmp/slotstream-release-calibration-20260922/probe',str(p.pid)],capture_output=True,text=True)
    if probe.returncode==0:samples.append({'time':time.time(),'process':json.loads(probe.stdout),'vm':vm()})
    time.sleep(1)
  finally:
   if p.poll() is None:p.terminate()
   rc=p.wait(timeout=30)
 rows=[json.loads(l[6:]) for l in (root/(label+'.log')).read_text().splitlines() if l.startswith('SPEED ')]
 receipt={'label':label,'arm':arm,'budgetGB':budget,'command':cmd,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'exit_code':rc,'before':before,'after':vm(),'elapsed':time.time()-start,'samples':samples,'rows':rows}
 (root/(label+'.json')).write_text(json.dumps(receipt,indent=2))
 print(json.dumps({k:receipt[k] for k in ['label','exit_code','before','after','elapsed']}),flush=True)
 for row in rows:
  if 'stats' in row:
   s=row['stats'];print(row['case'],json.dumps({k:s.get(k) for k in ['promptTokens','reusedPrefixTokens','prefillSeconds','decodeTokens','decodeSeconds','firstTokenSeconds','peakMemoryGB','draftedTokens','acceptedDrafts']}),flush=True)
 assert rc==0,label
