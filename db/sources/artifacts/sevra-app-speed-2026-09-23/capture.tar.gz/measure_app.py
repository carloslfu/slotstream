from pathlib import Path
import subprocess,json,time
root=Path('/tmp/sevra-app-speed-20260923'); thread=json.loads((root/'thread.json').read_text());home=Path('/Users/carlos/Sevra/Home/db');cli='/Users/carlos/Projects/slotstream/apps/macos/.build/release/sevra-local'
def state():
 x=json.loads(subprocess.check_output(['dbmd','show',thread['path'],'--json'],cwd=home,text=True));return json.loads(x['body'])
def wait_done():
 start=time.monotonic()
 while time.monotonic()-start<240:
  s=state();r=s.get('run') or {}
  if r.get('state') in ['completed','failed','stopped','interrupted','done','needsYou']:
   return s,r
  time.sleep(1)
 raise RuntimeError('App request exceeded observation timeout; no request resubmitted')
results=[]
s,r=wait_done();results.append({'label':'cold-bicycle','run':r,'captured_at':time.time()});(root/'cold-bicycle.json').write_text(json.dumps(results[-1],indent=2));print('cold-bicycle',json.dumps({'state':r.get('state'),'metrics':r.get('metrics')}),flush=True)
assert r.get('metrics'),r.get('state')
for label,prompt in [('warm-rain','Performance test 2: In about 180 words, explain how rain forms and why some clouds do not produce rain. Use three short paragraphs. Answer directly without tools.'),('warm-caching','Performance test 3: In about 180 words, explain the difference between RAM and SSD storage, and why caching helps a computer. Use three short paragraphs. Answer directly without tools.'),('warm-short','Reply with one friendly sentence saying hello.')]:
 start=time.time()
 with (root/(label+'.log')).open('w') as log:
  p=subprocess.run([cli,'chat','--home',str(home.parent),'--thread',thread['id'],'--prompt',prompt,'--nonce','sevra-speed-20260923-'+label],stdout=log,stderr=subprocess.STDOUT,timeout=240)
 s,r=wait_done();row={'label':label,'prompt':prompt,'client_seconds':time.time()-start,'exit_code':p.returncode,'run':r,'captured_at':time.time()};results.append(row);(root/(label+'.json')).write_text(json.dumps(row,indent=2));print(label,json.dumps({'state':r.get('state'),'metrics':r.get('metrics')}),flush=True)
 assert p.returncode==0 and r.get('metrics'),row
(root/'app-results.json').write_text(json.dumps(results,indent=2))
