import subprocess,pathlib,json,time,re,hashlib
r=pathlib.Path('/tmp/sevra-app-speed-20260923');exe='/Users/carlos/.slotstream/bin/slotstream'
for _ in range(30):
 if subprocess.run(['pgrep','-x','Sevra'],capture_output=True).returncode!=0:break
 time.sleep(.2)
else:raise RuntimeError('App is still running; comparison not started')
raw=subprocess.check_output(['vm_stat'],text=True);v={k:int(x) for k,x in re.findall(r'^([^:\n]+):\s+(\d+)\.',raw,re.M)};size=int(re.search(r'page size of (\d+)',raw).group(1));free=sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*size/1e9
assert free>=36,free
cmd=[exe,'mtp-bench','--memory-gb','33','--vision','off','--max-context','32768','--max-tokens','192','--pairs','3','--arms','plain,spec','--prompt','In about 180 words, explain the difference between RAM and SSD storage, and why caching helps a computer. Use three short paragraphs.']
receipt={'command':cmd,'reclaimableGB':free,'started':time.time(),'binary_sha256':hashlib.sha256(pathlib.Path(exe).read_bytes()).hexdigest(),'method':'One engine with MTP head retained in both arms, both warmed, order rotates across three pairs; equal pool isolates the loop but differs from the app memory plan. Greedy outputs compared by built-in diagnostic; timing is diagnostic if global paging/load occurs.'}
(r/'mtp-method.json').write_text(json.dumps(receipt,indent=2))
with (r/'mtp-qualified-comparison.log').open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);receipt['pid']=p.pid
 try:rc=p.wait(timeout=300)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=30);raise
receipt.update(exit_code=rc,finished=time.time(),reaped=True);(r/'mtp-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
assert rc==0
