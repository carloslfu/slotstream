import sys,json,time
from pathlib import Path
sys.path.insert(0,str(Path('Tools').resolve()))
import serve_bench
from thermal_readiness import observe
root=Path(__file__).resolve().parent
original=serve_bench.reserved_cooldown

def ready_cooldown(seconds,wait_limit,lock_path=None):
 started=time.monotonic();stable=0;observations=[]
 while time.monotonic()-started<180 and stable<10:
  item=observe();observations.append(item)
  stable=stable+1 if item['ready'] else 0
  time.sleep(1)
 with (root/'barrier-readiness.jsonl').open('a') as f:f.write(json.dumps({'seconds':time.monotonic()-started,'observations':observations,'passed':stable==10})+'\n')
 if stable!=10:raise RuntimeError('nominal thermal readiness did not return within 180 seconds')
 return original(seconds,wait_limit,lock_path)
serve_bench.reserved_cooldown=ready_cooldown
for kind in ['reasoning','prose']:
 sys.argv=['serve_bench.py','--protocol',str(root/(kind+'-protocol.json')),'--out',str(root/('barrier-'+kind))]
 result=serve_bench.main();print(json.dumps({'cohort':kind,'exit':result}),flush=True)
