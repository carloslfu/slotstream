import json,os,sys,re
from pathlib import Path
sys.path.insert(0,str(Path('Tools').resolve()))
from prefill_bench import preflight,run_child,vm_snapshot
from serve_bench import verified_build
root=Path(__file__).resolve().parent
binary=root/'build-final/candidate/slotstream';verified_build(binary)
out=root/'final-checks';out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))}
cases=[('state',[str(binary),'optimization-state-check','--variant','decode-barrier','--tokens','256','--json'],{},13),('lifecycle',[str(binary),'optimization-state-check','--variant','lifecycle','--json'],{'SLOTSTREAM_DECODE_BARRIER_LAYERS':'4'},13),('passcost',[str(binary),'mtp-passcost','--memory-gb','13','--max-context','8192','--positions','2','--max-batch','3','--max-tokens','32','--attention-modes','stock,split,exact','--settle-before-timing'],{},16),('static',['bash','Tools/static_gates.sh'],{'SLOTSTREAM_TEST_BINARY':str(binary)},13)]
for name,command,extra,headroom in cases:
 preflight(headroom);cell=out/name;cell.mkdir();before=vm_snapshot()
 code=run_child(command,env|extra,cell,1200);after=vm_snapshot()
 record=dict(command=command,env=extra,exit=code,before=before,after=after,classification='functional checks; no timing claims')
 if name in ['state','lifecycle'] and code==0:
  data=json.loads((cell/'stdout.txt').read_text());record['passed']=data['passed'];record['assertions']=len(data['items'])
 if name=='passcost' and code==0:
  text=(cell/'stdout.txt').read_text();samples=re.findall(r'PASSCOST_SAMPLE pos=(\d+) rows=(\d+) mode=(\S+) ms=(\S+) misses=(\d+)',text)
  peak=re.findall(r'PASSCOST_PEAK bytes=(\d+)',text)
  record['passed']=len(samples)==18 and all(int(x[-1])==0 for x in samples) and 'PASSCOST_WINDOW ' in text and bool(peak) and int(peak[-1])<=13_000_000_000
  record['samples']=len(samples);record['peak_bytes']=int(peak[-1]) if peak else None
 (cell/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:v for k,v in record.items() if k in ['exit','passed','assertions','samples','peak_bytes']}|{'check':name}),flush=True)
 if code or record.get('passed') is False:sys.exit(code or 1)
