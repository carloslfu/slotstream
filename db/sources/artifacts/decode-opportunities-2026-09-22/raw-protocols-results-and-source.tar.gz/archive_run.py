import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=Path('db/sources/artifacts/decode-opportunities-2026-09-22')
out.mkdir(parents=True,exist_ok=False)
selected=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or 'archive' in p.relative_to(root).parts:continue
 if p.name in ['slotstream','slotstream-checks','mlx.metallib'] or p.suffix=='.pyc':continue
 selected.append(p)
manifest={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in selected}
archive=out/'raw-protocols-results-and-source.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in selected:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
receipt=dict(schema='decode-opportunities-artifact-v1',archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=manifest,scope='M5 Pro, macOS 25G83, MLX 0.32.2, baseline 14fb9aa; rejected prototypes and excluded/interrupted trials retained; no weight files or executables')
(out/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=receipt['archive_sha256'],members=len(selected))))
