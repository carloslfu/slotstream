import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
all_pairs=[];result={}
for d in sorted(root.glob('barrier-*')):
 if not d.is_dir() or not (d/'results.jsonl').exists(): continue
 rows=[json.loads(l) for l in (d/'results.jsonl').read_text().splitlines()]
 pairs=[]
 for n in sorted({r['round'] for r in rows}):
  a=next((r for r in rows if r['round']==n and r['arm']=='reference'),None)
  b=next((r for r in rows if r['round']==n and r['arm']=='barrier4'),None)
  if not a or not b or 'metrics' not in a or 'metrics' not in b: continue
  am,bm=a['metrics'],b['metrics'];x,y=am['stats'],bm['stats']
  p=dict(round=n,clean=a['valid'] and b['valid'],exact=am['output_ids']==bm['output_ids'] and a['text']==b['text'],slots=[am['effective_pool_slots'],bm['effective_pool_slots']],seconds=[x['decodeSeconds'],y['decodeSeconds']],reduction=1-y['decodeSeconds']/x['decodeSeconds'],records=[x['decodeRecords'],y['decodeRecords']],peakGB=[x['peakMemoryGB'],y['peakMemoryGB']],tokens=[x['decodeTokens'],y['decodeTokens']],same_work=all(x[k]==y[k] for k in ['decodeTokens','decodeForwardPasses','decodeModelTokens','draftedTokens','verifyPasses']))
  pairs.append(p)
 eligible=[p for p in pairs if p['clean'] and p['exact'] and p['same_work'] and p['slots'][0]==p['slots'][1]]
 summary=dict(cells=len(rows),exclusions=[dict(round=r['round'],arm=r['arm'],reason=r.get('exclusion',r.get('error'))) for r in rows if not r['valid']],pairs=pairs,median_reduction=statistics.median(p['reduction'] for p in eligible) if eligible else None)
 result[d.name]=summary;all_pairs+=eligible
result['aggregate']=dict(eligible_pairs=len(all_pairs),median_reduction=statistics.median(p['reduction'] for p in all_pairs) if all_pairs else None)
print(json.dumps(result,indent=2))
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
