import MLX
import MLXNN

/// Fused pointwise work around the hyper-connection read's two small matmuls:
/// the gate input `silu(down / hc)`, the stream mix `sigmoid(up) * normed`
/// reduced over the streams, and the inject `2 * sigmoid(p / hc)`. Each stage
/// is one kernel instead of two to four (the dispatch census of 2026-09-16
/// counted about 1,500 sigmoid, multiply, add and divide launches per verify
/// pass, a large share of them here). The matmuls, the reshapes and the bf16
/// rounding boundaries stay where the eager path has them; the reshapes stay
/// outside the compiled functions, which are shapeless. An instance exists
/// only after every stage reproduces the eager arithmetic bit for bit.
package final class CompiledHyperRead {
    private let gateFn: ([MLXArray]) -> [MLXArray]
    private let mixFn: ([MLXArray]) -> [MLXArray]
    private let injectFn: ([MLXArray]) -> [MLXArray]

    private init(hcCount: Int) {
        let hc = Float(hcCount)
        gateFn = compile(shapeless: true) { (v: [MLXArray]) -> [MLXArray] in
            let t = v[0] / hc
            return [t * sigmoid(t)]
        }
        mixFn = compile(shapeless: true) { (v: [MLXArray]) -> [MLXArray] in
            [(sigmoid(v[0]) * v[1]).mean(axis: -2)]
        }
        injectFn = compile(shapeless: true) { (v: [MLXArray]) -> [MLXArray] in
            [2 * sigmoid(v[0] / hc)]
        }
    }

    /// `silu(downOut / hc)`, the input of the up projection.
    func gate(_ downOut: MLXArray) -> MLXArray { gateFn([downOut]).first ?? MLXArray(0) }
    /// `(sigmoid(upOut) * normed).mean(axis: -2)` over `[..., hc, hidden]` inputs.
    func mix(_ upOut: MLXArray, _ normed: MLXArray) -> MLXArray { mixFn([upOut, normed]).first ?? MLXArray(0) }
    /// `2 * sigmoid(projected / hc)`.
    func inject(_ projected: MLXArray) -> MLXArray { injectFn([projected]).first ?? MLXArray(0) }

    static func referenceGate(_ downOut: MLXArray, hc: Float) -> MLXArray { MLXNN.silu(downOut / hc) }
    static func referenceMix(_ upOut: MLXArray, _ normed: MLXArray) -> MLXArray { (sigmoid(upOut) * normed).mean(axis: -2) }
    static func referenceInject(_ projected: MLXArray, hc: Float) -> MLXArray { 2 * sigmoid(projected / hc) }

    /// Deterministic bf16 test values a few units wide.
    private static func values(_ shape: [Int], phase: Float) -> MLXArray {
        let count = shape.reduce(1, *)
        let ramp = MLXArray((0 ..< count).map { Float($0) })
        return (sin(ramp * 0.37 + phase) * 2.5).reshaped(shape).asType(.bfloat16)
    }

    /// The fused read for this model's stream count, or nil when any stage
    /// differs from the eager arithmetic by a single bit (the caller then
    /// keeps the eager chain, as `CompiledArithmetic` does).
    package static func prepared(hcCount: Int, lowRank: Int, hiddenSize: Int) -> CompiledHyperRead? {
        let fused = CompiledHyperRead(hcCount: hcCount)
        let hc = Float(hcCount)
        do {
            let exact = try withError { _ -> Bool in
                for rows in [1, 2, 3, 8] {
                let downOut = values([1, rows, lowRank], phase: 0.1)
                let upOut = values([1, rows, hcCount, hiddenSize], phase: 0.7)
                let normed = values([1, rows, hcCount, hiddenSize], phase: 1.9)
                let projected = values([1, rows, hcCount], phase: 2.3)
                let gate = fused.gate(downOut), mix = fused.mix(upOut, normed), inject = fused.inject(projected)
                eval(gate, mix, inject)
                let equal = gate.dtype == .bfloat16 && mix.dtype == .bfloat16 && inject.dtype == .bfloat16
                    && (gate .== referenceGate(downOut, hc: hc)).all().item(Bool.self)
                    && (mix .== referenceMix(upOut, normed)).all().item(Bool.self)
                    && (inject .== referenceInject(projected, hc: hc)).all().item(Bool.self)
                if !equal { return false }
                }
                return true
            }
            return exact ? fused : nil
        } catch { return nil }
    }
}
