import json,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
identity=json.loads((r/'build-v1/candidate/build-identity.json').read_text())
machine='[[records/machines/macbook-pro-m5-pro-48gb]]'
run_common=dict(tool='Frozen Swift model/state checks, served-request A/B and verification-pass timing',command='Tools/optimization_build.py; Tools/serve_bench.py; barrier_remaining.py; hc_run_v2.py; hc_run_v3.py; hc_run.py; final_v2_checks.py (exact arguments in archived scripts/manifests)',binary=identity['binary_sha256'],machines=machine,captured_at='2026-09-22')
records=[
 ('sources/runs/2026/09/2026-09-22-decode-opportunities.md','run','Decode opportunities: current-backend eligible timing and correctness','run-body.txt',run_common|{'discarded':'false'}),
 ('sources/runs/2026/09/2026-09-22-decode-opportunities-excluded.md','run','Decode opportunities: excluded timing, interrupted trials and original test failures','excluded-body.txt',run_common|{'discarded':'true'}),
 ('records/measurements/decode-opportunities-2026-09-22.md','measurement','Remaining decode opportunities: current-backend tests do not qualify new defaults','measurement-body.txt',dict(doc='measurements',order='1616',level='2',date='2026-09-22',status='measured',machines=machine,runs='[[sources/runs/2026/09/2026-09-22-decode-opportunities]], [[sources/runs/2026/09/2026-09-22-decode-opportunities-excluded]]')),
 ('records/decisions/decode-opportunities-stay-opt-in-2026-09-22.md','decision','Keep existing decode barriers and remove the unhelpful fusion prototype','decision-body.txt',dict(decided_on='2026-09-22',status='standing',evidence='[[records/measurements/decode-opportunities-2026-09-22]]',reversible_if='A changed mechanism/backend demonstrates at least 3% repeatable paired request-level gain at the intended memory profile with exact outputs/state, matched work, bounded memory and preserved exclusions.')),
]
for path,kind,title,body,fm in records:
 cmd=['dbmd','write',path,'--type',kind,'--summary',title,'--body-file',str(r/body),'--dir','db','--json']
 for key,value in ({'title':title}|fm).items():cmd+=['--fm',key+'='+value]
 p=subprocess.run(cmd,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 print(p.stdout.strip())
