import json,os,sys,time,re,statistics
from pathlib import Path
sys.path.insert(0,str(Path('Tools').resolve()))
from prefill_bench import preflight,run_child,vm_snapshot,host_conditions
from serve_bench import verified_build
root=Path(__file__).resolve().parent
binary=root/'build-v2/candidate/slotstream'
identity=verified_build(binary)
output=root/'hc-results';output.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))}
(output/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for variant in ['decode-barrier','compiled-hc']:
 preflight(13)
 cell=output/variant;cell.mkdir()
 command=[str(binary),'optimization-state-check','--variant',variant,'--tokens','256','--json']
 before=vm_snapshot();code=run_child(command,env,cell,600);after=vm_snapshot()
 (cell/'command.json').write_text(json.dumps(dict(command=command,exit=code,before=before,after=after),indent=2)+'\n')
 print(json.dumps(dict(check=variant,exit=code)),flush=True)
 if code:sys.exit(code)
for size in ['4k','8k']:
 for rnd in range(1,4):
  preflight(16)
  cell=output/f'{size}-r{rnd}';cell.mkdir()
  command=[str(binary),'mtp-passcost','--memory-gb','13','--max-context','16384','--prompt-file',str(root/f'hc-{size}.txt'),'--positions','12','--max-batch','3','--max-tokens','64','--attention-modes','stock,stock-hc','--production-attention']
  before=vm_snapshot();host_before=host_conditions();code=run_child(command,env,cell,600);after=vm_snapshot();host_after=host_conditions()
  text='\n'.join(p.read_text() for p in cell.glob('*.txt'))
  samples=[dict(pos=int(p),rows=int(k),mode=m,ms=float(t),misses=int(n)) for p,k,m,t,n in re.findall(r'HC_SAMPLE pos=(\d+) rows=(\d+) mode=(\S+) ms=(\S+) misses=(\d+)',text)]
  exact=[dict(pos=int(p),rows=int(k),mode=m,maxDiff=float(d),flips=int(f)) for p,k,m,d,f in re.findall(r'HC_EXACT pos=(\d+) rows=(\d+) mode=(\S+) maxDiff=(\S+) flips=(\d+)',text)]
  peak=re.findall(r'HC_PEAK bytes=(\d+)',text);engaged=re.findall(r'fused hyper reads: (\d+)',text)
  record=dict(command=command,exit=code,before=before,after=after,host_before=host_before,host_after=host_after,samples=samples,exact=exact,peak_bytes=int(peak[-1]) if peak else None,engaged=int(engaged[-1]) if engaged else 0)
  record['functional_pass']=code==0 and len(samples)==72 and len(exact)==36 and all(x['maxDiff']==0 and x['flips']==0 for x in exact) and record['engaged']>0
  record['all_hit']=bool(samples) and all(x['misses']==0 for x in samples)
  record['swap_clean']=all(before[k]==after[k] for k in ['swapins','swapouts'])
  for k in [1,2,3]:
   pairs={}
   for x in samples:
    if x['rows']==k:pairs.setdefault(x['pos'],{})[x['mode']]=x['ms']
   record[f'rows{k}_paired_reductions']=[1-p['stock-hc']/p['stock'] for p in pairs.values() if set(p)=={'stock','stock-hc'}]
  (cell/'result.json').write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({k:v for k,v in record.items() if k in ['exit','functional_pass','all_hit','swap_clean','peak_bytes','engaged']}|{'context':size,'round':rnd,'median_rows3':statistics.median(record['rows3_paired_reductions']) if record['rows3_paired_reductions'] else None}),flush=True)
  if not record['functional_pass'] or not record['all_hit'] or record['peak_bytes']>13e9:sys.exit(1)
