#!/usr/bin/env python3
"""Offline analysis only. No model execution and no filtering on observed speed."""
import collections, hashlib, json, math, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
rows=[json.loads(line) for line in (ROOT/'study/results.jsonl').read_text().splitlines()]
med=statistics.median

def get(row,phase='measured'): return row[phase]['metrics']['stats']
def speed(row,phase='measured'):
    s=get(row,phase);return s['decodeTokens']/s['decodeSeconds']
def median_for(rows,fn): return med([fn(r) for r in rows]) if rows else None

def summarize_rows(rs,phase='measured'):
    valid=[r for r in rs if r.get(phase,{}).get('valid',False)]
    def ms(f): return median_for(valid,lambda r:f(get(r,phase)))
    outputs={tuple(r[phase]['metrics']['output_ids']) for r in valid}
    return {'runs':len(rs),'clean_runs':len(valid),'median_tps':median_for(valid,lambda r:speed(r,phase)),
      'median_decode_seconds':ms(lambda s:s['decodeSeconds']),
      'median_client_seconds':median_for(valid,lambda r:r[phase]['client_seconds']),
      'median_first_visible_seconds':median_for(valid,lambda r:r[phase]['first_visible_text_seconds']),
      'median_read_MB_per_output':ms(lambda s:s['decodeReadBytes']/s['decodeTokens']/1e6),
      'median_acceptance':ms(lambda s:s['acceptedDrafts']/s['draftedTokens'] if s['draftedTokens'] else 0),
      'median_output_tokens_per_verify':ms(lambda s:s['decodeTokens']/s['verifyPasses'] if s['verifyPasses'] else 1),
      'median_draft_fraction':ms(lambda s:s['draftSeconds']/s['decodeSeconds']),
      'median_verify_fraction':ms(lambda s:s['verifySeconds']/s['decodeSeconds']),
      'median_reconciliation_fraction':ms(lambda s:s['reconciliationSeconds']/s['decodeSeconds']),
      'maximum_sampled_footprint_gb':max((get(r,phase)['sampledFootprint']['peakBytes']/1e9 for r in valid),default=None),
      'effective_pool_slots':sorted({r[phase]['metrics']['effective_pool_slots'] for r in rs if phase in r}),
      'unique_output_sequences':len(outputs)}

summaries={}
for prompt in P['prompts']:
    summaries[prompt]={str(d):summarize_rows([r for r in rows if r['prompt']==prompt and r['depth']==d]) for d in P['depths']}
lookup={(r['round'],r['prompt'],r['depth']):r for r in rows}
comparisons={}
for d in P['depths']:
    if d==1:continue
    workloads={}
    for prompt in P['prompts']:
        pairs=[]
        for rnd in range(1,P['rounds']+1):
            b=lookup.get((rnd,prompt,1));c=lookup.get((rnd,prompt,d))
            if not b or not c:continue
            if not b['valid'] or not c['valid']: continue
            pairs.append({'round':rnd,'ratio_to_depth1':speed(c)/speed(b),
                          'client_speed_ratio':b['measured']['client_seconds']/c['measured']['client_seconds'],
                          'output_ids_equal':b['measured']['metrics']['output_ids']==c['measured']['metrics']['output_ids']})
        workloads[prompt]={'pairs':pairs,'count':len(pairs),
                           'median_ratio':med([p['ratio_to_depth1'] for p in pairs]) if pairs else None}
    enough=all(w['count']>=P['minimum_clean_pairs_per_workload'] for w in workloads.values())
    ratios=[w['median_ratio'] for w in workloads.values() if w['median_ratio'] is not None]
    overall=math.prod(ratios)**(1/len(ratios)) if len(ratios)==len(P['prompts']) else None
    comparisons[str(d)]={'workloads':workloads,'enough_clean_pairs':enough,'geomean_median_ratio':overall,
        'passes_frozen_selection':bool(enough and overall>=1+P['minimum_median_gain_to_change_default'] and min(ratios)>=.95)}
result={'scope':P['scope'],'completed_cells':len(rows),'planned_cells':P['rounds']*len(P['depths'])*len(P['prompts']),
        'valid_cells':sum(r['valid'] for r in rows),'summaries':summaries,'comparisons_to_depth1':comparisons,
        'first_requests':{prompt:{str(d):summarize_rows([r for r in rows if r['prompt']==prompt and r['depth']==d],'warmup') for d in P['depths']} for prompt in P['prompts']},
        'exclusions':[{'round':r['round'],'prompt':r['prompt'],'depth':r['depth'],
                       'reasons':r.get('measured',{}).get('exclusions'), 'error':r.get('error')} for r in rows if not r['valid']],
        'within_cell_warm_measure_output_differences':[{k:r[k] for k in ['round','prompt','depth']} for r in rows if r.get('same_output_warm_and_measured') is False],
        'finished_processes':all(r.get('process_stopped',False) for r in rows if 'pid' in r)}
(ROOT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
