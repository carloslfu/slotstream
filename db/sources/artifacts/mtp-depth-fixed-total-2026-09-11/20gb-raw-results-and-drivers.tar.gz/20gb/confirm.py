#!/usr/bin/env python3
"""Run the prospectively declared longer-code confirmation after primary completion."""
import json,time
from pathlib import Path
import bench
from prefill_bench import digest,vm_snapshot
from thermal_readiness import observe
ROOT=Path(__file__).resolve().parent
analysis=json.loads((ROOT/'analysis.json').read_text())
plan=json.loads((ROOT/'confirmation-plan.json').read_text())
if analysis['completed_cells']!=analysis['planned_cells']:
    raise SystemExit('Primary incomplete; no confirmation selected.')
eligible=[(float(v['geomean_median_ratio']),int(d)) for d,v in analysis['comparisons_to_depth1'].items()
          if int(d) in (2,3) and v['enough_clean_pairs'] and v['geomean_median_ratio']>1]
if not eligible: raise SystemExit('No eligible candidate under the prospective confirmation rule.')
_,candidate=max(eligible)
out=ROOT/'confirmation';out.mkdir()
bench.P.update(max_tokens=plan['max_tokens'],warm_tokens=plan['warm_tokens'])
bench.P['prompts']={'code':plan['prompt']}
bench.DEADLINE=time.monotonic()+1800
bench.save(out/'freeze.json',{'plan':plan,'candidate':candidate,'effective_protocol':bench.P,
    'primary_analysis_sha256':digest(ROOT/'analysis.json'),'driver_sha256':digest(ROOT/'confirm.py'),
    'bench_sha256':digest(ROOT/'bench.py')})
try:
    for r,order in enumerate(plan['order'],1):
        for d in order:
            depth=candidate if d=='candidate' else d
            row=bench.run_cell(out,r,'code',depth,plan['max_tokens'])
            if row['fatal']:raise SystemExit('Confirmation stopped at unchanged resource/failure gate.')
finally:
    if bench.ACTIVE is not None:bench.stop_server(bench.ACTIVE)
    bench.save(out/'after.json',{'vm':vm_snapshot(),'conditions':observe(),'remaining_jobs':bench.inventory()})
