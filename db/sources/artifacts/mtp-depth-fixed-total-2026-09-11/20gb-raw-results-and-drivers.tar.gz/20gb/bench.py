#!/usr/bin/env python3
"""Frozen bounded MTP-depth comparison; production binary, no profiling patches."""
import argparse, datetime, hashlib, json, os, signal, socket, subprocess, threading, time
from pathlib import Path
from prefill_bench import preflight, vm_snapshot, digest
from serve_bench import request_body, exchange, wait_ready, stop_server, resource_exclusions, competing_jobs
from optimization_readiness import pressure_snapshot, require_normal
from thermal_readiness import observe
HERE=Path(__file__).resolve().parent
P=json.loads((HERE/'protocol.json').read_text())
P.update(maximum_sampled_footprint_bytes=int(P['memory_gb']*1e9),require_nominal_power_state=True)
ROOT=HERE.parent.parent
ACTIVE=None
DEADLINE=0

def save(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n')

def inventory(owned=None):
    r=subprocess.run(['ps','-axo','pid=,comm='],capture_output=True,text=True,check=True,timeout=5)
    jobs=competing_jobs()
    for line in r.stdout.splitlines():
        parts=line.strip().split(None,1)
        if len(parts)==2 and parts[0].isdigit() and Path(parts[1]).name=='slotstream':
            pid=int(parts[0])
            if pid!=owned: jobs.append({'pid':pid,'kind':'other-model-process'})
    return jobs

def stop_signal(sig,frame):
    raise KeyboardInterrupt(f'signal {sig}')

for sig in (signal.SIGTERM,signal.SIGINT): signal.signal(sig,stop_signal)

def cooldown():
    time.sleep(P['cooldown_seconds'])
    limit=time.monotonic()+P['thermal_wait_limit_seconds']
    while not observe()['ready']:
        if time.monotonic()>min(limit,DEADLINE): raise RuntimeError('thermal wait limit/deadline reached')
        time.sleep(5)
    if time.monotonic()>DEADLINE: raise RuntimeError('study deadline reached')

def run_cell(out,round_,prompt_name,depth,tokens,pilot=False):
    global ACTIVE
    cell=out/f'r{round_}-{prompt_name}-d{depth}'
    cell.mkdir()
    row={'round':round_,'prompt':prompt_name,'depth':depth,'pilot':pilot,'valid':False,
         'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    child=None; finished=threading.Event(); monitor=[]; fatal=[]
    try:
        cooldown()
        jobs=inventory()
        if jobs: raise RuntimeError(f'competing jobs: {jobs}')
        row['before_startup']=preflight(P['headroom_gb'])
        row['system_before_startup']=observe()
        require_normal(pressure_snapshot())
        env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))}
        env.update(SLOTSTREAM_BENCH_DETAILS='1',SLOTSTREAM_PREFILL_CHUNK=str(P['prefill_chunk']),
                   SLOTSTREAM_DRAFT_DEPTH=str(max(1,depth)))
        row['environment']={k:v for k,v in env.items() if k.startswith('SLOTSTREAM_')}
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
        command=[P['binary'],'serve','--model',P['model'],'--port',str(port),
                 '--memory-gb',str(P['memory_gb']),'--mtp','on' if depth else 'off',
                 '--no-elastic','--no-prefix-cache','--max-context',str(P['max_context'])]
        row['command']=command
        with (cell/'server.stdout').open('wb') as stdout,(cell/'server.stderr').open('wb') as stderr:
            start=time.monotonic()
            child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            ACTIVE=child; row['pid']=child.pid
            def watchdog():
                baseline=row['before_startup']['swapouts']
                while not finished.wait(2):
                    try:
                        vm=vm_snapshot(); pressure=pressure_snapshot(); state=observe()
                        sample={'elapsed':time.monotonic()-start,'vm':{k:v for k,v in vm.items() if k!='raw'},
                                'pressure':pressure['name'],'conditions':state['conditions']}
                        monitor.append(sample)
                        reason=None
                        if vm['swapouts']>baseline: reason='new swapouts'
                        elif pressure['level']!=1: reason='OS memory pressure'
                        elif vm['reclaimable_bytes']<3e9: reason='reclaimable headroom below 3GB'
                        elif time.monotonic()>DEADLINE: reason='study deadline'
                        if reason:
                            fatal.append(reason)
                            if child.poll() is None: os.killpg(child.pid,signal.SIGTERM)
                            return
                    except Exception as e:
                        fatal.append('watchdog unavailable: '+str(e))
                        if child.poll() is None: os.killpg(child.pid,signal.SIGTERM)
                        return
            watcher=threading.Thread(target=watchdog,daemon=True); watcher.start()
            wait_ready(child,port); row['startup_seconds']=time.monotonic()-start
            config=P|{'max_tokens':tokens}
            body=request_body(config,P['prompts'][prompt_name],images=[])
            for phase in ('warmup','measured'):
                before=vm_snapshot(); hostbefore=observe(); marker=len(monitor)
                result,wire=exchange(port,body,P['timeout_per_request'])
                after=vm_snapshot(); hostafter=observe()
                (cell/(phase+'.ndjson')).write_bytes(wire)
                save(cell/(phase+'.json'),result)
                stats=result['metrics']['stats']; metrics=result['metrics']
                reasons=resource_exclusions(stats,P)
                gb,ga=stats.get('generatorVMBefore'),stats.get('generatorVMAfter')
                if not isinstance(gb,dict) or not isinstance(ga,dict): raise ValueError('missing native VM observations')
                if any(before[k]!=after[k] or gb[k]!=ga[k] for k in ('swapins','swapouts')):
                    reasons.append('swap activity during request')
                if not hostbefore['ready'] or not hostafter['ready'] or any(
                    x['conditions']['thermalState']!='nominal' or x['conditions']['lowPowerModeEnabled'] for x in monitor[marker:]):
                    reasons.append('non-nominal thermal/power observation')
                if stats['decodeTokens']!=tokens: reasons.append('output count differs from frozen length')
                if metrics['effective_mtp'] != bool(depth) or metrics['effective_prefill_chunk']!=P['prefill_chunk']:
                    raise ValueError('effective configuration mismatch')
                if stats.get('reusedPrefixTokens',0)!=0: raise ValueError('unexpected prefix reuse')
                if depth and stats.get('verifyPasses',0)==0: raise ValueError('MTP did not run')
                if not depth and stats.get('draftedTokens',0)!=0: raise ValueError('unexpected drafting in plain arm')
                jobs=inventory(child.pid)
                if jobs: fatal.append('competing jobs during generation'); reasons.append(str(jobs))
                row[phase]={'before':before,'after':after,'host_before':hostbefore,'host_after':hostafter,
                            'valid':not reasons,'exclusions':reasons,**result}
                if any('footprint' in r for r in reasons): fatal.append('footprint gate')
                if fatal: raise RuntimeError('; '.join(fatal))
            row['valid']=row['measured']['valid']
            row['same_output_warm_and_measured']=row['warmup']['metrics']['output_ids']==row['measured']['metrics']['output_ids']
    except BaseException as e:
        row['error']=type(e).__name__+': '+str(e)
        if isinstance(e,(KeyboardInterrupt,SystemExit)): fatal.append('interrupted')
        else: fatal.append('cell failed; stop without replacement')
    finally:
        finished.set()
        if child is not None:
            stop_server(child)
            row['process_exit_code']=child.poll()
            row['process_stopped']=child.poll() is not None
        ACTIVE=None
        if 'watcher' in locals(): watcher.join(timeout=5)
        row['fatal']=fatal; row['monitor']=monitor
        save(cell/'result.json',row)
        with (out/'results.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
    report={k:row[k] for k in ['round','prompt','depth','valid','fatal']}
    if 'error' in row: report['error']=row['error']
    if 'measured' in row:
        stats=row['measured']['metrics']['stats']
        report.update(tps=stats['decodeTokens']/stats['decodeSeconds'],
                      accepted=stats.get('acceptedDrafts'),drafted=stats.get('draftedTokens'),
                      read_gb=stats['decodeReadBytes']/1e9,exclusions=row['measured']['exclusions'],
                      peak_gb=stats['sampledFootprint']['peakBytes']/1e9)
    print(json.dumps(report),flush=True)
    return row

def main():
    global DEADLINE
    parser=argparse.ArgumentParser(); parser.add_argument('--pilot',action='store_true'); args=parser.parse_args()
    out=HERE/('pilot' if args.pilot else 'study'); out.mkdir()
    DEADLINE=time.monotonic()+P['deadline_seconds']
    if digest(Path(P['binary']))!=P['binary_sha256']: raise ValueError('binary identity changed')
    save(out/'freeze.json',{'protocol':P,'files':{p.name:digest(p) for p in HERE.glob('*.py')},
                          'protocol_sha256':digest(HERE/'protocol.json')})
    try:
        if args.pilot:
            row=run_cell(out,0,'code',3,16,True)
            return 0 if row['valid'] and not row['fatal'] else 1
        prompts=list(P['prompts'])
        for r,order in enumerate(P['orders'],1):
            prompt_order=prompts[(r-1)%3:]+prompts[:(r-1)%3]
            for prompt in prompt_order:
                for depth in order:
                    row=run_cell(out,r,prompt,depth,P['max_tokens'])
                    if row['fatal']: return 1
        return 0
    finally:
        if ACTIVE is not None: stop_server(ACTIVE)
        save(out/'after.json',{'vm':vm_snapshot(),'conditions':observe(),'remaining_jobs':inventory()})

if __name__=='__main__': raise SystemExit(main())
