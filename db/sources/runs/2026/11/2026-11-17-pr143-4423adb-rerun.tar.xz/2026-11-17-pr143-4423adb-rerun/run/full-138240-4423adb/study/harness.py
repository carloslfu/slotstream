"""Measure real disk-prefix chat reuse and full-window restart restoration on M4."""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from importlib.metadata import version

from measure_slotstream_capacity_api import digest, image_fixture

# Slotstream resumes only from boundaries at or below 128000 tokens, and production
# clients compact before exceeding it, so longer inputs never occur in service.
MAX_INPUT_TOKENS = 128000

# The usage sequence spends the text file's 128000 tokens on the main conversation:
# 100000 + 6 x 4096 appends + a 2048-token body for the long-reply turn = 126624.
USAGE_MAIN_BODY = 100000
USAGE_APPEND = 4096
USAGE_APPEND_TURNS = 6
USAGE_LONG_BODY = 2048
USAGE_SIDE_BODIES = (16384, 8192)
USAGE_LONG_REPLY = 8192
USAGE_TURN_REPLY = 32
GUARD_SAMPLE_SECONDS = 0.5
# Host swap below 10 MB (640 macOS 16 KB pages) is accepted and recorded (Spike, 2026-11-11).
ACCEPTABLE_SWAPOUT_PAGES = 640

# Mirrors Slotstream ContextGeometry for a held-checkpoint request: every growth step is
# charged as a complete replacement of all attention layers plus the MTP layer.
GUARD_LAYERS = 13
GUARD_ROW_BYTES = 2304
GUARD_POOLED_ROW_BYTES = 256


def guard_charge_bytes(tokens):
    """Upper estimate of RequestControl's next-allocation charge with a held checkpoint at `tokens`."""
    capacity = -(-tokens // 1024) * 1024
    pooled = -(-(tokens // 4) // 256) * 256
    return GUARD_LAYERS * (capacity * GUARD_ROW_BYTES + pooled * GUARD_POOLED_ROW_BYTES)


def guard_slack_bytes():
    """Planner.availabilitySlackGB: max(1.5 GB, 5% of physical RAM)."""
    ram = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True))
    return max(1_500_000_000, int(0.05 * ram))


class GuardSampler:
    """Poll the two readings Slotstream's request guard refuses on.

    Reclaimable memory is compared with the next allocation; any OS pressure level other
    than normal (1) fails the request outright, whatever reclaimable memory remains.
    """

    def __init__(self, path, snapshot):
        self.path, self.snapshot = path, snapshot
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def _loop(self):
        with self.path.open("a") as out:
            while not self.stop_event.is_set():
                state = self.snapshot()
                out.write(
                    json.dumps(
                        dict(
                            t=time.time(),
                            reclaimable_bytes=state["reclaimable_bytes"],
                            swapins=state["swapins"],
                            swapouts=state["swapouts"],
                            pressure_level=int(
                                subprocess.check_output(
                                    ["sysctl", "-n", "kern.memorystatus_vm_pressure_level"],
                                    text=True,
                                )
                            ),
                        )
                    )
                    + "\n"
                )
                out.flush()
                self.stop_event.wait(GUARD_SAMPLE_SECONDS)

    def window_minimum(self, start, end):
        rows = [json.loads(line) for line in self.path.read_text().splitlines() if line]
        values = [r["reclaimable_bytes"] for r in rows if start <= r["t"] <= end]
        return min(values) if values else None

    def close(self):
        self.stop_event.set()
        self.thread.join()


def streaming_digest(path):
    hasher = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def production_launch(catalog_path):
    """Read the mac-flash-next settings that change planning, so a study cannot drift from them."""
    command = json.loads(catalog_path.read_text())["deployments"]["mac-flash-next"]["command"]
    argv = command["argv"]
    return dict(
        env={k: v for k, v in command["env"].items() if k.startswith("SLOTSTREAM_")},
        max_prefill_wait=argv[argv.index("--max-prefill-wait") + 1],
        budget=int(argv[argv.index("--memory-gb") + 1]),
    )


def exact_text(tokenizer, count, source_text=None, offset=0):
    text = source_text or "Context check. " + "".join(
        f"Record {i}: the sensor on line {i % 97} reported {37 + i * 31 % 500} units, note {i}. "
        for i in range(count // 10 + 100)
    )
    ids = tokenizer.encode(text, add_special_tokens=False).ids[offset : offset + count]
    text = tokenizer.decode(ids, skip_special_tokens=False)
    if len(ids) != count or tokenizer.encode(text, add_special_tokens=False).ids != ids:
        raise ValueError("Independent exact-token fixture does not round-trip")
    return text, ids


def validate_response(
    data,
    *,
    context,
    exact_ids=None,
    required_output=None,
    reply_limit=32,
    require_mirror_reads=True,
    replicas=2,
):
    details = data["slotstream_benchmark"]
    stats = details["stats"]
    if not data["done"] or any(
        stats.get(k) for k in ("runtimeError", "requestFailure", "memoryPressureCancelled")
    ):
        raise ValueError("Inference did not complete")
    if exact_ids is not None and details["prompt_ids"] != exact_ids:
        raise ValueError("Input differs from the independent tokenizer")
    if (
        len(details["prompt_ids"]) != stats["promptTokens"]
        or stats["prefillTokens"] != stats["promptTokens"] - stats["reusedPrefixTokens"]
        or len(details["output_ids"]) != stats["decodeTokens"]
        or stats["promptTokens"] + stats["decodeTokens"] > context
        or not 0 < stats["decodeTokens"] <= reply_limit
        or required_output is not None
        and stats["decodeTokens"] != required_output
    ):
        raise ValueError("Input/output delivery or context accounting differs")
    if not details["effective_mtp"] or stats.get("draftedTokens", 0) <= 0:
        raise ValueError("MTP draft work was not exercised")
    if (
        len(stats.get("mirrorBytes", [])) != replicas
        or require_mirror_reads
        and not all(stats["mirrorBytes"])
    ):
        raise ValueError("All checkpoint replicas must serve expert reads")
    return details, stats


def history_accounting(prompt_ids, reused, user_header=None, repeat=False):
    if repeat:
        history = len(prompt_ids)
    elif user_header is None:
        history = 0
    else:
        if not user_header:
            raise ValueError("New-user token marker is empty")
        matches = [
            i
            for i in range(len(prompt_ids) - len(user_header) + 1)
            if prompt_ids[i : i + len(user_header)] == user_header
        ]
        if not matches:
            raise ValueError("Cannot locate the new user message in actual input token IDs")
        history = matches[-1]
    rework = max(0, history - reused)
    return dict(
        historical_tokens=history,
        new_input_tokens=len(prompt_ids) - history,
        historical_reprefill_tokens=rework,
        new_input_prefill_tokens=len(prompt_ids) - reused - rework,
    )


def continuation_accounting(previous, prompt_ids, reused):
    """Count only IDs already observed in the previous prompt/reply as history."""
    known = previous["prompt_ids"] + previous["output_ids"]
    common = 0
    for left, right in zip(known, prompt_ids):
        if left != right:
            break
        common += 1
    rework = max(0, common - reused)
    return dict(
        historical_tokens=common,
        new_input_tokens=len(prompt_ids) - common,
        historical_reprefill_tokens=rework,
        new_input_prefill_tokens=len(prompt_ids) - reused - rework,
        previous_transcript_tokens=len(known),
        previous_transcript_common_tokens=common,
        previous_prompt_prefix_unchanged=common >= len(previous["prompt_ids"]),
    )


def speed_baseline(cell):
    """Reuse a qualified raw fixture, rather than inventing a similar prompt."""
    manifest = json.loads((cell / "manifest.json").read_text())
    raw = json.loads((cell / "main-response.json").read_text())
    body = json.loads((cell / "main-request.json").read_text())
    if (
        manifest.get("context") != 49152
        or not manifest.get("eligible")
        or not manifest.get("owned_server_reaped")
        or any(manifest["swap_delta"].values())
        or not all(manifest[k] for k in ("mtp", "vision", "mirror"))
        or manifest["raw_sha256"] != digest(cell / "main-response.json")
        or not body.get("raw")
        or body.get("images")
        or body["options"] != {"temperature": 0, "seed": 1, "num_predict": 32}
    ):
        raise ValueError("Speed baseline must be the qualified 48K MTP/vision/mirror raw request")
    _, stats = validate_response(raw, context=49152, required_output=32)
    if (
        stats["promptTokens"] != 49120
        or stats["prefillTokens"] != 49120
        or stats["reusedPrefixTokens"]
    ):
        raise ValueError("Speed baseline input accounting differs")
    return manifest, raw, body


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source", "binary", "model", "output", "cache-root"):
        parser.add_argument("--" + name, required=True, type=Path)
    parser.add_argument("--mirror", required=True, type=Path, nargs="+")
    parser.add_argument("--request-timeout", type=int, default=21600)
    parser.add_argument(
        "--runtime-receipt",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "src/hive_frame/data/slotstream-runtime.json",
    )
    parser.add_argument(
        "--catalog",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "config/hive.json",
    )
    parser.add_argument(
        "--text-file",
        type=Path,
        help="Real text whose leading exact tokens replace the generated records",
    )
    parser.add_argument("--budget", type=int, help="Default: the production --memory-gb")
    parser.add_argument("--context", type=int, default=138240)
    parser.add_argument(
        "--boundary-prompts",
        type=int,
        nargs="+",
        help="Append and repeat these exact prompt lengths, then restart at the last length",
    )
    parser.add_argument(
        "--full-window-contexts",
        type=int,
        nargs="+",
        help="Cold/reuse/restart one prompt per context; input is ctx-32, capped at 128000",
    )
    parser.add_argument(
        "--full-window-offset",
        type=int,
        default=0,
        help="Skip this many leading text tokens; ctx4096 needs it because the text cut at "
        "token 4064 ends a Swift declaration and greedy decoding stops after two tokens",
    )
    parser.add_argument(
        "--policy-contexts",
        type=int,
        nargs="+",
        help="Check normal chat and seeded128K reuse at these contexts",
    )
    parser.add_argument(
        "--seed-study",
        type=Path,
        help="Completed source-matched boundary study owning the seed cache",
    )
    parser.add_argument(
        "--seed-cache",
        type=Path,
        help="Copy this independent experimental cache; never use production cache",
    )
    parser.add_argument(
        "--policy-restart-only",
        action="store_true",
        help="Independent128000-token restore check after an excluded restart phase",
    )
    parser.add_argument(
        "--speed-baseline",
        type=Path,
        help="Separate 48K disk-off/on speed study using this completed raw fixture",
    )
    parser.add_argument(
        "--long-speed-comparison",
        action="store_true",
        help="Separate ctx170000/input169500/output64 disk-off/on comparison",
    )
    parser.add_argument(
        "--long-chat-comparison",
        action="store_true",
        help="Separate ctx170000/body169000/up-to64 outputs/four chat turns",
    )
    parser.add_argument(
        "--usage-sequence",
        action="store_true",
        help="One production-context server: a 100000-token chat appended in 4096-token turns "
        "toward 128000 with side conversations and a title request interleaved, an 8192-token "
        "reply near the full window, then a fresh-process replay of that reply; needs --text-file",
    )
    args = parser.parse_args()
    if (
        sum(
            bool(v)
            for v in (
                args.speed_baseline,
                args.long_speed_comparison,
                args.long_chat_comparison,
                args.boundary_prompts,
                args.full_window_contexts,
                args.policy_contexts,
                args.usage_sequence,
            )
        )
        > 1
    ):
        parser.error("Select only one speed-comparison input family")
    if bool(args.policy_contexts) != bool(args.seed_study and args.seed_cache):
        parser.error("Policy checks require both an experimental seed study and its cache")
    if args.policy_contexts and (
        min(args.policy_contexts) < 129057 or max(args.policy_contexts) > 262144
    ):
        parser.error("Policy contexts must fit129025 inputs and32 outputs")
    if args.policy_restart_only and not args.policy_contexts:
        parser.error("Restart-only verification requires policy contexts and the qualified seed")
    if args.boundary_prompts and (
        args.boundary_prompts != sorted(set(args.boundary_prompts))
        or min(args.boundary_prompts) < 1024
        or max(args.boundary_prompts) + 32 > args.context
    ):
        parser.error("Boundary prompts must increase and leave 32 output tokens within context")
    if args.full_window_contexts and (
        args.full_window_contexts != sorted(set(args.full_window_contexts))
        or min(args.full_window_contexts) < 1024 + 32
    ):
        parser.error("Full-window contexts must increase and leave 1024 cacheable input tokens")
    if args.full_window_offset and not (args.full_window_contexts and args.text_file):
        parser.error("--full-window-offset applies only to full-window contexts with --text-file")
    receipt = json.loads(args.runtime_receipt.read_text())
    production = production_launch(args.catalog)
    args.budget = args.budget or production["budget"]
    source_text = args.text_file.read_text() if args.text_file else None
    sys.path.insert(0, str(args.source / "Tools"))
    from context_qualification import observed_model, quiet_preflight, verification_lock
    from prefill_bench import vm_snapshot
    from tokenizers import Tokenizer

    args.output.mkdir(parents=True, exist_ok=False)
    args.cache_root.mkdir(parents=True, exist_ok=False)
    points = [
        {
            "name": "chat-169000-d0",
            "context": 169000,
            "disk_prefix_cache": False,
            "kind": "chat",
            "history_tokens": 32768,
        },
        {
            "name": "chat-169000-d1",
            "context": 169000,
            "disk_prefix_cache": True,
            "kind": "chat",
            "history_tokens": 32768,
        },
        {
            "name": "full-115000-d1",
            "context": 115000,
            "disk_prefix_cache": True,
            "kind": "full_window",
        },
        {
            "name": "full-169000-d1",
            "context": 169000,
            "disk_prefix_cache": True,
            "kind": "full_window",
        },
    ]
    protocol = dict(
        version=7,
        revision=2,
        kind="persistent-prefix-capacity",
        commit=receipt["slotstream_commit"],
        binary_sha256=receipt["binary_sha256"],
        budget_gb=args.budget,
        production_env=production["env"],
        max_prefill_wait=production["max_prefill_wait"],
        text_file_sha256=digest(args.text_file) if args.text_file else None,
        mtp=True,
        vision=True,
        mirror=True,
        prefix_cache=True,
        gpu_keepalive="removed_upstream",
        reply_tokens=32,
        disk_gb=20,
        minimum_tokens=1024,
        image_size=224,
        points=points,
        mirror_read_policy="cold_both_replicas_warm_observed",
        history_reprefill_limit_tokens=1024,
        request_timeout_seconds=args.request_timeout,
        preflight_needed_gb=args.budget + 1.75,
        policy="Predeclared points; no retries within a group. Preserve every outcome, reap the owned server after failure, and continue only independent groups through a fresh quiet preflight.",
        scope="MTP and two physical checkpoint replicas, actual image tower loading, three text-chat turns plus restart, and exact full-window raw cold/reuse/restart phases. Image-state persistence is not claimed.",
    )
    baseline = None
    if args.speed_baseline:
        baseline = speed_baseline(args.speed_baseline)
        prior_protocol = json.loads((args.speed_baseline.parent / "protocol.json").read_text())
        if any(
            prior_protocol[k] != protocol[k]
            for k in ("commit", "binary_sha256", "budget_gb", "reply_tokens")
        ):
            raise ValueError("Historical baseline runtime differs")
        points = [
            dict(
                name=f"full-49152-d{int(disk)}",
                context=49152,
                kind="full_window",
                disk_prefix_cache=disk,
                phase_names=["main", "reuse", "restart"] if disk else ["main", "reuse"],
            )
            for disk in (False, True)
        ]
        protocol.update(
            version=8,
            revision=2,
            kind="persistent-prefix-prefill-speed",
            points=points,
            mirror_read_policy="cold_both_replicas_warm_observed",
            baseline={
                "path": str(args.speed_baseline),
                "files": {
                    name: digest(args.speed_baseline / name)
                    for name in ("manifest.json", "main-request.json", "main-response.json")
                },
            },
            scope="One disk-off/on pair, same 49120-token raw text and 32 output tokens, ctx 49152. "
            "Off first/repeat; on first/repeat/fresh-process restart. Restart compares to the off repeat control. Separate computed-token rate, "
            "restore/save cost, TTFT and HTTP wall time. Filesystem caches are not flushed; "
            "historical baseline is separate from current paired controls. Not a capacity fitting study.",
        )
    if args.long_speed_comparison:
        points = [
            dict(
                name=f"full-170000-d{int(disk)}",
                context=170000,
                kind="full_window",
                prompt_tokens=169500,
                disk_prefix_cache=disk,
                phase_names=["main", "reuse", "restart"] if disk else ["main", "reuse"],
            )
            for disk in (False, True)
        ]
        protocol.update(
            version=9,
            revision=1,
            kind="persistent-prefix-long-speed",
            points=points,
            reply_tokens=64,
            history_reprefill_limit_tokens=1024,
            scope="Exact same 169500-token raw text, ctx170000, exactly64 outputs. Disk-off first/repeat; "
            "disk-on first/repeat/restart. One paired sequence, no filesystem cache flush. "
            "Repeated-input prefill is historical rework; its target is at most1024 tokens. "
            "Not a full-window capacity fitting study, nor a multi-turn chat guarantee.",
        )
    if args.long_chat_comparison:
        points = [
            dict(
                name=f"chat-170000-d{int(disk)}",
                context=170000,
                kind="chat",
                history_tokens=169000,
                disk_prefix_cache=disk,
                chat_turns=4 if disk else 2,
            )
            for disk in (False, True)
        ]
        protocol.update(
            version=10,
            revision=1,
            kind="persistent-prefix-long-chat",
            points=points,
            reply_tokens=64,
            scope="Disk-off first/follow-up, disk-on three turns and restart before turn4. "
            "Initial user body169000 independent tokens, actual rendered counts archived, ctx170000. "
            "Locate new-user boundary in actual token IDs; historical rework target is at most1024. "
            "Not a guarantee for arbitrary session inputs or edited history.",
        )
    reply_limit = protocol["reply_tokens"]
    if args.boundary_prompts:
        points = [
            dict(
                name=f"boundary-ctx{args.context}",
                context=args.context,
                kind="boundary_sequence",
                disk_prefix_cache=True,
                prompt_lengths=args.boundary_prompts,
            )
        ]
        protocol.update(
            version=11,
            revision=1,
            kind="persistent-prefix-boundary",
            points=points,
            scope="One fixed-context text sequence with resident vision and MTP: cold first prompt, "
            "append/repeat at each declared length, then a fresh-process final repeat. "
            "Exact token IDs and historical/new-input counts are archived. Repeat output must match "
            "its preceding request. This is not an independent cold-output comparison at every length, "
            "nor a fit of the full capacity curve. Production prefix files are not used.",
        )
    if args.full_window_contexts:
        points = [
            dict(
                name=f"full-ctx{context}",
                context=context,
                kind="full_window",
                disk_prefix_cache=True,
                prompt_tokens=min(context - reply_limit, MAX_INPUT_TOKENS),
                fixture_offset_tokens=args.full_window_offset,
            )
            for context in args.full_window_contexts
        ]
        protocol.update(
            version=13,
            revision=1,
            kind="persistent-prefix-full-window",
            points=points,
            max_input_tokens=MAX_INPUT_TOKENS,
            scope="One owned production-flag server per context: cold exact-token text, in-process "
            "reuse, then a fresh-process disk restore of the same input. Input is ctx-32 tokens, "
            "capped at the resume ceiling, so contexts above it are not full-window. "
            "Production prefix files are not used.",
        )
    if args.usage_sequence:
        if not args.text_file:
            parser.error("--usage-sequence needs --text-file for the main conversation")
        points = [
            dict(
                name=f"usage-ctx{args.context}",
                context=args.context,
                kind="usage_sequence",
                disk_prefix_cache=True,
                main_body_tokens=USAGE_MAIN_BODY,
                append_tokens=USAGE_APPEND,
                append_turns=USAGE_APPEND_TURNS,
                side_body_tokens=USAGE_SIDE_BODIES,
                long_reply_tokens=USAGE_LONG_REPLY,
            )
        ]
        protocol.update(
            version=14,
            revision=1,
            kind="persistent-prefix-usage-sequence",
            points=points,
            history_reprefill_limit_tokens=1024,
            guard_sample_seconds=GUARD_SAMPLE_SECONDS,
            scope="One production-flag server: a chat whose 100000-token body comes from the text "
            "file grows by 4096-token user turns toward 128000 while two side conversations, a "
            "follow-up to one of them and a short title request share the prefix cache; the last "
            "turn asks for an 8192-token reply, and a fresh process replays that turn from disk. "
            "Every return to a cached conversation must re-prefill at most 1024 history tokens. "
            "The runtime guard's reclaimable-memory reading is sampled throughout and compared "
            "with an upper estimate of its full-copy charge; actual refusals are authoritative. "
            "Production prefix files are not used.",
        )
    if args.policy_contexts:
        prior_protocol = json.loads((args.seed_study / "protocol.json").read_text())
        prior_runs = json.loads((args.seed_study / "runs.json").read_text())
        if (
            len(prior_runs) != 1
            or not prior_runs[0]["completed"]
            or not prior_runs[0]["eligible"]
            or not prior_runs[0]["owned_server_reaped"]
            or any(prior_runs[0]["swap_delta"].values())
            or any(
                prior_protocol[k] != protocol[k]
                for k in ("commit", "binary_sha256", "budget_gb", "reply_tokens")
            )
        ):
            raise ValueError("Seed study is incomplete or belongs to another runtime")
        inventory = [
            {
                "file": str(p.relative_to(args.seed_cache)),
                "bytes": p.stat().st_size,
                "sha256": streaming_digest(p),
            }
            for p in sorted(args.seed_cache.rglob("*"))
            if p.is_file()
        ]
        if not inventory or inventory != prior_runs[0]["cache_inventory"]:
            raise ValueError("Experimental seed cache changed since its verified study")
        points = [
            dict(
                name=f"policy-ctx{context}",
                context=context,
                kind="policy_check",
                disk_prefix_cache=True,
            )
            for context in args.policy_contexts
        ]
        protocol.update(
            version=12,
            revision=1,
            kind="persistent-prefix-policy-check",
            points=points,
            seed=dict(
                study=str(args.seed_study),
                cache=str(args.seed_cache),
                inventory=inventory,
                protocol_sha256=digest(args.seed_study / "protocol.json"),
            ),
            scope="Current-policy normal API chat plus seeded raw128000/128256/129025 repeats "
            "and independent restart at128000. Long requests are warm restores, never cold baselines. "
            "Record zero-history-rework and <=1024 separately. No arbitrary-chat guarantee or curve fit.",
        )
        if args.policy_restart_only:
            for point in points:
                point["kind"] = "policy_restart"
            protocol.update(
                revision=2,
                kind="persistent-prefix-policy-restart-check",
                scope="Independent fresh-process128000-token replay from the qualified experimental seed. "
                "Separate check of a previously paging-excluded restart, never a rerun of unaffected phases. "
                "Not a cold baseline or full-window memory qualification.",
            )
    speed_study = bool(
        args.speed_baseline
        or args.long_speed_comparison
        or args.long_chat_comparison
        or args.boundary_prompts
    )
    if digest(args.binary) != protocol["binary_sha256"]:
        raise ValueError("Installed executable changed")
    if (
        subprocess.check_output(
            ["git", "-C", str(args.source), "rev-parse", "HEAD"], text=True
        ).strip()
        != protocol["commit"]
    ):
        raise ValueError("Source commit changed")
    protocol.update(
        model_identity=observed_model(args.model),
        metallib_sha256=digest(args.binary.parent / "mlx.metallib"),
        harness_sha256=digest(Path(__file__)),
        helper_sha256=digest(Path(__file__).with_name("measure_slotstream_capacity_api.py")),
        tokenizer_version=version("tokenizers"),
    )

    def comparable(identity):
        return {
            k: {f: v for f, v in item.items() if f != "mtime_ns"} for k, item in identity.items()
        }

    # The first mirror keeps the single-mirror field names that the report tools read.
    mirrors = {
        ("mirror" if i == 0 else f"mirror-{i + 1}"): path for i, path in enumerate(args.mirror)
    }
    for label, path in mirrors.items():
        protocol[label.replace("-", "_") + "_identity"] = observed_model(path)
        if comparable(protocol["model_identity"]) != comparable(
            protocol[label.replace("-", "_") + "_identity"]
        ):
            raise ValueError(f"Checkpoint replica {path} differs from the model")
    if baseline and any(
        protocol[k] != prior_protocol[k]
        for k in ("metallib_sha256", "model_identity", "mirror_identity", "tokenizer_version")
    ):
        raise ValueError("Historical baseline model, tokenizer or Metal library differs")
    if args.policy_contexts and any(
        protocol[k] != prior_protocol[k]
        for k in ("metallib_sha256", "model_identity", "mirror_identity", "tokenizer_version")
    ):
        raise ValueError("Seed model, tokenizer or Metal library differs")
    env = {k: v for k, v in os.environ.items() if not k.startswith("SLOTSTREAM_")}
    env.update(production["env"], SLOTSTREAM_BENCH_DETAILS="1")
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    (args.output / "runs.json").write_text("[]\n")
    shutil.copyfile(__file__, args.output / "harness.py")
    shutil.copyfile(
        Path(__file__).with_name("measure_slotstream_capacity_api.py"), args.output / "helper.py"
    )
    if baseline:
        (args.output / "baseline").mkdir()
        for name in protocol["baseline"]["files"]:
            shutil.copyfile(args.speed_baseline / name, args.output / "baseline" / name)
    quiet_preflight(protocol["preflight_needed_gb"])
    for label, model in (("model", args.model), *mirrors.items()):
        with verification_lock(), (args.output / f"{label}-verification.txt").open("w") as log:
            subprocess.run(
                [str(args.binary), "pull", "--verify", "--dir", str(model)],
                cwd=args.source,
                env=env,
                stdout=log,
                stderr=log,
                check=True,
                timeout=600,
            )
    protocol["verification_completed"] = True
    protocol["volumes"] = {
        label: subprocess.check_output(["df", "-P", str(path)], text=True)
        for label, path in (("model", args.model), *mirrors.items(), ("cache", args.cache_root))
    }
    containers = plistlib.loads(subprocess.check_output(["diskutil", "apfs", "list", "-plist"]))[
        "Containers"
    ]
    disks = {}
    for label in ("model", *mirrors, "cache"):
        device = protocol["volumes"][label].splitlines()[-1].split()[0]
        info = plistlib.loads(subprocess.check_output(["diskutil", "info", "-plist", device]))
        container = next(
            c for c in containers if c["ContainerReference"] == info["ParentWholeDisk"]
        )
        disks[label] = {
            "volume": info,
            "physical_stores": [
                plistlib.loads(
                    subprocess.check_output(
                        ["diskutil", "info", "-plist", store["DeviceIdentifier"]]
                    )
                )
                for store in container["PhysicalStores"]
            ],
        }
    protocol["disk_receipts"] = disks
    replica_disks = [
        {p["ParentWholeDisk"] for p in disks[label]["physical_stores"]}
        for label in ("model", *mirrors)
    ]
    if len(set().union(*replica_disks)) != sum(len(d) for d in replica_disks):
        raise ValueError("Checkpoint replicas must use different physical disks")
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    shutil.copyfile(__file__, args.output / "harness.py")
    shutil.copyfile(
        Path(__file__).with_name("measure_slotstream_capacity_api.py"), args.output / "helper.py"
    )
    fixture = image_fixture(224)
    (args.output / "image-224.png").write_bytes(fixture)
    tokenizer = Tokenizer.from_file(str(args.model / "tokenizer.json"))
    user_header = tokenizer.encode("<|im_start|>user\n", add_special_tokens=False).ids
    protocol["chat_user_header_ids"] = user_header
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    rows = []
    sampler = None
    guard_slack = guard_slack_bytes()
    for point in points:
        cell = args.output / point["name"]
        cell.mkdir()
        state_dir = args.cache_root / point["name"]
        if point["kind"] in ("policy_check", "policy_restart"):
            shutil.copytree(args.seed_cache, state_dir)
        row = dict(
            point,
            started_unix=time.time(),
            completed=False,
            mtp=True,
            vision=True,
            mirror=True,
            image_size=224,
            phases=[],
            commands=[],
            server_pids=[],
            purpose="prefill_speed_comparison"
            if speed_study
            else "multi_turn_pilot"
            if point["kind"] == "chat"
            else "training_anchor",
        )
        rows.append(row)
        child, server_log, url, model, plan = None, None, None, None, None

        def request(path, body=None, timeout=None):
            payload = json.dumps(body).encode() if body is not None else None
            req = urllib.request.Request(
                url + path, data=payload, headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=timeout or args.request_timeout) as response:
                return json.load(response)

        def stop():
            nonlocal child, server_log
            if child is not None:
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
                row["owned_server_reaped"] = child.poll() is not None
                child = None
            if server_log is not None:
                server_log.close()
                server_log = None

        def run(name, path, body, ids=None, required_output=None, limit=None):
            (cell / f"{name}-request.json").write_text(json.dumps(body) + "\n")
            before = vm_snapshot()
            started = time.time()
            clock = time.monotonic()
            try:
                data = request(path, body)
            except urllib.error.HTTPError as error:
                (cell / f"{name}-error.json").write_bytes(error.read())
                raise
            wall_seconds = time.monotonic() - clock
            raw = cell / f"{name}-response.json"
            raw.write_text(json.dumps(data) + "\n")
            details, stats = validate_response(
                data,
                context=point["context"],
                exact_ids=ids,
                required_output=required_output,
                reply_limit=limit or reply_limit,
                require_mirror_reads=name == "main"
                or protocol["version"] == 8
                and protocol["revision"] == 1,
                replicas=1 + len(args.mirror),
            )
            if details["effective_pool_slots"] != plan["pool_slots"]:
                raise ValueError("Runtime expert pool changed from the post-image native plan")
            post = request("/api/ps", timeout=10)["models"][0]["size"]
            physical = max(
                post,
                stats["sampledFootprint"]["peakBytes"],
                stats["lifetimeRSSPeakBytes"],
                stats["physicalFootprintEndBytes"],
                stats["lifetimePhysicalFootprintPeakBytes"],
            )
            after = vm_snapshot()
            phase = dict(
                name=name,
                started_unix=started,
                ended_unix=time.time(),
                api=path,
                wall_seconds=wall_seconds,
                server_pid=child.pid,
                prompt_tokens=stats["promptTokens"],
                prefill_tokens=stats["prefillTokens"],
                reply_tokens=stats["decodeTokens"],
                reused_tokens=stats["reusedPrefixTokens"],
                prefill_seconds=stats["prefillSeconds"],
                decode_seconds=stats["decodeSeconds"],
                first_token_seconds=stats.get("firstTokenSeconds"),
                persistent=stats.get("persistentPrefix"),
                observed_peak_bytes=physical,
                raw_sha256=digest(raw),
                post_process_bytes=post,
                swap_delta={k: after[k] - before[k] for k in ("swapins", "swapouts")},
                pool_slots=details["effective_pool_slots"],
                native_ledger=plan["memory_ledger"],
            )
            phase.update(
                history_accounting(
                    details["prompt_ids"],
                    stats["reusedPrefixTokens"],
                    user_header if point["kind"] == "chat" and name != "main" else None,
                    repeat=point["kind"] == "full_window" and name != "main",
                )
            )
            if sampler is not None:
                end_tokens = stats["promptTokens"] + stats["decodeTokens"]
                lowest = sampler.window_minimum(started, phase["ended_unix"])
                charge = guard_charge_bytes(end_tokens)
                phase["guard"] = dict(
                    min_reclaimable_bytes=lowest,
                    full_copy_charge_upper_bytes=charge,
                    slack_bytes=guard_slack,
                    margin_bytes=None if lowest is None else lowest - charge - guard_slack,
                )
            row["phases"].append(phase)
            phase["prefix_cache_after"] = request("/api/show", {"model": model})["details"][
                "prefix_cache"
            ]
            (cell / "manifest.json").write_text(json.dumps(row, indent=2) + "\n")
            (args.output / "runs.json").write_text(json.dumps(rows, indent=2) + "\n")
            print(
                "PHASE",
                name,
                "input",
                phase["prompt_tokens"],
                "reused",
                phase["reused_tokens"],
                "prefill",
                phase["prefill_tokens"],
                "peak",
                physical,
                flush=True,
            )
            if physical > args.budget * 1_000_000_000:
                raise ValueError(f"Whole-process peak exceeded {args.budget} GB")
            if phase["swap_delta"]["swapouts"] >= ACCEPTABLE_SWAPOUT_PAGES:
                raise ValueError("Host swapped out 10 MB or more; preserve and exclude this point")
            return data, details, stats

        def start(name):
            nonlocal child, server_log, url, model, plan
            quiet_preflight(protocol["preflight_needed_gb"])
            with socket.socket() as sock:
                sock.bind(("127.0.0.1", 0))
                port = sock.getsockname()[1]
            url = f"http://127.0.0.1:{port}"
            cmd = [
                str(args.binary),
                "serve",
                "--model",
                str(args.model),
                "--memory-gb",
                str(args.budget),
                "--max-context",
                str(point["context"]),
                "--mtp",
                "on",
                "--vision",
                "on",
                *(arg for path in args.mirror for arg in ("--mirror", str(path))),
                "--max-prefill-wait",
                production["max_prefill_wait"],
                "--port",
                str(port),
            ]
            if point["disk_prefix_cache"]:
                cmd += [
                    "--prefix-cache-dir",
                    str(state_dir),
                    "--prefix-cache-disk-gb",
                    "20",
                    "--prefix-cache-min-tokens",
                    "1024",
                ]
            row["commands"].append(cmd)
            server_log = (cell / f"{name}-server.log").open("w")
            child = subprocess.Popen(
                cmd, cwd=args.source, env=env, stdout=server_log, stderr=server_log
            )
            row["server_pids"].append(child.pid)
            started = time.monotonic()
            while True:
                if child.poll() is not None:
                    raise RuntimeError("Owned server exited before readiness")
                try:
                    info = request("/api/ps", timeout=1)["models"][0]
                    model = info["model"]
                    break
                except (OSError, ValueError):
                    if time.monotonic() - started > 180:
                        raise TimeoutError("Owned server did not become ready")
                    time.sleep(0.25)
            # The image itself does not persist; subsequent requests are text
            # while its tower remains loaded. Preserve its raw response separately.
            image_body = {
                "model": model,
                "prompt": "Describe the color in one word.",
                "images": [base64.b64encode(fixture).decode()],
                "stream": False,
                "options": {"temperature": 0, "seed": 1, "num_predict": 16},
            }
            (cell / f"{name}-image-request.json").write_text(json.dumps(image_body) + "\n")
            image = request("/api/generate", image_body)
            (cell / f"{name}-image-response.json").write_text(json.dumps(image) + "\n")
            if (
                not image.get("done")
                or image["slotstream_benchmark"]["stats"].get("encodedImages") != 1
            ):
                raise ValueError("Vision tower was not exercised")
            plan = request("/api/ps", timeout=10)["models"][0]["details"]["memory_plan"]
            (cell / f"{name}-plan-loaded.json").write_text(json.dumps(plan, indent=2) + "\n")
            persisted = request("/api/show", {"model": model})["details"]["prefix_cache"]
            if bool(persisted.get("persistent")) != point["disk_prefix_cache"]:
                raise ValueError("Disk-prefix attachment differs from the requested mode")

        print("START", point["name"], flush=True)
        try:
            row["before"] = quiet_preflight(protocol["preflight_needed_gb"])
            start("initial")
            row.update(
                pool_slots=plan["pool_slots"],
                prefill_chunk=plan["prefill_chunk"],
                native_ledger=plan["memory_ledger"],
            )
            if point["kind"] == "policy_restart":
                text, ids = exact_text(tokenizer, 128000, source_text)
                body = {
                    "model": model,
                    "prompt": text,
                    "raw": True,
                    "stream": False,
                    "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                }
                _, _, stats = run("main", "/api/generate", body, ids, reply_limit)
                row["phases"][-1].update(
                    history_accounting(ids, stats["reusedPrefixTokens"], repeat=True)
                )
                if not (stats.get("persistentPrefix") or {}).get("restoredTokens", 0):
                    raise ValueError("Independent restart check did not restore the qualified seed")
            elif point["kind"] == "policy_check":
                text, _ = exact_text(tokenizer, 4096, source_text)
                messages = [
                    {
                        "role": "system",
                        "content": "Keep listing numbered short codes without analysis.",
                    },
                    {"role": "user", "content": text},
                ]
                previous = None
                for index in range(3):
                    body = {
                        "model": model,
                        "messages": messages,
                        "stream": False,
                        "think": False,
                        "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                    }
                    data, details, stats = run(
                        "main" if index == 0 else f"chat-turn-{index + 1}", "/api/chat", body
                    )
                    if previous:
                        row["phases"][-1].update(
                            continuation_accounting(
                                previous, details["prompt_ids"], stats["reusedPrefixTokens"]
                            )
                        )
                    previous = details
                    messages += [
                        data["message"],
                        {"role": "user", "content": f"Continue codes for turn{index + 2}."},
                    ]
                first_boundary = None
                for count in (128000, 128256, 129025):
                    text, ids = exact_text(tokenizer, count, source_text)
                    body = {
                        "model": model,
                        "prompt": text,
                        "raw": True,
                        "stream": False,
                        "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                    }
                    _, initial, stats = run(
                        f"seeded-{count}", "/api/generate", body, ids, reply_limit
                    )
                    row["phases"][-1].update(
                        history_accounting(ids, stats["reusedPrefixTokens"], repeat=True)
                    )
                    if not stats["reusedPrefixTokens"]:
                        raise ValueError(
                            "Seeded long request did not reuse an existing experimental prefix"
                        )
                    _, repeated, stats = run(
                        f"repeat-{count}", "/api/generate", body, ids, reply_limit
                    )
                    row["phases"][-1].update(
                        history_accounting(ids, stats["reusedPrefixTokens"], repeat=True)
                    )
                    if repeated["output_ids"] != initial["output_ids"]:
                        raise ValueError("Repeated seeded output differs")
                    if count == 128000:
                        first_boundary = initial["output_ids"]
                stop()
                time.sleep(10)
                start("restart")
                text, ids = exact_text(tokenizer, 128000, source_text)
                body = {
                    "model": model,
                    "prompt": text,
                    "raw": True,
                    "stream": False,
                    "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                }
                _, restored, stats = run("restart-128000", "/api/generate", body, ids, reply_limit)
                row["phases"][-1].update(
                    history_accounting(ids, stats["reusedPrefixTokens"], repeat=True)
                )
                if not (stats.get("persistentPrefix") or {}).get("restoredTokens", 0):
                    raise ValueError("Independent policy restart did not restore disk state")
                if restored["output_ids"] != first_boundary:
                    raise ValueError("Restarted128000 output differs")
            elif point["kind"] == "boundary_sequence":
                previous_ids = []
                for index, count in enumerate(point["prompt_lengths"]):
                    text, ids = exact_text(tokenizer, count, source_text)
                    if ids[: len(previous_ids)] != previous_ids:
                        raise ValueError("Boundary fixture did not extend the previous input")
                    body = {
                        "model": model,
                        "prompt": text,
                        "raw": True,
                        "stream": False,
                        "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                    }
                    _, first, stats = run(
                        "main" if index == 0 else f"append-{count}",
                        "/api/generate",
                        body,
                        ids,
                        reply_limit,
                    )
                    history = len(previous_ids)
                    row["phases"][-1].update(
                        historical_tokens=history,
                        new_input_tokens=count - history,
                        historical_reprefill_tokens=max(0, history - stats["reusedPrefixTokens"]),
                        new_input_prefill_tokens=count - max(history, stats["reusedPrefixTokens"]),
                    )
                    _, repeated, stats = run(
                        f"reuse-{count}", "/api/generate", body, ids, reply_limit
                    )
                    row["phases"][-1].update(
                        history_accounting(ids, stats["reusedPrefixTokens"], repeat=True)
                    )
                    if repeated["output_ids"] != first["output_ids"]:
                        raise ValueError("Repeated boundary output differs")
                    previous_ids = ids
                stop()
                time.sleep(10)
                start("restart")
                body["model"] = model
                _, restored, stats = run("restart", "/api/generate", body, ids, reply_limit)
                row["phases"][-1].update(
                    history_accounting(ids, stats["reusedPrefixTokens"], repeat=True)
                )
                if not (stats.get("persistentPrefix") or {}).get("restoredTokens", 0):
                    raise ValueError("Fresh process did not restore a disk state")
                if restored["output_ids"] != first["output_ids"]:
                    raise ValueError("Restarted boundary output differs")
            elif point["kind"] == "usage_sequence":
                sampler = GuardSampler(cell / "guard-samples.jsonl", vm_snapshot)
                main_ids = tokenizer.encode(source_text, add_special_tokens=False).ids
                used = USAGE_MAIN_BODY + USAGE_APPEND * USAGE_APPEND_TURNS + USAGE_LONG_BODY
                if len(main_ids) < used:
                    raise ValueError(f"Text file has {len(main_ids)} tokens; usage needs {used}")
                records_ids = tokenizer.encode(
                    exact_text(tokenizer, sum(USAGE_SIDE_BODIES) + 1024)[0],
                    add_special_tokens=False,
                ).ids

                def chunk(ids, start, count):
                    return tokenizer.decode(ids[start : start + count], skip_special_tokens=False)

                def chat(name, messages, limit=USAGE_TURN_REPLY, previous=None):
                    body = {
                        "model": model,
                        "messages": messages,
                        "stream": False,
                        "think": False,
                        "options": {"temperature": 0, "seed": 1, "num_predict": limit},
                    }
                    data, details, stats = run(name, "/api/chat", body, limit=limit)
                    if stats["promptTokens"] > MAX_INPUT_TOKENS:
                        raise ValueError(
                            f"{name} input exceeds the {MAX_INPUT_TOKENS} resume ceiling"
                        )
                    if previous is not None:
                        row["phases"][-1].update(
                            continuation_accounting(
                                previous, details["prompt_ids"], stats["reusedPrefixTokens"]
                            )
                        )
                        rework = row["phases"][-1]["historical_reprefill_tokens"]
                        if rework > protocol["history_reprefill_limit_tokens"]:
                            raise ValueError(f"{name} re-prefilled {rework} history tokens")
                    (cell / "manifest.json").write_text(json.dumps(row, indent=2) + "\n")
                    return data, details, body

                main_messages = [
                    {
                        "role": "system",
                        "content": "Output a long list of numbered short codes without analysis.",
                    },
                    {"role": "user", "content": chunk(main_ids, 0, USAGE_MAIN_BODY)},
                ]
                data, main_previous, _ = chat("main", main_messages)
                sides = {}
                for turn in range(USAGE_APPEND_TURNS):
                    start_token = USAGE_MAIN_BODY + turn * USAGE_APPEND
                    main_messages += [
                        data["message"],
                        {"role": "user", "content": chunk(main_ids, start_token, USAGE_APPEND)},
                    ]
                    data, main_previous, _ = chat(
                        f"turn-{turn + 2}", main_messages, previous=main_previous
                    )
                    if turn < len(USAGE_SIDE_BODIES):
                        offset = sum(USAGE_SIDE_BODIES[:turn])
                        side = [
                            {"role": "system", "content": "Respond with a short code."},
                            {
                                "role": "user",
                                "content": chunk(records_ids, offset, USAGE_SIDE_BODIES[turn]),
                            },
                        ]
                        side_data, side_details, _ = chat(f"side-{turn + 1}", side)
                        sides[turn] = (side, side_data, side_details)
                    elif turn == len(USAGE_SIDE_BODIES):
                        chat(
                            "title",
                            [
                                {
                                    "role": "system",
                                    "content": "Write a five-word title for this conversation.",
                                },
                                {"role": "user", "content": chunk(main_ids, 0, 300)},
                            ],
                            limit=16,
                        )
                    else:
                        side, side_data, side_details = sides.pop(0, (None, None, None))
                        if side is not None:
                            chat(
                                "side-1-follow-up",
                                side
                                + [
                                    side_data["message"],
                                    {"role": "user", "content": "Another short code."},
                                ],
                                previous=side_details,
                            )
                main_messages += [
                    data["message"],
                    {
                        "role": "user",
                        "content": chunk(
                            main_ids,
                            USAGE_MAIN_BODY + USAGE_APPEND * USAGE_APPEND_TURNS,
                            USAGE_LONG_BODY,
                        )
                        + "\n\nContinue the numbered list of short codes for as long as you can.",
                    },
                ]
                _, long_details, long_body = chat(
                    "long-reply", main_messages, limit=USAGE_LONG_REPLY, previous=main_previous
                )
                row["long_reply_decoded_tokens"] = len(long_details["output_ids"])
                stop()
                time.sleep(10)
                start("restart")
                long_body["model"] = model
                _, restored, stats = run(
                    "restart-long-reply", "/api/chat", long_body, limit=USAGE_LONG_REPLY
                )
                row["phases"][-1].update(
                    history_accounting(
                        restored["prompt_ids"], stats["reusedPrefixTokens"], repeat=True
                    )
                )
                if not (stats.get("persistentPrefix") or {}).get("restoredTokens", 0):
                    raise ValueError(
                        "Fresh process did not restore the long conversation from disk"
                    )
                # Greedy decoding over 8192 tokens may drift after a restore that re-chunks the
                # tail, so agreement is recorded rather than required; the first 32 must agree.
                common = 0
                for left, right in zip(restored["output_ids"], long_details["output_ids"]):
                    if left != right:
                        break
                    common += 1
                row["restart_long_reply_common_tokens"] = common
                if common < USAGE_TURN_REPLY:
                    raise ValueError(f"Restarted long reply diverges at token {common}")
            elif point["kind"] == "chat":
                text, chat_ids = exact_text(tokenizer, point["history_tokens"], source_text)
                (cell / "user-body-ids.json").write_text(json.dumps(chat_ids) + "\n")
                system = (
                    "Output a long list of numbered short codes without analysis."
                    if args.long_chat_comparison
                    else "Respond with a short code."
                )
                messages = [
                    {"role": "system", "content": system},
                    {"role": "user", "content": text},
                ]
                for index in range(point.get("chat_turns", 4)):
                    if index == 3:
                        stop()
                        time.sleep(10)
                        start("restart")
                    body = {
                        "model": model,
                        "messages": messages,
                        "stream": False,
                        "think": False,
                        "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                    }
                    data, _, stats = run(
                        "main" if index == 0 else f"turn-{index + 1}", "/api/chat", body
                    )
                    if (
                        point["disk_prefix_cache"]
                        and index > 0
                        and (stats.get("persistentPrefix") or {}).get("restoredTokens", 0) <= 0
                    ):
                        raise ValueError("Disk mode did not restore the long conversation")
                    if not point["disk_prefix_cache"] and stats["reusedPrefixTokens"] != 0:
                        raise ValueError("RAM-only long-chat control unexpectedly reused state")
                    messages += [
                        data["message"],
                        {
                            "role": "user",
                            "content": f"Continue with a short code for turn {index + 2}.",
                        },
                    ]
            else:
                if baseline:
                    text = baseline[2]["prompt"]
                    ids = tokenizer.encode(text, add_special_tokens=False).ids
                    if ids != baseline[1]["slotstream_benchmark"]["prompt_ids"]:
                        raise ValueError("Baseline input does not match the independent tokenizer")
                    if plan["memory_ledger"] != baseline[0]["native_ledger"]:
                        raise ValueError(
                            "Speed study native allocation differs from the historical control"
                        )
                else:
                    text, ids = exact_text(
                        tokenizer,
                        point.get("prompt_tokens", point["context"] - reply_limit),
                        source_text,
                        point.get("fixture_offset_tokens", 0),
                    )
                (cell / "fixture-ids.json").write_text(json.dumps(ids) + "\n")
                body = {
                    "model": model,
                    "prompt": text,
                    "raw": True,
                    "stream": False,
                    "options": {"temperature": 0, "seed": 1, "num_predict": reply_limit},
                }
                _, cold, cold_stats = run("main", "/api/generate", body, ids, reply_limit)
                if speed_study and cold_stats["reusedPrefixTokens"]:
                    raise ValueError("First speed-comparison request unexpectedly reused state")
                if baseline and (
                    cold_stats["reusedPrefixTokens"]
                    or cold["output_ids"] != baseline[1]["slotstream_benchmark"]["output_ids"]
                ):
                    raise ValueError(
                        "First request reused state or output differs from the historical control"
                    )
                for name in point.get("phase_names", ["main", "reuse", "restart"])[1:]:
                    if name == "restart":
                        stop()
                        time.sleep(10)
                        start("restart")
                        body["model"] = model
                    _, restored, stats = run(name, "/api/generate", body, ids, reply_limit)
                    if (
                        point["disk_prefix_cache"]
                        and (stats.get("persistentPrefix") or {}).get("restoredTokens", 0) <= 0
                    ):
                        raise ValueError("Full-window request did not restore from disk")
                    if not point["disk_prefix_cache"] and stats["reusedPrefixTokens"]:
                        raise ValueError(
                            "Disk-off full-window request unexpectedly reused in-memory state"
                        )
                    if restored["output_ids"] != cold["output_ids"]:
                        raise ValueError("Restored output differs from cold output")
            row.update(
                completed=True,
                process_budget_passed=True,
                raw_sha256=digest(cell / "main-response.json"),
                observed_peak_bytes=row["phases"][0]["observed_peak_bytes"],
                lifecycle_peak_bytes=max(p["observed_peak_bytes"] for p in row["phases"]),
                cache_inventory=[
                    {
                        "file": str(p.relative_to(state_dir)),
                        "bytes": p.stat().st_size,
                        "sha256": streaming_digest(p),
                    }
                    for p in sorted(state_dir.rglob("*"))
                    if p.is_file()
                ],
            )
        except Exception as error:
            row["error"] = f"{type(error).__name__}: {error}"
        finally:
            stop()
            if sampler is not None:
                sampler.close()
                sampler = None
            row["after"] = vm_snapshot()
            row["ended_unix"] = time.time()
            row["swap_delta"] = {
                k: row["after"][k] - row.get("before", row["after"])[k]
                for k in ("swapins", "swapouts")
            }
            row["eligible"] = (
                row["completed"] and row["swap_delta"]["swapouts"] < ACCEPTABLE_SWAPOUT_PAGES
            )
            (cell / "manifest.json").write_text(json.dumps(row, indent=2) + "\n")
            (args.output / "runs.json").write_text(json.dumps(rows, indent=2) + "\n")
            print(
                "RESULT",
                point["name"],
                row.get("observed_peak_bytes"),
                row["eligible"],
                row.get("error"),
                flush=True,
            )
        if not row["eligible"] and protocol["version"] == 8 and protocol["revision"] == 1:
            return 1
        time.sleep(10)
    return 0 if all(row["eligible"] for row in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
