#!/bin/bash
# PR #143: BF16 attention price above 128256 keys on 4423adb5 with SLOTSTREAM_WIRED_LIMIT=1.
# The harness caps prompts at 128000 tokens, so this restores the 128000-token prefix that
# run/full-138240-4423adb saved (copied, never the original) and extends it to 129025, 132096
# and 136000 tokens. Server flags are the harness's production flags.
set -uo pipefail
E=/Volumes/llm/hive-frame-pr143-4423adb-20261117
F=$E/run/above-128k-4423adb
BIN=/Users/USER/.local/share/hive_frame/runtimes/slotstream-4423adb/slotstream
PY=/Volumes/llm/hive-frame-capacity-20261011/tokenizer-venv/bin/python
launchctl bootout user/501/local.hive-frame.mac-flash-next
while ps -axww -o command | grep -q '[s]lotstream serve'; do sleep 5; done
echo "production stopped $(date)"
bash /Volumes/llm/slotstream-read-lanes/clean_mac.sh > $F/clean.log 2>&1
sleep 60
cp -R $E/run/full-138240-4423adb/study-cache/full-ctx138240 $F/prefix-cache
CMD="$BIN serve --model /Volumes/llm/models/qwen38-flash-next-mlx-4bit --memory-gb 27 --max-context 138240 --mtp on --prefix-cache-dir $F/prefix-cache --prefix-cache-disk-gb 20 --prefix-cache-min-tokens 1024 --port 11439 --vision on --mirror /Users/USER/.slotstream/models/qwen38-flash-next-mlx-4bit --mirror /Volumes/llm-250/models/qwen38-flash-next-mlx-4bit --max-prefill-wait 90"
echo "SLOTSTREAM_PREFILL_CHUNK=256 SLOTSTREAM_WIRED_LIMIT=1 SLOTSTREAM_BENCH_DETAILS=1 $CMD" > $F/command.txt
echo "$PY $F/requests.py $F" >> $F/command.txt
{ date; vm_stat; sysctl vm.swapusage; } > $F/vm-before.txt
SLOTSTREAM_PREFILL_CHUNK=256 SLOTSTREAM_WIRED_LIMIT=1 SLOTSTREAM_BENCH_DETAILS=1 $CMD > $F/server.log 2>&1 < /dev/null &
SP=$!
until curl -s -m 5 http://127.0.0.1:11439/api/ps > /dev/null; do sleep 5; ps -p $SP > /dev/null || { echo "server exited"; break; }; done
( while ps -p $SP > /dev/null; do T=$(date +%H%M%S); { date; vm_stat; sysctl vm.swapusage; } > $F/samples/$T-vmstat.txt; footprint $SP > $F/samples/$T-footprint.txt 2>&1; sleep 30; done ) < /dev/null > /dev/null 2>&1 &
$PY $F/requests.py $F > $F/results.jsonl 2> $F/requests.err
echo "REQUESTS_EXIT=$?"
{ date; vm_stat; sysctl vm.swapusage; } > $F/vm-after.txt
kill $SP; wait $SP
echo "ALL_DONE $(date)"
