"""Measure exact-token requests through the unchanged production server."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import plistlib
import socket
import struct
import subprocess
import sys
import time
import urllib.request
import zlib


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def image_fixture(size):
    """A deterministic RGB PNG; no private photograph enters the archive."""
    def chunk(kind, payload):
        return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload))
    pixels = b"".join(b"\0" + bytes((200, 40, 30)) * size for _ in range(size))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b""))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source", "binary", "model", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--contexts", type=int, nargs="*")
    parser.add_argument("--matrix", action="store_true", help="Measure all MTP/vision/mirror combinations")
    parser.add_argument("--mirror", type=Path)
    parser.add_argument("--modes", nargs="+", choices=[f"m{m}v{v}r{r}" for m in (0, 1) for v in (0, 1) for r in (0, 1)],
                        help="Restrict --matrix to these measured configurations")
    parser.add_argument("--training-contexts", type=int, nargs="+", help="Declare fitting contexts before measurement")
    parser.add_argument("--validation-only", action="store_true", help="Declare every point independent of fitting")
    parser.add_argument("--image-size", type=int, choices=(224, 448), help="Fix the synthetic image size")
    parser.add_argument("--replacement-for", help="Retained study/point excluded by swapin; one independent replacement")
    parser.add_argument("--replacement-purpose", choices=("training_anchor", "independent_validation"),
                        help="Declare the unchanged role of a single replacement before measurement")
    parser.add_argument("--request-timeout", type=int, default=3600, help="Per request time limit in seconds")
    args = parser.parse_args()
    if (args.modes or args.training_contexts or args.validation_only or args.image_size or args.replacement_for or args.replacement_purpose) and not args.matrix:
        parser.error("Mode-study controls require --matrix")
    if args.validation_only and args.training_contexts:
        parser.error("--validation-only cannot declare training contexts")
    if args.replacement_purpose and not args.replacement_for:
        parser.error("--replacement-purpose requires --replacement-for")
    if args.request_timeout < 1:
        parser.error("--request-timeout must be positive")
    sys.path.insert(0, str(args.source / "Tools"))
    from context_qualification import observed_model, quiet_preflight, verification_lock
    from prefill_bench import vm_snapshot
    from tokenizers import Tokenizer
    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    protocol = {
        "version": 5, "revision": 5, "commit": "0237e14885cde50ec6e3b6fefde5884e9e6c0493",
        "binary_sha256": "61e08e428ca969a17722874f62b395a64b257dda5d718a0ff745b3e5eadc0065",
        "model": str(args.model), "budget_gb": 22, "reply_tokens": 32,
        "mtp": "off", "vision": "off", "gpu_keepalive": "off", "prefix_cache": True,
        "tokenizer_version": "0.22.2", "api": "/api/generate raw=true",
        "preflight_needed_gb": 23.75,
        "preflight_basis": "22 GB process budget + 1.75 GB, rounded above max(1.5 GB, 5% of 32 GiB RAM); native engine admission remains enabled",
        "settle_seconds_after_owned_server_exit": 10,
        "points": [
            {"name": "1k", "context": 1024, "warm_tokens": 0, "warm_conversations": 0},
            {"name": "8k", "context": 8192, "warm_tokens": 0, "warm_conversations": 0},
            {"name": "32k", "context": 32768, "warm_tokens": 2048, "warm_conversations": 4},
            {"name": "64k", "context": 65536, "warm_tokens": 2048, "warm_conversations": 4},
            {"name": "8k-holdout", "context": 8192, "warm_tokens": 0, "warm_conversations": 0},
            {"name": "32k-retained", "context": 32768, "warm_tokens": 8192, "warm_conversations": 4},
        ],
        "warm_output_policy": "Up to 16 tokens; an earlier normal EOS is valid only for warm requests. The main request must deliver exactly 32 tokens.",
        "sampling": "Native 20 ms physical footprint, kernel lifetime peak, RSS and post-request /api/ps; never add MLX and footprint",
        "policy": "New owned server per point; no retries. Abort on incomplete work, budget excess or swapout increase. Archive all outcomes.",
        "scope": "Synthetic exact-token raw requests, production optimization controls, explicit keepalive off. Warm requests are recorded without assuming all four conversations remain resumable.",
    }
    if args.contexts:
        if any(not 1024 <= n <= 262144 for n in args.contexts) or (not args.matrix and len(set(args.contexts)) != len(args.contexts)):
            raise ValueError("Contexts must be integers between 1024 and 262144 (unique outside a mode study)")
        protocol["points"] = [{"name": f"ctx{n}-validation", "context": n, "warm_tokens": 0,
                               "warm_conversations": 0} for n in args.contexts]
    if args.matrix:
        if args.mirror is None:
            parser.error("--matrix requires a verified --mirror model copy")
        contexts = args.contexts or [1024, 8192, 16384, 32768, 12288, 8192]
        if args.training_contexts and not set(args.training_contexts).issubset(contexts):
            parser.error("Every --training-contexts value must occur in --contexts")
        points = []
        # Pair one-disk/two-disk arms, reversing their order at alternating ctx.
        for index, context in enumerate(contexts):
            for mtp, vision in ((True, True), (True, False), (False, True), (False, False)):
                for mirrored in ((False, True) if index % 2 == 0 else (True, False)):
                    key = f"m{int(mtp)}v{int(vision)}r{int(mirrored)}"
                    if args.modes and key not in args.modes:
                        continue
                    # A repeated fitting context is an independent repeat, never a second fit.
                    training = (context in args.training_contexts and context not in contexts[:index]
                                if args.training_contexts else index < 4)
                    training = training and not args.validation_only
                    points.append({"name": f"c{context}-m{int(mtp)}v{int(vision)}r{int(mirrored)}-p{index}",
                                   "context": context, "warm_tokens": 0, "warm_conversations": 0,
                                   "mtp": mtp, "vision": vision, "mirror": mirrored,
                                   "image_size": (args.image_size or (448 if index == 5 else 224)) if vision else None,
                                   "purpose": "training_anchor" if training else "independent_validation"})
        replacement_role = args.replacement_purpose or ("independent_validation" if args.validation_only else None)
        if args.replacement_for and (len(points) != 1 or replacement_role != points[0]["purpose"]):
            parser.error("--replacement-for requires exactly one point with the declared replacement purpose")
        protocol.update(version=6, revision=5, validation_only=args.validation_only,
                        replacement_for=args.replacement_for,
                        replacement_purpose=replacement_role if args.replacement_for else None,
                        request_timeout_seconds=args.request_timeout, selected_modes=args.modes, mtp="per_point", vision="per_point",
                        mirror_model=str(args.mirror), points=points,
                        scope="Full-window exact-token text with MTP on/off, vision tower resident after an actual synthetic image request, and single/mirror paired reads. Image fixtures are 224 square for anchors and 448 square for repeat validation; not full-window image-chat or arbitrary-image qualification.")
    if digest(args.binary) != protocol["binary_sha256"]:
        raise ValueError("Installed executable changed")
    if subprocess.check_output(["git", "-C", str(args.source), "rev-parse", "HEAD"], text=True).strip() != protocol["commit"]:
        raise ValueError("Source commit changed")
    protocol["metallib_sha256"] = digest(args.binary.parent / "mlx.metallib")
    protocol["harness_sha256"] = digest(Path(__file__))
    protocol["model_identity"] = observed_model(args.model)
    (out / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    (out / "harness.py").write_bytes(Path(__file__).read_bytes())
    env = {k: v for k, v in os.environ.items() if not k.startswith("SLOTSTREAM_")}
    env.update(SLOTSTREAM_GPU_KEEPALIVE="off", SLOTSTREAM_BENCH_DETAILS="1")
    quiet_preflight(protocol["preflight_needed_gb"])
    with verification_lock(), (out / "model-verification.txt").open("w") as log:
        subprocess.run([str(args.binary), "pull", "--verify", "--dir", str(args.model)],
                       env=env, stdout=log, stderr=log, check=True, timeout=600)
    if args.matrix:
        protocol["mirror_identity"] = observed_model(args.mirror)
        def comparable(identity):
            return {k: {f: v for f, v in item.items() if f != "mtime_ns"} for k, item in identity.items()}
        if comparable(protocol["mirror_identity"]) != comparable(protocol["model_identity"]):
            raise ValueError("Primary and mirror checkpoint identities differ")
        with verification_lock(), (out / "mirror-verification.txt").open("w") as log:
            subprocess.run([str(args.binary), "pull", "--verify", "--dir", str(args.mirror)],
                           env=env, stdout=log, stderr=log, check=True, timeout=600)
        disks = {}
        containers = plistlib.loads(subprocess.check_output(["diskutil", "apfs", "list", "-plist"]))["Containers"]
        for label, path in (("primary", args.model), ("mirror", args.mirror)):
            device = subprocess.check_output(["df", "-P", str(path)], text=True).splitlines()[-1].split()[0]
            info = plistlib.loads(subprocess.check_output(["diskutil", "info", "-plist", device]))
            container = next(c for c in containers if c["ContainerReference"] == info["ParentWholeDisk"])
            stores = [plistlib.loads(subprocess.check_output(["diskutil", "info", "-plist", s["DeviceIdentifier"]]))
                      for s in container["PhysicalStores"]]
            disks[label] = {"volume": info, "physical_stores": stores}
        protocol["disk_receipts"] = disks
        def physical(label):
            return {s["ParentWholeDisk"] for s in disks[label]["physical_stores"]}
        if not physical("primary").isdisjoint(physical("mirror")):
            raise ValueError("Mirror must reside on a distinct disk")
        for size in (224, 448):
            fixture = out / f"image-{size}.png"
            fixture.write_bytes(image_fixture(size))
        (out / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    tokenizer = Tokenizer.from_file(str(args.model / "tokenizer.json"))
    def prompt(tokens, conversation=0):
        text = "Context check. " if conversation == 0 else f"Context check conversation {conversation}. "
        text += "".join(f"Record {i}: the sensor on line {i % 97} reported {37 + i * 31 % 500} units at {i % 24}:{i * 7 % 60:02d}, and technician {i * 13 % 1000} filed note {i}. " for i in range(tokens // 12 + 100))
        ids = tokenizer.encode(text, add_special_tokens=False).ids[:tokens]
        decoded = tokenizer.decode(ids, skip_special_tokens=False)
        if tokenizer.encode(decoded, add_special_tokens=False).ids != ids or len(ids) != tokens:
            raise ValueError("Synthetic text did not round-trip to the frozen token sequence")
        return decoded, ids
    rows = []
    for point in protocol["points"]:
        cell = out / point["name"]
        cell.mkdir()
        row = dict(point, started_unix=time.time(), completed=False)
        rows.append(row)
        child = None
        try:
            if digest(args.binary) != protocol["binary_sha256"] or observed_model(args.model) != protocol["model_identity"]:
                raise ValueError("Binary or model identity changed")
            if args.matrix and observed_model(args.mirror) != protocol["mirror_identity"]:
                raise ValueError("Mirror checkpoint identity changed")
            row["before"] = quiet_preflight(protocol["preflight_needed_gb"])
            mtp, vision, mirrored = point.get("mtp", False), point.get("vision", False), point.get("mirror", False)
            row.update(mtp=mtp, vision=vision, mirror=mirrored)
            doctor = [str(args.binary), "doctor", "--model", str(args.model), "--memory-gb", "22",
                      "--max-context", str(point["context"]), "--mtp", "on" if mtp else "off",
                      "--vision", "on" if vision else "off", "--json"]
            with (cell / "doctor-before.json").open("w") as receipt:
                subprocess.run(doctor, cwd=args.source, env=env, stdout=receipt, check=True, timeout=30)
            with socket.socket() as sock:
                sock.bind(("127.0.0.1", 0))
                port = sock.getsockname()[1]
            url = f"http://127.0.0.1:{port}"
            def request(path, body=None, timeout=args.request_timeout):
                data = json.dumps(body).encode() if body is not None else None
                req = urllib.request.Request(url + path, data=data, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    return json.load(response)
            command = [str(args.binary), "serve", "--model", str(args.model), "--memory-gb", "22",
                       "--max-context", str(point["context"]), "--mtp", "on" if mtp else "off",
                       "--vision", "on" if vision else "off",
                       "--gpu-keepalive", "off", "--max-prefill-wait", "0", "--port", str(port)]
            if mirrored:
                command.extend(["--mirror", str(args.mirror)])
            row["command"] = command
            print("START", point["name"], flush=True)
            with (cell / "server.log").open("w") as log:
                child = subprocess.Popen(command, cwd=args.source, env=env, stdout=log, stderr=log)
                start = time.monotonic()
                while True:
                    if child.poll() is not None:
                        raise RuntimeError("Owned server exited before readiness")
                    try:
                        models = request("/api/ps", timeout=1)["models"]
                        break
                    except (OSError, ValueError):
                        if time.monotonic() - start > 180:
                            raise TimeoutError("Owned server did not become ready")
                        time.sleep(0.25)
                model = models[0]["model"]
                plan = models[0]["details"]["memory_plan"]
                (cell / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
                observed = []
                def generate(name, tokens, conversation, output_tokens, allow_natural_stop=False, image=None):
                    text, ids = prompt(tokens, conversation) if image is None else ("Describe the color in one word.", None)
                    body = {"model": model, "prompt": text, "raw": True, "stream": False,
                            "options": {"temperature": 0, "seed": 1, "num_predict": output_tokens}}
                    if image is not None:
                        body.update(raw=False, images=[base64.b64encode(image).decode()])
                    (cell / (name + "-request.json")).write_text(json.dumps(body) + "\n")
                    data = request("/api/generate", body)
                    (cell / (name + "-response.json")).write_text(json.dumps(data) + "\n")
                    details = data["slotstream_benchmark"]
                    stats = details["stats"]
                    if ids is not None and (details["prompt_ids"] != ids or stats["promptTokens"] != tokens):
                        raise ValueError("Swift tokenizer differs from independent exact-token input")
                    if any(stats.get(k) for k in ("runtimeError", "requestFailure", "memoryPressureCancelled")):
                        raise ValueError("Request failed")
                    if details["effective_mtp"] != mtp:
                        raise ValueError("Requested MTP state was not exercised")
                    if mtp and image is None and stats.get("draftedTokens", 0) <= 0:
                        raise ValueError("MTP did not execute draft work")
                    if mirrored and (len(stats.get("mirrorBytes", [])) != 2 or not all(stats["mirrorBytes"])):
                        raise ValueError("Both physical checkpoint copies must serve expert reads")
                    if image is not None and stats.get("encodedImages") != 1:
                        raise ValueError("Image did not execute the vision tower")
                    actual_output = stats["decodeTokens"]
                    if len(details["output_ids"]) != actual_output or not 0 < actual_output <= output_tokens:
                        raise ValueError("Invalid generated token accounting")
                    if actual_output != output_tokens and not (allow_natural_stop and stats.get("finishReason") == "stop"):
                        raise ValueError("Request did not deliver all required output tokens")
                    post = request("/api/ps", timeout=10)["models"][0]["size"]
                    peak = max(stats["sampledFootprint"]["peakBytes"], stats["lifetimeRSSPeakBytes"],
                               stats["physicalFootprintEndBytes"], stats["lifetimePhysicalFootprintPeakBytes"], post)
                    observed.append(peak)
                    if peak > 22_000_000_000:
                        raise ValueError("Measured whole-process footprint exceeded 22 GB")
                    return data, details
                if vision:
                    fixture = out / f"image-{point['image_size']}.png"
                    row["image_sha256"] = digest(fixture)
                    image_data, image_details = generate("image", 0, 0, 16, True, fixture.read_bytes())
                    row["image_request"] = {"prompt_tokens": image_details["stats"]["promptTokens"],
                                            "reply_tokens": image_details["stats"]["decodeTokens"],
                                            "pool_slots": image_details["effective_pool_slots"],
                                            "raw_sha256": digest(cell / "image-response.json")}
                    # Loading the tower can resize the pool: record the actual post-load plan.
                    plan = request("/api/ps", timeout=10)["models"][0]["details"]["memory_plan"]
                    (cell / "plan-loaded.json").write_text(json.dumps(plan, indent=2) + "\n")
                for i in range(point["warm_conversations"]):
                    generate(f"warm-{i + 1}", point["warm_tokens"], i + 1, 16, allow_natural_stop=True)
                show = request("/api/show", {"model": model})
                row["retained_before"] = show["details"]["prefix_cache"]
                data, details = generate("main", point["context"] - 32, 0, 32)
                stats = details["stats"]
                show = request("/api/show", {"model": model})
                ledger = plan["memory_ledger"]
                row.update(completed=True, observed_peak_bytes=max(observed), pool_slots=details["effective_pool_slots"],
                           prefill_chunk=details["effective_prefill_chunk"], native_ledger=ledger,
                           configured_context=point["context"], prompt_tokens=stats["promptTokens"],
                           reply_tokens=stats["decodeTokens"], process_budget_passed=True,
                           native_fits=max(observed) <= ledger["expected_peak_bytes"],
                           prefill_seconds=stats["prefillSeconds"], decode_seconds=stats["decodeSeconds"],
                           retained_after=show["details"]["prefix_cache"], optimizations=details["optimizations"],
                           raw_sha256=digest(cell / "main-response.json"),
                           measured_components={k: stats.get(k) for k in (
                               "sampledFootprint", "lifetimePhysicalFootprintPeakBytes", "lifetimeRSSPeakBytes",
                               "physicalFootprintEndBytes", "mlxPeakMemoryGB", "prefillPhysicalFootprintBytes")})
        except Exception as error:
            row["error"] = f"{type(error).__name__}: {error}"
        finally:
            if child is not None:
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
                row["owned_server_reaped"] = child.poll() is not None
            row["after"] = vm_snapshot()
            row["ended_unix"] = time.time()
            row["swap_delta"] = {k: row["after"][k] - row.get("before", row["after"])[k] for k in ("swapins", "swapouts")}
            row["eligible"] = row["completed"] and all(v == 0 for v in row["swap_delta"].values())
            (cell / "manifest.json").write_text(json.dumps(row, indent=2) + "\n")
            (out / "runs.json").write_text(json.dumps(rows, indent=2) + "\n")
            print("RESULT", point["name"], row.get("observed_peak_bytes"), row["eligible"], row.get("error"), flush=True)
        if not row["completed"] or row["swap_delta"]["swapouts"]:
            return 1
        time.sleep(protocol["settle_seconds_after_owned_server_exit"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
