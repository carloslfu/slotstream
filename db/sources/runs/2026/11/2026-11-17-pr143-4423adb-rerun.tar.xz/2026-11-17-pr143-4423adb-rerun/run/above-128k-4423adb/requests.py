"""Extend the saved 128000-token prefix past 128256 keys, where prefill passes fall below 256 rows."""
import json, sys, time, urllib.request
from pathlib import Path
from tokenizers import Tokenizer

out = Path(sys.argv[1])
tok = Tokenizer.from_file("/Volumes/llm/models/qwen38-flash-next-mlx-4bit/tokenizer.json")
base_text = Path("/Volumes/llm/hive-frame-wired-test-20261110/long_prompt.txt").read_text()
base_ids = tok.encode(base_text, add_special_tokens=False).ids[:128000]
base = tok.decode(base_ids, skip_special_tokens=False)
records = "".join(f"\n\nRecord {i}: the sensor on line {i % 97} reported {37 + i * 31 % 500} units, note {i}." for i in range(4000))
for count in (129025, 132096, 136000):
    ids = tok.encode(base + records, add_special_tokens=False).ids[:count]
    if ids[:128000] != base_ids:
        raise SystemExit(f"{count}: extension changes the first 128000 tokens")
    text = tok.decode(ids, skip_special_tokens=False)
    if tok.encode(text, add_special_tokens=False).ids != ids:
        raise SystemExit(f"{count}: prompt does not round-trip")
    body = {"model": "qwen3.8-flash-next:4bit", "prompt": text, "raw": True, "stream": False,
            "options": {"temperature": 0, "seed": 1, "num_predict": 32}}
    started = time.time()
    req = urllib.request.Request("http://127.0.0.1:11439/api/generate", json.dumps(body).encode(),
                                 {"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=7200) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        data = {"http_status": e.code, "error": e.read().decode()}
    (out / f"request-{count}.json").write_text(json.dumps(body) + "\n")
    (out / f"response-{count}.json").write_text(json.dumps(data) + "\n")
    s = data.get("slotstream_benchmark", {}).get("stats", {})
    rows = s.get("prefillComputeQueryRows", [])
    keys = s.get("prefillComputeKeyExtents", [])
    print(json.dumps({"count": count, "seconds": round(time.time() - started, 1), "error": data.get("error"),
                      "prompt": data.get("prompt_eval_count"), "reused": s.get("reusedPrefixTokens"),
                      "rows": sorted(set(rows)), "max_key": max(keys, default=None),
                      "peak_gb": s.get("peakMemoryGB"), "sampled_peak": s.get("sampledFootprint", {}).get("peakBytes"),
                      "refusals": {k: s.get(k) for k in ("sharedPrefixRefusals", "alignedResumeRefusals", "prefixCheckpointRefusals")},
                      "swap": [s.get("generatorVMBefore"), s.get("generatorVMAfter")]}), flush=True)
