#!/bin/bash
# Build 4423adb5 (PR #143 head: Carlos's opt-in wired limit + guard holes) the same way 200fb398 was built.
# Production slotstream keeps serving during the build; nothing is being measured yet.
set -euo pipefail
SRC=/Volumes/llm/slotstream-guard-bf16-src
ROOT=/Volumes/llm/hive-frame-slotstream-4423adb
OUT=/Volumes/llm/hive-frame-slotstream-4423adb-evidence
BASE=/Volumes/llm/hive-frame-slotstream-981ce2d
EXPECTED=4423adb532b6c00000d17a67d5635f4b237c4506
export PATH=/Volumes/llm/toolchains/swift-6.3/swift-6.3-RELEASE-osx-package.pkg/Payload/usr/bin:/opt/homebrew/bin:$PATH
export SDKROOT=$(xcrun --show-sdk-path)
[ -d "$ROOT/.git" ] || git clone --quiet "$SRC" "$ROOT"
cd "$ROOT"
git fetch --quiet "$SRC" "$EXPECTED"
git checkout --quiet --detach "$EXPECTED"
test "$(git rev-parse HEAD)" = "$EXPECTED"
mkdir -p .build Tools/lib "$ROOT-tmp"
export TMPDIR="$ROOT-tmp"
[ -d .build/repositories ] || cp -R "$BASE/.build/repositories" .build/repositories
[ -f Tools/lib/mlx-0.32.2.metallib ] || cp "$BASE/Tools/lib/mlx-0.32.2.metallib" Tools/lib/
swift --version
python3 Tools/optimization_build.py --out "$OUT" --jobs 2
echo BUILD_OK
