#!/bin/bash
# carloslfu/slotstream#143 reruns on head 4423adb5 (Carlos: opt-in wired limit, regrowth charge
# with one layer's old buffers, alias-flag holes), with SLOTSTREAM_WIRED_LIMIT=1 in the harness
# catalog env. Same harness, model, mirrors and flags as the 11-13/11-15 rounds otherwise
# (27 GB, ctx from catalog, MTP + vision, SLOTSTREAM_PREFILL_CHUNK=256, prefetch default).
#  1. stop production (the build needs the model-process lock), build + install 4423adb
#  2. doctor: Metal working set as MLX sees it
#  3. swap ABBA at --full-window-contexts 32768: base 981ce2dd (ignores the variable) vs 4423adb5
#  4. guard usage sequence --context 138240 --usage-sequence on 4423adb5
#  5. full window 138240 on 4423adb5: prefill passes above 128K keys (BF16 attention price)
set -uo pipefail
E=/Volumes/llm/hive-frame-pr143-4423adb-20261117
PY=/Volumes/llm/hive-frame-capacity-20261011/tokenizer-venv/bin/python
TEXT=/Volumes/llm/hive-frame-wired-test-20261110/long_prompt.txt
MODEL=/Volumes/llm/models/qwen38-flash-next-mlx-4bit
MIRRORS="/Users/USER/.slotstream/models/qwen38-flash-next-mlx-4bit /Volumes/llm-250/models/qwen38-flash-next-mlx-4bit"
RT=/Users/USER/.local/share/hive_frame/runtimes
HEAD=4423adb532b6c00000d17a67d5635f4b237c4506
receipt() {
  case $1 in
    981ce2d) echo /Volumes/llm/hive-frame-paging-rootcause-20261110/harness/src/hive_frame/data/slotstream-runtime.json ;;
    4423adb) echo $E/receipt-4423adb.json ;;
  esac
}
date > $E/started.txt

launchctl bootout user/501/local.hive-frame.mac-flash-next
while ps -axww -o command | grep -q '[s]lotstream serve'; do sleep 5; done
echo "production stopped $(date)"

cd /Volumes/llm
bash hive-frame-slotstream-4423adb-build.sh > hive-frame-slotstream-4423adb-build-2.log 2>&1 < /dev/null || { echo "BUILD FAILED"; tail -5 hive-frame-slotstream-4423adb-build-2.log; echo ALL_DONE; exit 1; }
echo "built $(date)"
mkdir -p $RT/slotstream-4423adb
for f in build-identity.json build-source.tar.gz mlx.metallib slotstream; do
  cp -p /Volumes/llm/hive-frame-slotstream-4423adb-evidence/candidate/$f $RT/slotstream-4423adb/
done
/usr/bin/python3 - <<PY
import json
i = json.load(open("$RT/slotstream-4423adb/build-identity.json"))
i.update(slotstream_commit="$HEAD", upstream_main="981ce2dd580c1ff92d956d9bfeca3aa2ca446e55",
         pull_requests={"carloslfu/slotstream#143": "$HEAD"},
         executable="$RT/slotstream-4423adb/slotstream")
json.dump(i, open("$E/receipt-4423adb.json", "w"), indent=2)
PY

cp -R /Volumes/llm/hive-frame-pr143-ab-20261113/harness $E/harness
/usr/bin/python3 - <<PY
import json
p = "$E/harness/config/hive.json"
d = json.load(open(p))
d["deployments"]["mac-flash-next"]["command"]["env"]["SLOTSTREAM_WIRED_LIMIT"] = "1"
json.dump(d, open(p, "w"), indent=2)
print(d["deployments"]["mac-flash-next"]["command"]["env"])
PY
SLOTSTREAM_WIRED_LIMIT=1 $RT/slotstream-4423adb/slotstream doctor --model $MODEL --memory-gb 27 > $E/doctor.txt 2>&1
sysctl iogpu.wired_limit_mb >> $E/doctor.txt

run_part() {  # name, arm, extra harness args...
  local name=$1 arm=$2; shift 2
  local F=$E/run/$name
  mkdir -p $F/samples
  bash /Volumes/llm/slotstream-read-lanes/clean_mac.sh > $F/clean.log 2>&1
  sleep 60
  cd $E/harness
  local CMD="$PY tools/measure_slotstream_persistent_prefix.py --source /Volumes/llm/hive-frame-slotstream-$arm --binary $RT/slotstream-$arm/slotstream --runtime-receipt $(receipt $arm) --model $MODEL --mirror $MIRRORS --output $F/study --cache-root $F/study-cache --text-file $TEXT $*"
  echo "$CMD" > $F/command.txt
  ( while ! grep -q '^EXIT=' $F/run.log 2>/dev/null; do
      T=$(date +%H%M%S)
      P=$(ps -axww -o pid,command | awk -v a="slotstream-$arm/slotstream serve" 'index($0, a) {print $1}' | head -1)
      { date; vm_stat; sysctl vm.swapusage; } > $F/samples/$T-vmstat.txt
      if [ -n "$P" ]; then footprint $P > $F/samples/$T-footprint-$P.txt 2>&1; fi
      sleep 60
    done ) > $F/sampler.log 2>&1 < /dev/null &
  $CMD > $F/run.log 2>&1
  echo "EXIT=$?" >> $F/run.log
  wait
  echo "$name $(tail -2 $F/run.log | tr '\n' ' ') $(date)"
}

run_part swap-base-1 981ce2d --full-window-contexts 32768
run_part swap-head-1 4423adb --full-window-contexts 32768
run_part swap-head-2 4423adb --full-window-contexts 32768
run_part swap-base-2 981ce2d --full-window-contexts 32768
run_part usage-4423adb 4423adb --context 138240 --usage-sequence
run_part full-138240-4423adb 4423adb --full-window-contexts 138240
echo "ALL_DONE $(date)"
