#!/bin/bash
# carloslfu/slotstream#143 evidence on clean commit builds, production flags (27 GB, three copies).
#  swap:  --full-window-contexts 32768, base 981ce2dd vs head 200fb398, ABBA (the 11-10 paging repro).
#  usage: --context 138240 --usage-sequence on db0f6c8c (wired limit only), 53f3fa58 (+ two guard
#         fixes) and 200fb398 (all four): shows which phase each guard fix unblocks.
# Starts only after the prefetch A/B wrote ALL_DONE and the oMLX upgrade (brew) is no longer running.
set -uo pipefail
E=/Volumes/llm/hive-frame-pr143-ab-20261113
PY=/Volumes/llm/hive-frame-capacity-20261011/tokenizer-venv/bin/python
H=$E/harness
TEXT=/Volumes/llm/hive-frame-wired-test-20261110/long_prompt.txt
MODEL=/Volumes/llm/models/qwen38-flash-next-mlx-4bit
MIRRORS="/Users/USER/.slotstream/models/qwen38-flash-next-mlx-4bit /Volumes/llm-250/models/qwen38-flash-next-mlx-4bit"
# macOS /bin/bash is 3.2 (no associative arrays); clean_mac.sh kills Homebrew's bash.
receipt() {
  case $1 in
    981ce2d) echo /Volumes/llm/hive-frame-paging-rootcause-20261110 ;;
    db0f6c8) echo /Volumes/llm/hive-frame-db0f6c8-calibration-20261110 ;;
    53f3fa5) echo /Volumes/llm/hive-frame-53f3fa5-calibration-20261112 ;;
    200fb39) echo /Volumes/llm/hive-frame-200fb39-calibration-20261112 ;;
  esac | sed 's|$|/harness/src/hive_frame/data/slotstream-runtime.json|'
}

until grep -q ALL_DONE /Volumes/llm/hive-frame-prefetch-ab-20261113/driver.log 2>/dev/null; do sleep 60; done
sleep 120
while ps -axo command | grep -E -q 'brew\.rb|bin\/brew '; do sleep 30; done
date > $E/started.txt

run_part() {  # name, arm, extra harness args...
  local name=$1 arm=$2; shift 2
  local F=$E/run/$name
  mkdir -p $F/samples
  bash /Volumes/llm/slotstream-read-lanes/clean_mac.sh > $F/clean.log 2>&1
  sleep 60
  cd $H
  local CMD="$PY tools/measure_slotstream_persistent_prefix.py --source /Volumes/llm/hive-frame-slotstream-$arm --binary /Users/USER/.local/share/hive_frame/runtimes/slotstream-$arm/slotstream --runtime-receipt $(receipt $arm) --model $MODEL --mirror $MIRRORS --output $F/study --cache-root $F/study-cache --text-file $TEXT $*"
  echo "$CMD" > $F/command.txt
  ( while ! grep -q '^EXIT=' $F/run.log 2>/dev/null; do
      T=$(date +%H%M%S)
      P=$(ps -axo pid,command | awk -v a="slotstream-$arm/slotstream serve" 'index($0, a) {print $1}' | head -1)
      { date; vm_stat; sysctl vm.swapusage; } > $F/samples/$T-vmstat.txt
      if [ -n "$P" ]; then footprint $P > $F/samples/$T-footprint-$P.txt 2>&1; fi
      sleep 60
    done ) > $F/sampler.log 2>&1 < /dev/null &
  $CMD > $F/run.log 2>&1
  echo "EXIT=$?" >> $F/run.log
  wait
  echo "$name $(tail -2 $F/run.log | tr '\n' ' ')"
}

run_part swap-base-1 981ce2d --full-window-contexts 32768
run_part swap-head-1 200fb39 --full-window-contexts 32768
run_part swap-head-2 200fb39 --full-window-contexts 32768
run_part swap-base-2 981ce2d --full-window-contexts 32768
run_part usage-db0f6c8 db0f6c8 --context 138240 --usage-sequence
run_part usage-53f3fa5 53f3fa5 --context 138240 --usage-sequence
run_part usage-200fb39 200fb39 --context 138240 --usage-sequence
echo ALL_DONE
