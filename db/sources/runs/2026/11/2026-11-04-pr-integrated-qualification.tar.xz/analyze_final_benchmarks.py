import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

ROOT=Path('/tmp/slotstream-pr-followup-20261104')
REPO=Path('/tmp/slotstream-pr-audit-scripts-20261104')
sys.path.insert(0,str(REPO/'Tools'))
from memory_gate import check_memory
from prefill_bench import validate_metrics

sources=[('baseline-vs-final','ordinary',8.1,False),
         ('baseline-vs-final-replacement-prose','ordinary',8.1,False),
         ('baseline-vs-final-mtp','mtp',10,True)]
expected={'ordinary':{'short','prose','code'},'mtp':{'code-brief-development'}}
groups={};exclusions=[];raw_count=0;fixtures={}
for folder,profile,target,mtp in sources:
    manifest=json.loads((ROOT/folder/'manifest.json').read_text())
    args=manifest['arguments']
    assert args['memory_gb']==target and args['mtp']==('on' if mtp else 'off') and args['seed']==7 and args['max_tokens']==32 and args['sample_footprint'] is True and args['sampled'] is False
    for arm in ('baseline','final'):
        identity=json.loads((ROOT/(arm+'-build')/'build-identity.json').read_text())
        assert manifest['build_identities'][arm]['binary_sha256']==identity['binary_sha256']
    rows=list(map(json.loads,(ROOT/folder/'results.jsonl').read_text().splitlines()))
    pairs={}
    for row in rows:
        raw_count+=1
        assert row['exit_code']==0 and row['requested_effective_chunk']==256
        assert row['valid'] is True or row.get('exclusion')=='swap activity during cell; timing excluded',row
        validate_metrics(row['metrics'])
        assert row['metrics']['effective_mtp'] is mtp and row['metrics']['effective_prefill_chunk']==256
        fixture=manifest['fixtures'][row['prompt']]['sha256']
        key=(profile,row['prompt'])
        assert key not in fixtures or fixtures[key]==fixture
        fixtures[key]=fixture
        row['_memory']=check_memory(row['metrics'],target)['maximum_observed_bytes']
        pairs.setdefault((row['prompt'],row['round']),{})[row['arm']]=row
    for (prompt,round_number),arms in sorted(pairs.items()):
        assert prompt in expected[profile] and set(arms)=={'baseline','final'}
        a,b=arms['baseline'],arms['final']
        ma,mb=a['metrics'],b['metrics']
        assert ma['prompt_ids']==mb['prompt_ids'] and ma['output_ids']==mb['output_ids']
        assert ma['effective_pool_slots']==mb['effective_pool_slots']
        item={'folder':folder,'round':round_number,'prompt':prompt,'profile':profile,
              'output_ids_equal':True,'baseline_wall_seconds':a['wall_seconds'],'final_wall_seconds':b['wall_seconds'],'wall_reduction_fraction':1-b['wall_seconds']/a['wall_seconds'],'baseline_request_seconds':ma['stats']['requestSeconds'],
              'final_request_seconds':mb['stats']['requestSeconds'],
              'request_reduction_fraction':1-mb['stats']['requestSeconds']/ma['stats']['requestSeconds'],
              'baseline_peak_bytes':a['_memory'],'final_peak_bytes':b['_memory'],
              'delta_bytes':b['_memory']-a['_memory'],
              'material_growth_threshold_bytes':max(250_000_000,.05*a['_memory'])}
        if not (a['valid'] and b['valid']):
            item['reason']='Global paging; discard the complete pair for timing.'
            item['discarded']=True;exclusions.append(item)
        else:groups.setdefault((profile,prompt),[]).append(item)
assert set(groups)=={(p,n) for p,names in expected.items() for n in names}
reports=[]
for (profile,prompt),pairs in sorted(groups.items()):
    assert len(pairs)==3,(profile,prompt,len(pairs))
    delta=statistics.median(p['request_reduction_fraction'] for p in pairs)
    memory_ok=statistics.median(p['delta_bytes']-p['material_growth_threshold_bytes'] for p in pairs)<=0
    assert delta>=-.05 and memory_ok,(profile,prompt,delta,memory_ok)
    reports.append({'profile':profile,'prompt':prompt,'passed':True,'median_request_reduction_fraction':delta,
                    'median_wall_reduction_fraction':statistics.median(p['wall_reduction_fraction'] for p in pairs),
                    'median_delta_bytes':statistics.median(p['delta_bytes'] for p in pairs),'pairs':pairs})
result={'passed':True,'all_cells_within_explicit_target':True,'raw_cells':raw_count,
        'used_pairs':sum(len(r['pairs']) for r in reports),'discarded_pairs':exclusions,'reports':reports}
(ROOT/'final-benchmark-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'final-benchmark-memory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('reports','discarded_pairs')}))
for r in reports:print(r['profile'],r['prompt'],round(r['median_request_reduction_fraction']*100,3),'percent request reduction',r['median_delta_bytes'],'bytes median peak change')
