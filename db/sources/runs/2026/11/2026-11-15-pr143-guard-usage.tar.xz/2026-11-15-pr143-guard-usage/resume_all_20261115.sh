#!/bin/bash
# Resume after the 11-14 stop and 11-15 reboot, one driver, strictly serial:
#  1. oMLX 0.8.0rc1 via brew, before any clean_mac.sh (clean_mac kills everything under /opt/homebrew).
#  2. PR143 usage sequences (db0f6c8, 53f3fa5, 200fb39) at --context 138240 --usage-sequence.
#  3. Prefetch-off recalibration of mac-flash-next (200fb398, harness hive.json carries
#     SLOTSTREAM_OPT_EXPERT_PREFETCH=0): full window 138240, then usage sequence 138240.
set -uo pipefail
P143=/Volumes/llm/hive-frame-pr143-ab-20261113
NOPF=/Volumes/llm/hive-frame-200fb39-noprefetch-calibration-20261114
PY=/Volumes/llm/hive-frame-capacity-20261011/tokenizer-venv/bin/python
TEXT=/Volumes/llm/hive-frame-wired-test-20261110/long_prompt.txt
MODEL=/Volumes/llm/models/qwen38-flash-next-mlx-4bit
MIRRORS="/Users/USER/.slotstream/models/qwen38-flash-next-mlx-4bit /Volumes/llm-250/models/qwen38-flash-next-mlx-4bit"
receipt() {
  case $1 in
    db0f6c8) echo /Volumes/llm/hive-frame-db0f6c8-calibration-20261110 ;;
    53f3fa5) echo /Volumes/llm/hive-frame-53f3fa5-calibration-20261112 ;;
    200fb39) echo /Volumes/llm/hive-frame-200fb39-calibration-20261112 ;;
  esac | sed 's|$|/harness/src/hive_frame/data/slotstream-runtime.json|'
}

echo "omlx start $(date)"
HOMEBREW_NO_INSTALL_CLEANUP=1 HOMEBREW_NO_AUTO_UPDATE=1 /opt/homebrew/bin/brew upgrade omlx > $P143/omlx-install-20261115.log 2>&1
if ! readlink /opt/homebrew/opt/omlx | grep -q 0.8.0rc1; then
  HOMEBREW_NO_INSTALL_CLEANUP=1 HOMEBREW_NO_AUTO_UPDATE=1 /opt/homebrew/bin/brew reinstall omlx >> $P143/omlx-install-20261115.log 2>&1
fi
echo "omlx $(readlink /opt/homebrew/opt/omlx) $(date)"
while ps -axww -o command | grep -E -q '[b]rew\.rb'; do sleep 30; done

run_part() {  # dir, arm, harness dir, extra harness args...
  local F=$1 arm=$2 H=$3; shift 3
  mkdir -p $F/samples
  bash /Volumes/llm/slotstream-read-lanes/clean_mac.sh > $F/clean.log 2>&1
  sleep 60
  cd $H
  local CMD="$PY tools/measure_slotstream_persistent_prefix.py --source /Volumes/llm/hive-frame-slotstream-$arm --binary /Users/USER/.local/share/hive_frame/runtimes/slotstream-$arm/slotstream --runtime-receipt $(receipt $arm) --model $MODEL --mirror $MIRRORS --output $F/study --cache-root $F/study-cache --text-file $TEXT $*"
  echo "$CMD" > $F/command.txt
  ( while ! grep -q '^EXIT=' $F/run.log 2>/dev/null; do
      T=$(date +%H%M%S)
      P=$(ps -axww -o pid,command | awk -v a="slotstream-$arm/slotstream serve" 'index($0, a) {print $1}' | head -1)
      { date; vm_stat; sysctl vm.swapusage; } > $F/samples/$T-vmstat.txt
      if [ -n "$P" ]; then footprint $P > $F/samples/$T-footprint-$P.txt 2>&1; fi
      sleep 60
    done ) > $F/sampler.log 2>&1 < /dev/null &
  $CMD > $F/run.log 2>&1
  echo "EXIT=$?" >> $F/run.log
  wait
  echo "$F $(tail -2 $F/run.log | tr '\n' ' ') $(date)"
}

mv $P143/run/usage-db0f6c8 $P143/run/usage-db0f6c8-interrupted-20261114
for arm in db0f6c8 53f3fa5 200fb39; do
  run_part $P143/run/usage-$arm $arm $P143/harness --context 138240 --usage-sequence
done
echo "PR143 ALL_DONE $(date)"

date > $NOPF/started.txt
run_part $NOPF/full 200fb39 $NOPF/harness --full-window-contexts 138240
run_part $NOPF/usage 200fb39 $NOPF/harness --context 138240 --usage-sequence
echo "ALL_DONE $(date)"
