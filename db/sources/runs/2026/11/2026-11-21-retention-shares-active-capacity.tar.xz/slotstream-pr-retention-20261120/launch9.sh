#!/bin/bash
D=/Volumes/llm/slotstream-pr-retention-20261120
W=/Volumes/llm/slotstream-pr-scopefix-20261121
$D/run_pr.sh fix@31:1 fix@32:1 >> $D/driver9.log 2>&1
$D/run_multi.sh fix@30:1 >> $D/driver9.log 2>&1
(cd $W && git am -3 $D/changelog.patch > $W/am-changelog.log 2>&1; echo AM_EXIT=$? >> $W/am-changelog.log)
(cd $W && bash Tools/static_gates.sh > $W/static-gates.log 2>&1; echo STATIC_EXIT=$? >> $W/static-gates.log)
echo ALL_DONE >> $D/driver9.log
