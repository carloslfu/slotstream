#!/bin/bash
# PR validation at production settings: upstream main d30ee840 vs PR 4384abc6, both plus
# the ignore-EOS bench switch. Interleaved arms; preflight, clean_mac, swap snapshot and a
# 60 s idle wait before each; the run stops if preflight fails.
D=/Volumes/llm/slotstream-pr-retention-20261120
OUT=$D/run
PY=/Volumes/llm/hive-frame-capacity-20261011/tokenizer-venv/bin/python
mkdir -p $OUT
for ar in "$@"; do
  arm=${ar%:*}; r=${ar#*:}; C=$OUT/$arm-$r; mkdir -p $C
  bash /Volumes/llm/bench-preflight.sh > $C/preflight.txt 2>&1 || { cat $C/preflight.txt; echo "STOP preflight $arm-$r"; exit 1; }
  bash /Volumes/llm/slotstream-read-lanes/clean_mac.sh > $C/clean.log 2>&1
  bash /Volumes/llm/bench-preflight.sh >> $C/preflight.txt 2>&1 || { cat $C/preflight.txt; echo "STOP preflight $arm-$r"; exit 1; }
  { date; vm_stat | grep -i swap; sysctl vm.swapusage; } > $C/swap-before.txt
  sleep 60
  $PY -u $D/multi.py $OUT $arm $r
  echo "$arm-$r exit=$?"
done
echo ALL_DONE
