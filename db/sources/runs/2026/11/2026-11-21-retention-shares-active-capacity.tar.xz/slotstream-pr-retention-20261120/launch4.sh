#!/bin/bash
/Volumes/llm/slotstream-pr-retention-20261120/run_pr.sh 'scopelog%0:1' >> /Volumes/llm/slotstream-pr-retention-20261120/driver4.log 2>&1
echo ALL_DONE >> /Volumes/llm/slotstream-pr-retention-20261120/driver4.log
