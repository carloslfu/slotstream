"""Production-setting slotstream at ctx 138240 on four model copies: upstream main vs the retention PR.

Each arm starts a fresh server after preflight, clean_mac.sh and a 60 s idle wait, with the
production serve flags and env (prefetch off, prefill chunk 256, wired limit on, --memory-gb
27) and three mirrors, and an empty experiment prefix-cache directory. It loads the image
tower the way production does, then sends a short (2048-token) and a long (137984-token, the
source repeated past its 128000 tokens) raw prompt, each generating 256 greedy tokens.
"main" is upstream d30ee840 and "pr" is 4384abc6 (retained prefix-cache sequence bytes
charged inside the active capacity); both add SLOTSTREAM_BENCH_IGNORE_EOS=1 so the long
request decodes all 256 tokens.

Usage: python speed.py OUT_DIR ARM[@MEMORY_GB] ROUND (run_pr.sh owns cleaning and idle wait, because
clean_mac.sh kills any process under /opt/homebrew, which includes this interpreter).
"""

from __future__ import annotations

import base64
import json
import os
import re
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from tokenizers import Tokenizer

BINARIES = {
    "main": "/Volumes/llm/slotstream-main-d30ee840-ignore-eos-20261120/.build/release/slotstream",
    "pr": "/Volumes/llm/slotstream-pr-4384abc6-ignore-eos-20261120/.build/release/slotstream",
    # pr plus a stderr line per automatic read-scope decision (SLOTSTREAM_BENCH_SCOPE_LOG=1).
    "scopelog": "/Volumes/llm/slotstream-pr-scope-log-20261121/.build/release/slotstream",
    # pr plus 58581e69: attention and expert workspace priced as sequential, cache cleared before the scope check.
    "fix": "/Volumes/llm/slotstream-pr-scopefix-20261121/.build/release/slotstream",
}
MODEL = "/Volumes/llm/models/qwen38-flash-next-mlx-4bit"
MIRRORS = [
    "~/.slotstream/models/qwen38-flash-next-mlx-4bit",
    "/Volumes/llm-256-2/models/qwen38-flash-next-mlx-4bit",
    "/Volumes/llm-256-1/models/qwen38-flash-next-mlx-4bit",
]
# Upstream main made the wired limit opt-in; production's 200fb398 fork always sets it.
PRODUCTION_ENV = {"SLOTSTREAM_PREFILL_CHUNK": "256", "SLOTSTREAM_OPT_EXPERT_PREFETCH": "0",
                  "SLOTSTREAM_WIRED_LIMIT": "1"}
SHORT_PROMPT = "~/.local/state/hive_frame/bench/mac-slotstream-main-20261106-v2/prompt.txt"
LONG_SOURCE = "/Volumes/llm/hive-frame-wired-test-20261110/long_prompt.txt"
LONG_TOKENS = 137984
IMAGE = "/Volumes/llm/hive-frame-53f3fa5-three-replica-20261112-r2/full/study/image-224.png"
REPLY_TOKENS = 256


def swap_counters() -> dict[str, int]:
    text = subprocess.check_output(["vm_stat"], text=True)
    return {
        key: int(re.search(rf'"?{label}"?:\s+(\d+)', text).group(1))
        for key, label in (("swapins", "Swapins"), ("swapouts", "Swapouts"))
    }


def request(url: str, path: str, body: dict | None = None, timeout: int = 3600) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url + path, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.load(response)


def main() -> None:
    out, arm, round_ = Path(sys.argv[1]), sys.argv[2], int(sys.argv[3])
    # "pr@29" runs the pr binary at --memory-gb 29; a bare arm uses production's 27.
    # "scopelog%0" adds SLOTSTREAM_PREFILL_CACHE_MB=0 (MLX buffer cache capped while a prompt is read).
    binary, _, memory_gb = arm.partition("@")
    # "scopelog^30" sets SLOTSTREAM_BENCH_SCOPE_LIMIT_GB=30: only the read-scope check limit, not the plan.
    binary, _, scope_gb = binary.partition("^")
    binary, _, cache_mb = binary.partition("%")
    memory_gb = memory_gb or "27"
    tokenizer = Tokenizer.from_file(f"{MODEL}/tokenizer.json")
    long_ids = tokenizer.encode(Path(LONG_SOURCE).read_text(), add_special_tokens=False).ids
    long_ids = long_ids * (LONG_TOKENS // len(long_ids) + 1)
    long_prompt = tokenizer.decode(long_ids[:LONG_TOKENS], skip_special_tokens=False)
    prompts = {"short": Path(SHORT_PROMPT).read_text(), "long": long_prompt}
    image = base64.b64encode(Path(IMAGE).read_bytes()).decode()
    cell = out / f"{arm}-{round_}"
    cell.mkdir(exist_ok=True)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    cache = cell / "prefix-cache"
    cmd = [
        BINARIES[binary], "serve", "--model", MODEL, "--memory-gb", memory_gb, "--max-context", "138240",
        "--mtp", "on", "--prefix-cache-dir", str(cache), "--prefix-cache-disk-gb", "20",
        "--prefix-cache-min-tokens", "1024", "--port", str(port), "--vision", "on",
        *(arg for m in MIRRORS for arg in ("--mirror", m)), "--max-prefill-wait", "90",
    ]
    arm_env = {**PRODUCTION_ENV, "SLOTSTREAM_BENCH_DETAILS": "1", "SLOTSTREAM_BENCH_IGNORE_EOS": "1",
               **({"SLOTSTREAM_BENCH_SCOPE_LOG": "1"} if binary == "scopelog" else {}),
               **({"SLOTSTREAM_PREFILL_CACHE_MB": cache_mb} if cache_mb else {}),
               **({"SLOTSTREAM_BENCH_SCOPE_LIMIT_GB": scope_gb} if scope_gb else {})}
    env = {k: v for k, v in os.environ.items() if not k.startswith("SLOTSTREAM_")}
    env.update(arm_env)
    (cell / "command.txt").write_text(
        " ".join(f"{k}={v}" for k, v in arm_env.items()) + " " + " ".join(cmd) + "\n"
    )
    row = {"arm": arm, "round": round_, "port": port, "phases": {}}
    swap_start = swap_counters()
    with (cell / "server.log").open("w") as log:
        child = subprocess.Popen(cmd, env=env, stdout=log, stderr=log, stdin=subprocess.DEVNULL)
        url = f"http://127.0.0.1:{port}"
        try:
            deadline = time.monotonic() + 300
            while True:
                if child.poll() is not None:
                    raise RuntimeError(f"server exited {child.returncode} before readiness")
                try:
                    model = request(url, "/api/ps", timeout=2)["models"][0]["model"]
                    break
                except (OSError, ValueError, KeyError, IndexError):
                    if time.monotonic() > deadline:
                        raise TimeoutError("server not ready in 300 s")
                    time.sleep(0.5)
            bodies = {
                "image": {"model": model, "prompt": "Describe the color in one word.",
                          "images": [image], "stream": False,
                          "options": {"temperature": 0, "seed": 1, "num_predict": 16}},
                **{
                    name: {"model": model, "prompt": text, "raw": True, "stream": False,
                           "options": {"temperature": 0, "seed": 1,
                                       "num_predict": REPLY_TOKENS}}
                    for name, text in prompts.items()
                },
            }
            for name, body in bodies.items():
                before = swap_counters()
                clock = time.monotonic()
                data = request(url, "/api/generate", body)
                wall = time.monotonic() - clock
                after = swap_counters()
                (cell / f"{name}-response.json").write_text(json.dumps(data) + "\n")
                bench = data.get("slotstream_benchmark", {})
                stats = bench.get("stats", {})
                row["phases"][name] = {
                    "wall_seconds": wall,
                    "prompt_tokens": data.get("prompt_eval_count"),
                    "prefill_seconds": data.get("prompt_eval_duration", 0) / 1e9,
                    "decode_tokens": data.get("eval_count"),
                    "decode_seconds": data.get("eval_duration", 0) / 1e9,
                    "pool_slots": bench.get("effective_pool_slots"),
                    "peak_footprint_bytes": stats.get("lifetimePhysicalFootprintPeakBytes"),
                    "sampled_peak_bytes": (stats.get("sampledFootprint") or {}).get("peakBytes"),
                    "response": data.get("response"),
                    "swap_delta": {k: after[k] - before[k] for k in after},
                }
                p = row["phases"][name]
                p["decode_tok_s"] = p["decode_tokens"] / p["decode_seconds"] if p["decode_seconds"] else None
                p["prefill_tok_s"] = p["prompt_tokens"] / p["prefill_seconds"] if p["prefill_seconds"] else None
                print(arm, round_, name, json.dumps({k: v for k, v in p.items() if k != "response"}), flush=True)
        except Exception as error:  # noqa: BLE001 - record and continue with the next independent arm-round
            row["error"] = repr(error)
            print(arm, round_, "ERROR", repr(error), flush=True)
        finally:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
    swap_end = swap_counters()
    row["swap_delta_total"] = {k: swap_end[k] - swap_start[k] for k in swap_end}
    (cell / "result.json").write_text(json.dumps(row, indent=2) + "\n")


if __name__ == "__main__":
    main()
