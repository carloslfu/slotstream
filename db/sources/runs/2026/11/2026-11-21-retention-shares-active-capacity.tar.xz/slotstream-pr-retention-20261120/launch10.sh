#!/bin/bash
D=/Volumes/llm/slotstream-pr-retention-20261120
W=/Volumes/llm/slotstream-pr-scopefix-20261121
(cd $W && bash Tools/dbmd_install.sh > $W/dbmd-install.log 2>&1; echo INSTALL_EXIT=$? >> $W/dbmd-install.log)
(cd $W && PATH=$HOME/.dbmd/bin:$PATH bash Tools/static_gates.sh > $W/static-gates-2.log 2>&1; echo STATIC_EXIT=$? >> $W/static-gates-2.log)
$D/run_multi.sh fix@29:1 fix@27:1 main@27:1 >> $D/driver10.log 2>&1
echo ALL_DONE >> $D/driver10.log
