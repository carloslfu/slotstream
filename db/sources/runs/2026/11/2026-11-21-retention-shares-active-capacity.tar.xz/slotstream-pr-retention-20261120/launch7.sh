#!/bin/bash
export PATH=/Library/Developer/Toolchains/swift-6.3-RELEASE.xctoolchain/usr/bin:$PATH
(cd /Volumes/llm/slotstream-pr-scopefix-20261121 && make build SLOTSTREAM_BUILD_JOBS=4 > /Volumes/llm/slotstream-pr-scopefix-20261121/build.log 2>&1; echo BUILD_EXIT=$? >> /Volumes/llm/slotstream-pr-scopefix-20261121/build.log)
grep -q "BUILD_EXIT=0" /Volumes/llm/slotstream-pr-scopefix-20261121/build.log || { echo BUILD_FAILED >> /Volumes/llm/slotstream-pr-retention-20261120/driver7.log; exit 1; }
/Volumes/llm/slotstream-pr-retention-20261120/run_pr.sh fix:1 >> /Volumes/llm/slotstream-pr-retention-20261120/driver7.log 2>&1
(cd /Volumes/llm/slotstream-pr-scopefix-20261121 && make checks > /Volumes/llm/slotstream-pr-scopefix-20261121/checks.log 2>&1; echo CHECKS_EXIT=$? >> /Volumes/llm/slotstream-pr-scopefix-20261121/checks.log)
echo ALL_DONE >> /Volumes/llm/slotstream-pr-retention-20261120/driver7.log
