#!/bin/bash
export PATH=/Library/Developer/Toolchains/swift-6.3-RELEASE.xctoolchain/usr/bin:$PATH
(cd /Volumes/llm/slotstream-pr-scope-log-20261121 && make build SLOTSTREAM_BUILD_JOBS=4 > /Volumes/llm/slotstream-pr-scope-log-20261121/build.log 2>&1; echo BUILD_EXIT=$? >> /Volumes/llm/slotstream-pr-scope-log-20261121/build.log)
grep -q "BUILD_EXIT=0" /Volumes/llm/slotstream-pr-scope-log-20261121/build.log || { echo BUILD_FAILED >> /Volumes/llm/slotstream-pr-retention-20261120/driver3.log; exit 1; }
ls -la /Volumes/llm/slotstream-pr-scope-log-20261121/.build/release/slotstream >> /Volumes/llm/slotstream-pr-retention-20261120/driver3.log
/Volumes/llm/slotstream-pr-retention-20261120/run_pr.sh scopelog:2 >> /Volumes/llm/slotstream-pr-retention-20261120/driver3.log 2>&1
echo ALL_DONE >> /Volumes/llm/slotstream-pr-retention-20261120/driver3.log
