"""Interleaved conversation peak test: one long chat and short title requests on one server.

Open WebUI sends a title request (a different prefix) between turns of a chat. This runs a
130000-token chat turn, a title request, the chat continued by 4000 new tokens, a second title
request, and the chat continued by 2000 more, so retained prefix states plus the active request
sit near the 138240 context. It records per-turn peak footprint, swap, prefix-cache outcome and
speed, to check that charging retained sequence bytes inside the active capacity holds the peak
within the plan. Serve flags and env are speed.py's.

Usage: python multi.py OUT_DIR ARM[@MEMORY_GB] ROUND (run_pr.sh owns cleaning and idle wait).
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

from speed import (BINARIES, LONG_SOURCE, MIRRORS, MODEL, PRODUCTION_ENV, SHORT_PROMPT,
                   request, swap_counters)
from tokenizers import Tokenizer

CHAT_TOKENS = 130000
CONTINUATIONS = (4000, 2000)


def main() -> None:
    out, arm, round_ = Path(sys.argv[1]), sys.argv[2], int(sys.argv[3])
    binary, _, memory_gb = arm.partition("@")
    memory_gb = memory_gb or "27"
    tokenizer = Tokenizer.from_file(f"{MODEL}/tokenizer.json")
    source = tokenizer.encode(Path(LONG_SOURCE).read_text(), add_special_tokens=False).ids
    source = source * ((CHAT_TOKENS + sum(CONTINUATIONS)) // len(source) + 1)
    title = "Generate a short title for this conversation:\n" + Path(SHORT_PROMPT).read_text()[:6000]

    cell = out / f"multi-{arm}-{round_}"
    cell.mkdir(exist_ok=True)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    cmd = [
        BINARIES[binary], "serve", "--model", MODEL, "--memory-gb", memory_gb, "--max-context", "138240",
        "--mtp", "on", "--prefix-cache-dir", str(cell / "prefix-cache"), "--prefix-cache-disk-gb", "20",
        "--prefix-cache-min-tokens", "1024", "--port", str(port), "--vision", "on",
        *(arg for m in MIRRORS for arg in ("--mirror", m)), "--max-prefill-wait", "90",
    ]
    arm_env = {**PRODUCTION_ENV, "SLOTSTREAM_BENCH_DETAILS": "1"}
    env = {k: v for k, v in os.environ.items() if not k.startswith("SLOTSTREAM_")}
    env.update(arm_env)
    (cell / "command.txt").write_text(" ".join(f"{k}={v}" for k, v in arm_env.items()) + " " + " ".join(cmd) + "\n")

    rows = []
    with (cell / "server.log").open("w") as log:
        child = subprocess.Popen(cmd, env=env, stdout=log, stderr=log, stdin=subprocess.DEVNULL)
        url = f"http://127.0.0.1:{port}"
        try:
            deadline = time.monotonic() + 300
            while True:
                if child.poll() is not None:
                    raise RuntimeError(f"server exited {child.returncode} before readiness")
                try:
                    model = request(url, "/api/ps", timeout=2)["models"][0]["model"]
                    break
                except (OSError, ValueError, KeyError, IndexError):
                    if time.monotonic() > deadline:
                        raise TimeoutError("server not ready in 300 s") from None
                    time.sleep(0.5)

            chat = tokenizer.decode(source[:CHAT_TOKENS], skip_special_tokens=False)
            offset = CHAT_TOKENS
            turns = [("chat-1", None)]
            for i, extra in enumerate(CONTINUATIONS, start=2):
                turns += [(f"title-{i - 1}", None), (f"chat-{i}", extra)]
            for name, extra in turns:
                if name.startswith("chat") and extra:
                    chat += tokenizer.decode(source[offset:offset + extra], skip_special_tokens=False)
                    offset += extra
                prompt = title if name.startswith("title") else chat
                body = {"model": model, "prompt": prompt, "raw": True, "stream": False,
                        "options": {"temperature": 0, "seed": 1, "num_predict": 32 if name.startswith("title") else 64}}
                before = swap_counters()
                clock = time.monotonic()
                data = request(url, "/api/generate", body)
                wall = time.monotonic() - clock
                after = swap_counters()
                (cell / f"{name}-response.json").write_text(json.dumps(data) + "\n")
                if name.startswith("chat"):
                    chat += data.get("response", "")
                stats = data.get("slotstream_benchmark", {}).get("stats", {})
                row = {
                    "turn": name, "wall_seconds": wall,
                    "prompt_tokens": data.get("prompt_eval_count"),
                    "prefill_seconds": data.get("prompt_eval_duration", 0) / 1e9,
                    "decode_tokens": data.get("eval_count"),
                    "decode_seconds": data.get("eval_duration", 0) / 1e9,
                    "expert_hit_rate": stats.get("expertHitRate"),
                    "sampled_peak_bytes": (stats.get("sampledFootprint") or {}).get("peakBytes"),
                    "swap_delta": {k: after[k] - before[k] for k in after},
                }
                rows.append(row)
                print(arm, round_, json.dumps(row), flush=True)
        except Exception as error:  # noqa: BLE001 - keep the turns already measured
            body = error.read().decode(errors="replace") if hasattr(error, "read") else ""
            rows.append({"error": repr(error), "body": body})
            print(arm, round_, "BODY", body, flush=True)
            print(arm, round_, "ERROR", repr(error), flush=True)
        finally:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
    (cell / "result.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
