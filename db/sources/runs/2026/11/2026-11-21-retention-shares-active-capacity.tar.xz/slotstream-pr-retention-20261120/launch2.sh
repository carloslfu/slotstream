#!/bin/bash
# After the four production-target rounds, the PR binary at --memory-gb 29 so prefill read
# scopes and the larger expert pool can both fit.
D=/Volumes/llm/slotstream-pr-retention-20261120
until grep -q -E "ALL_DONE|STOP preflight" $D/driver.log; do sleep 60; done
grep -q ALL_DONE $D/driver.log || exit 1
bash $D/run_pr.sh pr@29:1 >> $D/driver2.log 2>&1
