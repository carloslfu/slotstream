#!/bin/bash
# Builds both release binaries one after the other, then runs main:1 pr:1 pr:2 main:2.
export PATH=/Library/Developer/Toolchains/swift-6.3-RELEASE.xctoolchain/usr/bin:$PATH
D=/Volumes/llm/slotstream-pr-retention-20261120
for w in main-d30ee840 pr-4384abc6; do
  W=/Volumes/llm/slotstream-$w-ignore-eos-20261120
  (cd $W && make build SLOTSTREAM_BUILD_JOBS=4 > $W/build.log 2>&1) || { echo "BUILD_FAILED $w" >> $D/driver.log; exit 1; }
  ls -la $W/.build/release/slotstream >> $D/driver.log
done
bash $D/run_pr.sh main:1 pr:1 pr:2 main:2 >> $D/driver.log 2>&1
