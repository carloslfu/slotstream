#!/bin/bash
/Volumes/llm/slotstream-pr-retention-20261120/run_pr.sh fix@29:1 fix@30:1 >> /Volumes/llm/slotstream-pr-retention-20261120/driver8.log 2>&1
echo ALL_DONE >> /Volumes/llm/slotstream-pr-retention-20261120/driver8.log
